```markdown
# 文明、现代化与价值投资技能集

本技能集源自专业著作《文明、现代化、价值投资与中国》，涵盖文明演进研究、现代化历史分析、价值投资实践、跨学科思维方法以及未来趋势预测等多个领域。这些技能帮助用户深入理解人类文明发展规律、掌握价值投资核心理念、运用跨学科思维解决复杂问题，并为个人成长和战略决策提供系统框架。

## 可用技能

| 技能 | 描述 | 适用场景 |
|------|------|----------|
| [civilization-stage-classification](civilization-stage-classification/SKILL.md) | 将人类文明划分为采集狩猎(1.0)、农业畜牧业(2.0)、科技文明(3.0)三个阶段 | 界定文明发展阶段、区分文化与文明概念、解释科技文明独特性 |
| [human-civilization-three-stages-great-divergence](human-civilization-three-stages-great-divergence/SKILL.md) | 运用人类文明三阶段跃升与东西方两次大分流理论分析文明演进 | 解释东西方发展差异根源、分析文明跃迁机制、理解现代地缘政治格局 |
| [civilization-3.0-framework](civilization-3.0-framework/SKILL.md) | 3.0科技文明运行机制、自由市场经济原理、政治权力分配制度分析 | 研究文明演进、制度经济学、政治经济关系分析 |
| [civilization-3-0-market-iron-law](civilization-3-0-market-iron-law/SKILL.md) | 运用3.0文明铁律分析自由市场体系竞争格局 | 预测全球市场演变趋势、分析市场规模与效率关系、判断市场整合方向 |
| [civilization-3-0-economic-theory](civilization-3-0-economic-theory/SKILL.md) | 应用3.0文明铁律理论理解科技与市场结合产生的现代化机制 | 分析全球经济体系长期趋势、评估国家发展战略、理解全球化必然性 |
| [modernization-causal-chain-analysis](modernization-causal-chain-analysis/SKILL.md) | 分析现代化诞生的严格历史因果链条——从新大陆发现到工业革命 | 解释现代化起源、分析历史反事实、评估特定国家现代化潜力 |
| [modernization-spread-dual-track-analysis](modernization-spread-dual-track-analysis/SKILL.md) | 分析19世纪现代化文明传播的双轨规律——主动现代化与被动卷入 | 解释国家发展路径差异、预测工业化速度、分析殖民历史影响 |
| [modernization-path-comparison](modernization-path-comparison/SKILL.md) | 使用20世纪历史证据比较经济发展模式（自由市场 vs 国家干预） | 评估面临危机国家的经济制度选择 |
| [agricultural-civilization-ceiling-analysis](agricultural-civilization-ceiling-analysis/SKILL.md) | 分析农业文明的天花板效应及其引发的五大灾难循环机制 | 解释古代社会周期性动荡、农业帝国兴衰规律、马尔萨斯陷阱运作逻辑 |
| [agricultural-civilization-historical-patterns](agricultural-civilization-historical-patterns/SKILL.md) | 应用马尔萨斯陷阱和三次冲顶理论解释农业文明瓶颈与思想革命关系 | 研究农业文明历史周期、分析文明兴衰规律、理解轴心时代思想起源 |
| [axial-age-thought-revolution-analysis](axial-age-thought-revolution-analysis/SKILL.md) | 分析公元前5世纪轴心时代思想革命的核心特征及跨文化一致性 | 理解高端政权建设思想基础、构建社会伦理体系、分析跨文化哲学共通性 |
| [scientific-revolution-intellectual-framework](scientific-revolution-intellectual-framework/SKILL.md) | 分析17-18世纪科学革命与启蒙运动的知识触发机制 | 讨论科学革命起源、启蒙运动思想基础、现代化知识条件 |
| [atlantic-economy-formation-analysis](atlantic-economy-formation-analysis/SKILL.md) | 分析15-18世纪环大西洋经济体系的形成机制、殖民模式差异 | 理解大航海时代经济转型、英美宪政模式与西葡掠夺模式对比 |
| [structural-analysis-of-chinese-modernization-failure](structural-analysis-of-chinese-modernization-failure/SKILL.md) | 分析中国帝制时期未能自发实现现代化的结构性障碍 | 解释中国现代化失败根本原因、对比中西发展路径差异 |
| [chinese-political-three-source-adaptation](chinese-political-three-source-adaptation/SKILL.md) | 运用中国传统政治三源（儒家、法家、道家）动态适配框架 | 大国政治治理、传统政治现代化转型、科技文明时代政治制度设计 |
| [china-reform-literature-map](china-reform-literature-map/SKILL.md) | 提供中国当代经济改革开放研究的五维文献地图 | 研究1978年后中国经济改革、分析发展模式、进行国际比较研究 |
| [china-international-strategy](china-international-strategy/SKILL.md) | 涵盖从大国关系框架到具体应对策略的完整体系 | 制定中国对外战略、分析中美关系、评估大国竞争风险 |
| [china-economic-transformation](china-economic-transformation/SKILL.md) | 涵盖从三合一机制到政策工具选择的完整分析体系 | 分析中国经济转型、政府与市场关系、宏观政策工具选择 |
| [china-economic-analysis](china-economic-analysis/SKILL.md) | 应用2.5阶段理论和改革开放分析框架 | 分析中国经济结构问题、评估就业与消费趋势、判断发展阶段特征 |
| [china-urbanization-consumption-mechanism](china-urbanization-consumption-mechanism/SKILL.md) | 量化分析中国城市化率提升对内需消费的释放机制 | 分析中国城市化政策经济影响、测算内需增长空间 |
| [china-engineer-dividend-assessment](china-engineer-dividend-assessment/SKILL.md) | 评估中国工程师红利对产业升级和长期竞争优势的影响 | 讨论中国制造业竞争力、科技产业发展潜力、中美科技竞争 |
| [east-asian-confucian-growth-benchmarking](east-asian-confucian-growth-benchmarking/SKILL.md) | 使用东亚儒教经济体历史增长轨迹预测中长期增长潜力 | 分析中国等儒教文化特征经济体在达到中等收入水平后的发展路径 |
| [imperial-examination-system](imperial-examination-system/SKILL.md) | 分析科举制作为农业文明2.0时代最伟大制度创新的机制、应用和历史影响 | 研究中国政治制度史、比较政治学、大规模政权管理、精英选拔体系设计 |
| [value-investing-core-principles](value-investing-core-principles/SKILL.md) | 区分投资与投机、评估投资风险、建立竞争优势、界定能力圈边界 | 股票投资者、基金经理和个人投资者进行价值投资决策 |
| [value-investing-core-principles-2](value-investing-core-principles-2/SKILL.md) | 应用格雷厄姆-巴菲特-芒格价值投资四概念框架 | 进行价值投资决策、评估股票内在价值、构建投资组合 |
| [value-investing-career-framework](value-investing-career-framework/SKILL.md) | 涵盖从入门到职业发展的完整路径 | 投资初学者、卖方分析师转型、寻找优秀投资人的个人投资者 |
| [value-investor-fiduciary-duty](value-investor-fiduciary-duty/SKILL.md) | 履行受托责任、执行价格发现与资本配置功能、管理长期资本 | 价值投资活动中的 fiduciary duty 履行、经济功能分析 |
| [value-investor-authenticity-assessment](value-investor-authenticity-assessment/SKILL.md) | 应用长期品性-业绩关联评估框架识别真伪价值投资者 | 判断某位投资者是否为真正的价值投资者、评估资产管理人长期可靠性 |
| [value-investing-generations-framework](value-investing-generations-framework/SKILL.md) | 帮助理解从格雷厄姆到全球实践者的理念发展及现代化与价值投资的正向循环机制 | 理解价值投资理念的历史演进、跨市场应用价值投资 |
| [value-investing-screening-workflow](value-investing-screening-workflow/SKILL.md) | 应用快速财务筛选流程和护城河时间维度分析 | 快速筛选潜在投资标的、分析企业护城河、确定研究优先级 |
| [earnings-quality-valuation-framework](earnings-quality-valuation-framework/SKILL.md) | 基于盈利质量的多维估值分析框架 | 评估上市公司估值水平、比较P/E倍数、分析周期性行业、筛选成长股 |
| [valuation-metrics-analysis](valuation-metrics-analysis/SKILL.md) | 通过当前P/E、历史P/E中位数和相对P/E判断高估或低估状态 | 个股估值评估、比较市盈率、相对估值水平和股息收益率 |
| [extreme-drawdown-competence-verification](extreme-drawdown-competence-verification/SKILL.md) | 验证投资者是否真正理解公司价值（能力圈边界） | 持仓股价下跌50%-80%且公司基本面未恶化时，决定继续持有或认错卖出 |
| [investment-manager-luck-vs-skill-evaluation](investment-manager-luck-vs-skill-evaluation/SKILL.md) | 评估投资经理或投资者自身业绩成功源于真实能力还是市场运气 | 筛选投资经理、验证投资策略有效性、区分运气与能力 |
| [buffett-partnership-compensation-structure](buffett-partnership-compensation-structure/SKILL.md) | 设计和计算基于"巴菲特合伙人模式"的投资基金报酬机制 | 建立深度利益对齐的基金结构、设计零管理费且附带累进复利门槛的报酬方案 |
| [munger-investment-philosophy](munger-investment-philosophy/SKILL.md) | 应用芒格"去有鱼的地方钓鱼"原则和正道vs小道选择逻辑 | 面临投资方法选择、决定投资市场区域、评估不同投资策略的可持续性 |
| [civilization-based-investment-framework](civilization-based-investment-framework/SKILL.md) | 从人类文明进化史角度理解目标国家的历史轨迹和未来趋势 | 进行跨国投资、在危机时期做出重大投资决策、评估特定国家长期潜力 |
| [retail-holding-company-analysis](retail-holding-company-analysis/SKILL.md) | 分析以投资控股为主业、持有上市子公司股份的零售企业财务表现 | 分析现代百货H&S(005440)等投资控股型零售企业的财务健康状况 |
| [universal-wisdom-interdisciplinary-thinking](universal-wisdom-interdisciplinary-thinking/SKILL.md) | 应用跨学科思维模型解决商业分析、投资研究和复杂问题 | 避免单一学科偏见、寻求深层认知、处理涉及多因素交互的系统性问题 |
| [new-history-interdisciplinary-methodology](new-history-interdisciplinary-methodology/SKILL.md) | 运用跨学科科学工具研究超越文字记载的人类历史（数万年尺度） | 解释东西方发展差距根源、预测基于长期进化规律的未来趋势 |
| [scientific-method-knowledge](scientific-method-knowledge/SKILL.md) | 应用科学方法作为唯一可靠路径，确保理论在实践中可被检验、批判和修正 | 获取可靠知识、评估理论学说有效性、进行客观研究 |
| [scientific-interest-driven-learning](scientific-interest-driven-learning/SKILL.md) | 采用科学方法结合兴趣引导的方式实现知识复利增长 | 建立可持续的竞争优势、在特定领域获得超越他人的知识深度和预测能力 |
| [knowledge-verification-framework](knowledge-verification-framework/SKILL.md) | 运用可证伪、可修正的真知标准评估知识命题的可靠性 | 验证知识可靠性、建立容错学习机制、评估理论实用性 |
| [social-development-index-measurement](social-development-index-measurement/SKILL.md) | 使用社会发展指数定量衡量文明发展水平（能量摄取、社会组织、信息技术、战争动员） | 历史比较研究、东西方发展差距分析、长期文明轨迹追踪 |
| [future-human-evolution-analysis](future-human-evolution-analysis/SKILL.md) | 分析人工智能与生物工程驱动的人类自我进化前景 | 评估未来技术趋势、分析全球治理挑战、预测人类物种命运 |
| [ai-existential-risk-assessment](ai-existential-risk-assessment/SKILL.md) | 评估AI技术发展对人类文明的生存性风险等级，并制定相应控制策略 | 讨论AI自主学习能力、超级智能风险、AI治理政策 |
| [permafrost-methane-feedback-analysis](permafrost-methane-feedback-analysis/SKILL.md) | 分析全球变暖导致西伯利亚冻土融化释放甲烷的反馈机制 | 评估气候临界点、冻土融化风险、修正长期气候模型 |
| [milankovitch-cycle-climate-mechanism](milankovitch-cycle-climate-mechanism/SKILL.md) | 分析地球轨道参数变化对长期气候的影响，解释冰期和间冰期的形成机制 | 古气候研究、地质历史分析、地球气候变化原因探讨 |
| [disruptive-technology-five-miracles-rule](disruptive-technology-five-miracles-rule/SKILL.md) | 通过检查是否具备至少五个连续的工程技术奇迹来判断技术实现的可能性 | 评估颠覆性技术可行性 |
| [decennial-self-renewal](decennial-self-renewal/SKILL.md) | 每5-10年进行系统性自我审视与重塑 | 中年转型、职业瓶颈突破、重大生活变故后的重建 |
| [blind-spot-mentorship-value](blind-spot-mentorship-value/SKILL.md) | 识别并利用导师/挚友指出自身盲点的价值 | 个人成长瓶颈期、重大决策前的自我审视、评估现有关系网络质量 |
| [cognitive-bias-investment](cognitive-bias-investment/SKILL.md) | 应用理性思维原则，认识到自然选择设计的认知局限 | 进行投资决策、克服认知偏差、提升思维能力 |
| [constitutional-democracy-evolution](constitutional-democracy-evolution/SKILL.md) | 指导3.0文明转型期社会按照特定渐进路径实现宪政民主制的演化 | 西方政治现代化进程分析、政治权力分配制度设计 |
| [us-hard-power-mechanism-analysis](us-hard-power-mechanism-analysis/SKILL.md) | 分析美国对外政策中硬实力运作机制与意识形态包装之间的分离关系 | 评估美国制裁有效性、美元体系控制力、跨境交易监控范围 |
| [us-china-policy-analysis](us-china-policy-analysis/SKILL.md) | 应用四大派别分类框架（接触派、鹰派、务实派、民粹派）及其演变趋势分析 | 分析中美关系走向、评估美国对华政策态度、理解美国内部政治派别 |
| [us-order-tier-classification](us-order-tier-classification/SKILL.md) | 使用美国秩序三层市场结构模型分析国家在国际体系中的经济地位 | 地缘政治经济分析、制裁风险评估、国际市场准入策略制定 |
| [rational-cultural-reconstruction-and-consensus](rational-cultural-reconstruction-and-consensus/SKILL.md) | 运用理性思维重整中国传统文化，通过事实和逻辑而非权威教条来批判性思考 | 面对科技文明挑战、重建社会精神基础、构建社会共识 |
| [macroeconomic-savings-investment-framework](macroeconomic-savings-investment-framework/SKILL.md) | 应用基于储蓄者与借款人存在情况的四象限分类框架 | 分析宏观经济状态、判断经济危机类型、制定财政货币政策 |
| [lewis-turning-point-economic-stages](lewis-turning-point-economic-stages/SKILL.md) | 运用刘易斯拐点理论判定经济体发展的三个阶段 | 分析劳动力市场变化、预测工资走势、评估投资环境与消费社会形成 |
| [virtual-real-economy-integration](virtual-real-economy-integration/SKILL.md) | 建立融合性政策视角，消除虚实界限的传统观念束缚 | 制定产业政策、进行经济分类、评估虚拟经济价值 |
| [book-recommendation-principles](book-recommendation-principles/SKILL.md) | 构建基于个人偏好的书籍推荐清单，确保推荐多样性、处理翻译版本免责声明 | 创建阅读指南或书单，特别是涉及英语原著推荐时 |
| [book-core-theme-framework](book-core-theme-framework/SKILL.md) | 分析书籍的核心议题架构，明确文明、现代化、价值投资与中国之间的逻辑关系 | 梳理书籍主题层级、理解核心论点框架、解释书籍讨论范围 |
| [western-civilization-reading-guide](western-civilization-reading-guide/SKILL.md) | 提供西方文明史与传记类核心阅读书目分类指南 | 系统学习西方文明史、构建通识教育知识体系、研究重要历史人物 |
| [chinese-english-civilization-terminology](chinese-english-civilization-terminology/SKILL.md) | 将文明研究领域的核心中文术语准确翻译为英文对应概念 | 询问"文明"、"现代化"等术语的英文表达、学术写作中确认专业词汇英译 |
| [chinese-civilization-research-bibliography](chinese-civilization-research-bibliography/SKILL.md) | 提供从古典原著到现代学术的系统知识框架分级阅读体系 | 研究中国文明、历史或文化、建立系统知识框架 |
| [publisher-metadata-extraction](publisher-metadata-extraction/SKILL.md) | 从出版物文档中提取出版来源元数据信息 | 识别书籍/文档的出版商信息、处理版权页数据、出版元数据整理 |

## 快速导航

### 文明演进与现代化理论
- **civilization-stage-classification**: 文明三阶段分类框架（1.0狩猎采集、2.0农业、3.0科技）
- **human-civilization-three-stages-great-divergence**: 东西方大分流与文明跃迁分析
- **civilization-3.0-framework**: 3.0科技文明的完整运行机制
- **civilization-3-0-market-iron-law**: 自由市场竞争的铁律
- **modernization-causal-chain-analysis**: 现代化起源的严格因果链
- **modernization-spread-dual-track-analysis**: 现代化传播的双轨规律
- **agricultural-civilization-ceiling-analysis**: 农业文明的能量瓶颈与循环灾难
- **axial-age-thought-revolution-analysis**: 轴心时代思想革命分析

### 中国研究
- **structural-analysis-of-chinese-modernization-failure**: 中国现代化失败的结构性障碍
- **chinese-political-three-source-adaptation**: 儒法道三源动态适配框架
- **china-reform-literature-map**: 中国改革开放研究五维文献地图
- **china-international-strategy**: 中国对外战略完整体系
- **china-economic-transformation**: 中国经济转型分析框架
- **china-economic-analysis**: 中国经济结构与发展阶段分析
- **china-urbanization-consumption-mechanism**: 城市化与内需释放机制
- **china-engineer-dividend-assessment**: 工程师红利与产业升级
- **east-asian-confucian-growth-benchmarking**: 东亚儒教经济体增长基准
- **imperial-examination-system**: 科举制的制度创新分析

### 价值投资
- **value-investing-core-principles**: 价值投资核心原则（投资vs投机、能力圈、安全边际）
- **value-investing-core-principles-2**: 格雷厄姆-巴菲特-芒格四概念框架
- **value-investing-career-framework**: 价值投资职业发展路径
- **value-investor-fiduciary-duty**: 价值投资者的受托责任
- **value-investor-authenticity-assessment**: 真伪价值投资者识别
- **value-investing-generations-framework**: 价值投资理念的历史演进
- **value-investing-screening-workflow**: 快速筛选与护城河分析
- **earnings-quality-valuation-framework**: 盈利质量多维估值框架
- **valuation-metrics-analysis**: P/E估值指标分析
- **extreme-drawdown-competence-verification**: 极端回撤时的能力圈验证
- **investment-manager-luck-vs-skill-evaluation**: 运气与能力区分评估
- **buffett-partnership-compensation-structure**: 巴菲特合伙报酬结构设计
- **munger-investment-philosophy**: 芒格投资哲学（去有鱼的地方钓鱼）
- **civilization-based-investment-framework**: 基于文明认知的投资框架

### 跨学科思维与知识方法
- **universal-wisdom-interdisciplinary-thinking**: 普世智慧跨学科思维模型
- **new-history-interdisciplinary-methodology**: 跨学科研究人类历史（数万年尺度）
- **scientific-method-knowledge**: 科学方法作为可靠知识路径
- **scientific-interest-driven-learning**: 科学兴趣驱动的知识复利增长
- **knowledge-verification-framework**: 可证伪、可修正的真知标准
- **social-development-index-measurement**: 文明发展水平定量测量

### 未来趋势与风险
- **future-human-evolution-analysis**: AI与生物工程驱动的人类进化前景
- **ai-existential-risk-assessment**: AI技术生存性风险评估
- **permafrost-methane-feedback-analysis**: 冻土融化甲烷反馈机制
- **milankovitch-cycle-climate-mechanism**: 地球轨道参数与气候变化
- **disruptive-technology-five-miracles-rule**: 颠覆性技术可行性评估

### 个人成长与认知
- **decennial-self-renewal**: 十年系统性自我审视与重塑
- **blind-spot-mentorship-value**: 导师指出盲点的价值
- **cognitive-bias-investment**: 克服认知偏差的理性思维

### 政治与国际关系
- **constitutional-democracy-evolution**: 宪政民主制的渐进演化路径
- **us-hard-power-mechanism-analysis**: 美国硬实力运作机制分析
- **us-china-policy-analysis**: 中美关系四大派别分析框架
- **us-order-tier-classification**: 美国秩序三层市场结构
- **atlantic-economy-formation-analysis**: 大西洋经济体系形成机制
- **rational-cultural-reconstruction-and-consensus**: 理性文化重建与社会共识

### 宏观经济
- **macroeconomic-savings-investment-framework**: 储蓄投资四象限框架
- **lewis-turning-point-economic-stages**: 刘易斯拐点三阶段理论
- **virtual-real-economy-integration**: 虚拟实体经济融合视角

### 书籍与阅读
- **book-recommendation-principles**: 基于个人偏好的书籍推荐原则
- **book-core-theme-framework**: 书籍核心议题架构分析
- **western-civilization-reading-guide**: 西方文明史核心阅读书目
- **chinese-english-civilization-terminology**: 文明研究术语中英对照
- **chinese-civilization-research-bibliography**: 中国文明研究分级阅读体系
- **publisher-metadata-extraction**: 出版商元数据提取

## 如何使用

这些技能可以通过以下方式调用：

1. **直接引用**：在对话中明确提及需要使用的技能名称，例如"请使用 value-investing-core-principles 技能帮我分析这只股票"

2. **场景触发**：描述你的任务或问题，系统会根据技能描述自动匹配最相关的技能。例如：
   - "我想了解为什么现代化起源于西方而不是中国" → 触发 modernization-causal-chain-analysis
   - "如何判断一个基金经理是运气好还是真的有实力" → 触发 investment-manager-luck-vs-skill-evaluation
   - "帮我设计一个利益深度对齐的基金报酬结构" → 触发 buffett-partnership-compensation-structure

3. **组合使用**：复杂问题可能需要多个技能配合使用。例如分析中国未来投资机会，可能需要同时使用：
   - china-economic-analysis（经济分析）
   - china-engineer-dividend-assessment（工程师红利）
   - civilization-based-investment-framework（文明投资框架）
   - value-investing-core-principles（价值投资原则）

4. **学习路径**：如果你想系统学习某个领域，可以按照技能的逻辑顺序依次使用。例如学习价值投资：
   - value-investing-career-framework（职业入门）
   - value-investing-core-principles（核心原则）
   - value-investing-screening-workflow（筛选流程）
   - earnings-quality-valuation-framework（估值框架）
   - extreme-drawdown-competence-verification（能力验证）
```