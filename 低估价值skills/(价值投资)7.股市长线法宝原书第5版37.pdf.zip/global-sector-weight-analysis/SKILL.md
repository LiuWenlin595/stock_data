---
name: global-sector-weight-analysis
description: Analyze global equity market sector weight distributions across regions (US, Europe, Japan, Emerging Markets) for index construction, portfolio benchmarking, and understanding regional market structure differences. Use when comparing sector concentrations or analyzing regional market compositions as of 2013 baseline.
---

# Global Sector Weight Distribution Analysis

## When to Use
- Constructing or analyzing global/regional equity indices
- Comparing sector allocations across geographic markets
- Understanding regional market structural differences
- Benchmarking portfolio sector weights against market caps

## Global Baseline (2013)
| Sector | Global Weight |
|--------|--------------|
| Financials | 21.2% |
| Information Technology | 12.2% |
| Consumer Discretionary | 11.4% |
| Consumer Staples | 10.6% |
| Industrials | 10.5% |
| Healthcare | 10.2% |
| Energy | 10.1% |
| Materials | 6.1% |
| Telecommunications | 4.3% |
| Utilities | 3.3% |

## Regional Variations

### United States
- **IT dominant**: 18.0% (vs 12.2% global)
- **Financials**: 16.7% (below global average post-2008)
- Note: Financials dropped from 22% pre-crisis to 16.7%

### EAFE (Europe, Australasia, Far East)
- **Financials heavy**: 25.2%
- Reflects European banking concentration

### Japan
- **Consumer Discretionary**: 21.4% (Toyota effect)
- Unique sector concentration vs global norms

### Emerging Markets
- **Financials**: 27.9% (China big-four banks impact)
- Highest financial sector concentration globally

### Europe
- **Financials**: 21.4%
- **Consumer Staples**: 14.6% (above global average)

## Application
Use these weights to:
1. Identify regional sector over/underweights in portfolios
2. Understand index composition biases
3. Assess geographic diversification effectiveness