---
name: developed-country-demographic-reversal
description: Analyze demographic age structure reversal in developed countries when baby boomers age, fertility rates drop below replacement level (2.1), and medical technology extends lifespans. Use this to predict long-term social and investment implications for Japan, Southern Europe (Greece, Spain, Portugal), and other aging societies.
---

# Developed Country Demographic Reversal Analysis

## When to Use
- Analyzing long-term demographic trends in developed markets
- Predicting age structure shifts in Japan, Southern Europe, and similar economies
- Assessing implications of aging populations on economic growth and investment

## Execution Steps

### 1. Verify Prerequisites
Confirm all three conditions are met:
- **Baby boom cohort aging**: Post-WWII generation entering 70+ age bracket
- **Fertility below replacement**: Rate sustained below 2.1 (Southern Europe ~1.5, East Asia ~1.1-1.3)
- **Medical technology impact**: Elderly life expectancy growing ~2.5 years per decade since 1950

### 2. Calculate Reversal Timeline
- Track cohort survival: Baby boomers (born 1946-1964) reaching age 70-80 by 2020-2040
- Monitor youth cohort size: Count population under 15 vs over 80
- **Reversal threshold**: When 80+ population exceeds under-15 population

### 3. Identify Affected Regions
Priority regions showing reversal first:
- **Japan**: Already in advanced reversal stage
- **Southern Europe**: Greece, Spain, Portugal (fertility 1.3-1.5)
- **Other developed**: Italy, Germany, South Korea, Taiwan

### 4. Assess Investment Implications
- Age-dense cohort shifts to 70-80 year bracket
- Healthcare and senior living demand surge
- Consumer staples (tobacco, beverages) historically outperform in aging societies
- Labor force contraction pressures automation and immigration policies

## Key Variables
- Fertility rate (replacement level: 2.1)
- Life expectancy growth rate (2.5 years/decade in developed nations)
- Age dense zone (shifts from young adults to 70-80 years)

## Output
Structural prediction: By mid-21st century, {country} will show inverted age pyramid with 80+ population exceeding under-15 population, creating historically unprecedented demographic structure.