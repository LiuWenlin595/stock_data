---
name: long-term-equity-investment-analysis
description: Evaluate long-term equity investment opportunities by identifying historically outperforming sectors (consumer staples, healthcare), quantifying top company return premiums (19% vs 10% market average), and assessing active management's ability to capture these returns. Use for long-term portfolio construction, stock selection, and active vs passive investment decisions spanning multi-decade horizons.
---

# Long-Term Equity Investment Analysis

## When to Use
- Building long-term buy-and-hold portfolios (10+ years)
- Selecting individual stocks for multi-decade appreciation
- Deciding between active management vs passive indexing
- Analyzing sector allocation for long-term wealth creation

## Part 1: Identify Winning Industries (1957-2012)

### Top Performing Sectors
Historical analysis of S&P 500 original constituents (1957-2012) shows clear sector dominance:

**Consumer Staples (Dominant)**
- Tobacco: Philip Morris/Altria
- Beverages: Coca-Cola, PepsiCo
- Food: Heinz, General Mills, Hershey
- Household: Colgate-Palmolive, Procter & Gamble
- **Representation**: 11 of top 20 companies

**Healthcare (Strong)**
- Pharmaceuticals: Abbott, Bristol-Myers Squibb, Merck, Pfizer
- **Representation**: 4 of top 20 companies

**Others**
- Industrials, Energy, Utilities, Financials (limited representation)

### Key Insight
Demand stability drives long-term outperformance. Consumer staples and healthcare show recession-resistant, consistent demand patterns.

## Part 2: Quantify Return Premiums

### Top Company Performance (Philip Morris Case Study)
**1957-2012 Period:**
- Annualized return: 19.47%
- S&P 500 return: 10.07%
- **Premium**: ~2x market average
- $1,000 investment growth: ~$20 million (vs $191,000 for index)

**1925-2012 Period:**
- Annualized return: 17.3%
- Market average: 9.6%
- $1,000 investment growth: >$1 billion

### Success Drivers
1. **Brand power**: Global recognition (Marlboro)
2. **Reinvestment**: Consistent dividend reinvestment
3. **Acquisition strategy**: Absorbed 10+ original S&P 500 companies

## Part 3: Evaluate Active Management

### Historical Performance (1971-2012)
**All Funds Average:**
- Return: 9.23%
- Wilshire 5000: 10.23%
- S&P 500: 10.11%
- **Result**: Underperformance by ~1% annually

**Survivorship Bias Note:**
- Surviving funds only: +0.25% vs Wilshire 5000
- But only 86 of 1,000 funds survived
- **Net returns**: Lower after sales/redemption fees

### Exception Periods
Active funds outperformed during:
- **1975-1983 small-cap boom**: Small-caps returned 35.32% annually
- Many managers tilted to small-caps during this period

## Decision Framework

### For Stock Selection
1. Prioritize consumer staples and healthcare sectors
2. Seek companies with strong brand moats
3. Target consistent dividend growers
4. Hold periods: Minimum 20-30 years

### For Investment Strategy
1. **Passive vs Active**: Index funds preferred for broad exposure (lower costs, better tax efficiency)
2. **Active only if**: Specialized small-cap exposure or specific sector focus during cyclical uptrends
3. **Cost matters**: 1% annual fee compounds to significant drag over decades

## Key Metrics
- Long-term market average: ~9-10% annually
- Top decile companies: ~17-19% annually
- Active fund drag: ~1% annually (before fees)