---
name: macro-events-market-impact
description: Analyze stock market reactions to macro events including political elections (party differences), wars and conflicts (short-term volatility patterns and long-term cycles), and geopolitical crises. Use when assessing market behavior during elections, military conflicts, or geopolitical tensions to inform tactical and strategic investment decisions.
---

# Macro Events Market Impact Analysis

## When to Use
- Assessing market behavior during election periods
- Analyzing portfolio adjustments during war or conflict
- Understanding volatility patterns during geopolitical crises
- Comparing long-term returns across war and peace periods

## Part 1: Political Elections

### Short-Term Reaction (Election Day)
**Historical Pattern (Since 1888):**
- Democratic win: Market -0.6% average
- Republican win: Market +0.7% average
- Post-WWII: Republican advantage weakened

### Long-Term Returns by Party (1888-2012)
| Metric | Democratic | Republican |
|--------|-----------|------------|
| Nominal Return | 10.80% | 8.47% |
| Inflation | 3.86% | 1.90% |
| **Real Return** | **6.80%** | **6.45%** |

**Conclusion**: Real returns nearly identical; inflation difference explains nominal gap.

### Modern Era (1952-2012)
- Democratic nominal: 14.20%
- Republican nominal: 8.37%
- Democratic real: 10.48%
- Republican real: 4.45%
- **Note**: Congressional control also matters (e.g., Clinton + Republican Congress)

## Part 2: War vs. Peace Cycles

### Return Analysis (Since 1885)
**Time Allocation**: ~20% war, ~80% peace

**Nominal Returns**: Similar in both periods

**Inflation Impact**:
- War periods: 6% average inflation
- Peace periods: <2% average inflation
- **Result**: Real returns significantly higher in peace periods

### Volatility Patterns
**General Rule**: Peace periods show higher volatility than war periods

**Exceptions**:
- WWI: Higher volatility
- Gulf War: Brief spike
- **Highest volatility periods**: 1929-1933 (pre-WWII), 2008-2009 (financial crisis) - both peacetime

## Part 3: Specific Conflict Patterns

### Phase 1: Initial Shock (Decline)
**Korean War (1950)**: -4.65% (day 1), max -12%
**Gulf War (1990)**: -18% (oil shock + recession)
**9/11 (2001)**: -16% (9606 to 8062)
**Iraq War prelude (2003)**: Decline to 7524 (fear-based)

### Phase 2: Macro Policy Dominance
Market driven by Federal Reserve policy, inflation, and interest rates rather than conflict news.

**Vietnam War Example**:
- Gulf of Tonkin: +18% over 18 months
- Fed tightening: -30% decline
- 1970 recession: -25% from war-start levels

### Phase 3: Resolution Rally
Once outcome is clear, markets rebound sharply.

**Gulf War (1991)**:
- Jan 17 attack start: Bonds and stocks surge
- Oil drops $29→$20/barrel
- Day 2: Dow +4.4%
- War end (Feb 28): +18% from start

**9/11 Response**:
- One week post-attack: Rebound begins
- Fed aggressive expansion
- 3 months: +26.3% (8062→10184)

**Iraq War (2003)**:
- Post-invasion: Continuous rise despite ongoing violence

### Risk Warning
War gains can be erased by subsequent economic cycles (2003-2007 bull market +17.5% annualized lost in 2008 crisis).

## Application Framework

### For Elections
- Ignore short-term reaction (day/week)
- Long-term: Party matters less than inflation control
- Consider Congressional gridlock as potential positive

### For Conflicts
1. **Don't sell into initial panic** (Phase 1)
2. **Watch the Fed** (Phase 2 determinant)
3. **Avoid chasing war rallies** (Phase 3 often marks local top)
4. **Focus on 3+ year horizon**: Conflicts rarely alter long-term trends