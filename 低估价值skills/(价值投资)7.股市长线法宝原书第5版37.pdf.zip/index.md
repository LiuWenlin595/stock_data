```markdown
# 全球投资与金融市场分析技能集

本技能集源自专业金融著作《70C1Dd6C-175D-4358-B040-2199290C4288》，涵盖股票市场指数、投资组合管理、量化策略、风险管理、宏观经济分析及行为金融学等核心领域。帮助用户进行指数化投资、资产配置、市场择时、衍生品交易及长期财富规划等专业任务。

## Available Skills

| Skill | Description | Use When |
|-------|-------------|----------|
| [global-sector-weight-analysis](global-sector-weight-analysis/SKILL.md) | 分析全球股票市场行业权重分布（美国、欧洲、日本、新兴市场） | 构建指数、组合基准比较、理解区域市场结构差异 |
| [vix-panic-threshold-assessment](vix-panic-threshold-assessment/SKILL.md) | 基于VIX指数阈值（50/80/150+）判定市场危机严重程度 | 市场情绪监测、波动率交易、系统性危机识别 |
| [circuit-breaker-mechanisms](circuit-breaker-mechanisms/SKILL.md) | 了解纽交所交易熔断机制的历史演变与设计原理 | 分析极端波动事件、研究市场微观结构 |
| [dow-jones-index-calculation](dow-jones-index-calculation/SKILL.md) | 计算道琼斯工业平均指数价格加权值及除数调整 | 实时计算DJIA点位、处理成分股变更或拆股 |
| [moving-average-market-timing](moving-average-market-timing/SKILL.md) | 执行200日移动平均线市场择时策略 | 构建趋势跟踪系统、比较择时与买入持有策略 |
| [money-market-fund-risk-monitoring](money-market-fund-risk-monitoring/SKILL.md) | 识别货币市场基金"破净"的系统性风险阈值 | 投资货币基金、评估短期流动性工具安全性 |
| [fundamental-weighted-index-construction](fundamental-weighted-index-construction/SKILL.md) | 基于基本面指标构建避免泡沫的被动型股票指数 | 构建低买高卖的智能贝塔指数、年度再平衡 |
| [emerging-market-productivity-retirement-scenarios](emerging-market-productivity-retirement-scenarios/SKILL.md) | 分析新兴市场生产率增长对发达国家退休政策的影响 | 长期经济预测、退休政策制定、养老金规划 |
| [index-futures-cash-settlement](index-futures-cash-settlement/SKILL.md) | 计算股指期货合约持有至结算日的现金结算盈亏 | 合约接近结算日、计算到期盈亏、理解现金结算机制 |
| [emerging-market-infrastructure-forecast](emerging-market-infrastructure-forecast/SKILL.md) | 预测新兴市场未来20年基础设施投资规模与机会 | 分析新兴市场增长、寻找美国公司投资机会 |
| [covered-call-strategy](covered-call-strategy/SKILL.md) | 执行备兑看涨期权策略获取期权费收入 | 持有股票且预期市场不会暴涨、震荡市增强收益 |
| [interbank-liquidity-spread-analysis](interbank-liquidity-spread-analysis/SKILL.md) | 通过联邦基金利率与LIBOR息差判断市场压力水平 | 评估流动性压力、银行间信用风险、危机预警 |
| [stock-index-fundamentals](stock-index-fundamentals/SKILL.md) | 综合理解主要股票指数的特征差异与计算方法 | 比较指数投资特征、选择ETF跟踪标的 |
| [nasdaq-index-overview](nasdaq-index-overview/SKILL.md) | 理解纳斯达克指数的定义、计算方法及市场地位演变 | 分析科技股表现、回顾2000年互联网泡沫 |
| [market-volatility-media-attribution-analysis](market-volatility-media-attribution-analysis/SKILL.md) | 分析金融媒体对市场波动的归因分歧与可信度 | 单日大幅波动、多新闻事件并存时的归因验证 |
| [index-arbitrage-strategy](index-arbitrage-strategy/SKILL.md) | 执行股指期货与ETF的指数套利交易 | 发现期现价格偏离、预测市场开盘方向 |
| [siegel-constant-long-term-return](siegel-constant-long-term-return/SKILL.md) | 基于Siegel常数（6.6%）估算美股长期实际回报率 | 20年以上投资规划、退休资金测算、战略配置 |
| [retirement-age-prediction](retirement-age-prediction/SKILL.md) | 预测特定情境下发达国家退休年龄的变化趋势 | 评估退休政策影响、规划个人退休时间 |
| [stock-inflation-hedge-timing](stock-inflation-hedge-timing/SKILL.md) | 区分短期与长期持有期下股票的抗通胀表现 | 评估股票作为通胀对冲工具的适用性 |
| [global-demographic-economic-framework](global-demographic-economic-framework/SKILL.md) | 分析全球化背景下人口老龄化对经济与资产的影响 | 预测资产价格、规划退休配置、分析政府赤字 |
| [economic-cycle-market-timing](economic-cycle-market-timing/SKILL.md) | 基于经济周期预测在股票和债券间进行战术配置 | 获取衰退前后4个月切换的年化5%超额收益 |
| [developed-country-demographic-reversal](developed-country-demographic-reversal/SKILL.md) | 分析发达国家人口年龄结构逆转的影响 | 婴儿潮老龄化、生育率低于更替水平、寿命延长 |
| [macro-events-market-impact](macro-events-market-impact/SKILL.md) | 分析宏观事件（选举、战争、地缘政治危机）对股市的影响 | 评估政治事件、冲突的短期波动与长期周期 |
| [quantitative-trading-strategies](quantitative-trading-strategies/SKILL.md) | 执行短期动量、长期逆向反转和趋势通道策略 | 战术配置决策、技术进出场时机选择 |
| [earnings-expectations-market-reaction](earnings-expectations-market-reaction/SKILL.md) | 分析季度盈利惊喜并预测股价反应 | 财报季事件驱动交易、风险管理 |
| [long-term-wealth-accumulation](long-term-wealth-accumulation/SKILL.md) | 通过成本最小化和税收高效投资建立长期财富 | 退休规划、20年以上投资、评估费用结构 |
| [behavioral-finance-bias-mitigation](behavioral-finance-bias-mitigation/SKILL.md) | 识别并抵消投资决策中的认知偏差 | 投资者表现出从众行为、不愿实现亏损时 |
| [index-options-trading](index-options-trading/SKILL.md) | 交易标准普尔500等指数期权，计算盈亏平衡点 | 预期市场方向、需要杠杆但限制最大损失 |
| [long-term-equity-investment-analysis](long-term-equity-investment-analysis/SKILL.md) | 识别长期跑赢的行业和顶级公司的超额收益 | 评估长期股权投资机会、量化顶级公司溢价 |
| [value-dividend-factor-investing](value-dividend-factor-investing/SKILL.md) | 使用价值和股息因子构建低波动长期核心配置 | 寻求因子溢价、高股息策略、基本面加权 |
| [international-portfolio-diversification](international-portfolio-diversification/SKILL.md) | 利用全球相关性分析优化股票配置降低波动 | 单一国家集中度超80%、寻求地理分散 |
| [macro-valuation-economic-cycles](macro-valuation-economic-cycles/SKILL.md) | 应用托宾Q进行资本配置，根据经济周期调整策略 | 企业估值、资本预算、宏观择时决策 |
| [financial-crisis-spread-monitoring](financial-crisis-spread-monitoring/SKILL.md) | 通过TED利差等指标识别流动性冻结和系统性危机 | 监测金融稳定性、评估信贷压力、宏观审慎监管 |
| [gold-investment-characteristics](gold-investment-characteristics/SKILL.md) | 基于1802-2012年数据评估黄金长期投资价值 | 分析黄金购买力保值能力、通胀对冲 |
| [calendar-based-market-anomalies](calendar-based-market-anomalies/SKILL.md) | 分析星期效应、九月效应等股票市场日历异象 | 评估市场时机、解释历史波动聚集 |
| [global-equity-long-term-premium](global-equity-long-term-premium/SKILL.md) | 应用"乐观主义者的胜利"百年实证法则 | 20年以上长期投资、跨国配置、验证Siegel常数全球适用性 |
| [mbs-rating-model-flaw-analysis](mbs-rating-model-flaw-analysis/SKILL.md) | 分析房地产抵押贷款支持证券评级模型的结构性缺陷 | 质疑AAA级MBS真实风险、复盘2008年评级失效 |

## Quick Navigation

### 指数与基准
- **[dow-jones-index-calculation]**: 道琼斯指数计算与除数调整
- **[nasdaq-index-overview]**: 纳斯达克指数特征与历史演变
- **[stock-index-fundamentals]**: 主要股票指数综合比较
- **[global-sector-weight-analysis]**: 全球行业权重分布分析

### 投资策略与择时
- **[moving-average-market-timing]**: 200日均线趋势跟踪策略
- **[economic-cycle-market-timing]**: 基于经济周期的股债轮动
- **[quantitative-trading-strategies]**: 动量、反转与趋势通道策略
- **[value-dividend-factor-investing]**: 价值与股息因子投资
- **[calendar-based-market-anomalies]**: 日历异象与季节性分析

### 衍生品与套利
- **[index-futures-cash-settlement]**: 股指期货现金结算计算
- **[covered-call-strategy]**: 备兑看涨期权收益增强
- **[index-options-trading]**: 指数期权交易与定价
- **[index-arbitrage-strategy]**: 期现套利与开盘预测

### 风险管理与危机监测
- **[vix-panic-threshold-assessment]**: VIX恐慌阈值危机判定
- **[circuit-breaker-mechanisms]**: 熔断机制历史与设计
- **[interbank-liquidity-spread-analysis]**: 银行间流动性息差分析
- **[financial-crisis-spread-monitoring]**: 金融危机量化指标监测
- **[money-market-fund-risk-monitoring]**: 货币基金系统性风险识别

### 长期财富与退休规划
- **[siegel-constant-long-term-return]**: Siegel常数长期回报估算
- **[long-term-wealth-accumulation]**: 成本最小化财富积累
- **[retirement-age-prediction]**: 退休年龄趋势预测
- **[emerging-market-productivity-retirement-scenarios]**: 生产率与退休政策情景分析
- **[global-demographic-economic-framework]**: 人口老龄化经济影响框架

### 资产配置与多元化
- **[international-portfolio-diversification]**: 国际组合分散化优化
- **[fundamental-weighted-index-construction]**: 基本面加权指数构建
- **[stock-inflation-hedge-timing]**: 股票抗通胀持有期分析
- **[gold-investment-characteristics]**: 黄金长期投资价值评估

### 行为与决策
- **[behavioral-finance-bias-mitigation]**: 认知偏差识别与抵消
- **[earnings-expectations-market-reaction]**: 盈利预期与股价反应
- **[market-volatility-media-attribution-analysis]**: 媒体波动归因可信度分析

### 宏观与专题研究
- **[macro-events-market-impact]**: 宏观事件市场影响分析
- **[macro-valuation-economic-cycles]**: 托宾Q与经济周期估值
- **[developed-country-demographic-reversal]**: 发达国家人口结构逆转
- **[emerging-market-infrastructure-forecast]**: 新兴市场基础设施预测
- **[long-term-equity-investment-analysis]**: 长期股权投资机会识别
- **[global-equity-long-term-premium]**: 全球股票长期风险溢价
- **[mbs-rating-model-flaw-analysis]**: MBS评级模型缺陷分析

## How to Use

1. **识别需求场景**：根据当前任务确定所属类别（指数计算、投资策略、风险管理等）

2. **匹配技能**：在对应类别中查找最匹配的技能，阅读其"Use When"触发条件

3. **调用技能**：通过技能路径访问详细文档，获取具体计算方法、参数设置和操作步骤

4. **交叉验证**：复杂决策可结合多个技能（如择时策略+风险管理+行为偏差识别）

5. **注意时效性**：涉及市场数据的技能需确认历史参数是否适用于当前市场环境
```