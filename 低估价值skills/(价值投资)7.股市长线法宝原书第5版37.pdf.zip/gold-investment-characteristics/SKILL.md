---
name: gold-investment-characteristics
description: Evaluate gold as a long-term investment asset for inflation hedging and portfolio diversification based on 1802-2012 historical data. Use when analyzing gold's purchasing power preservation capabilities and its impact on long-term portfolio returns.
---

# Gold Investment Characteristics Analysis

## When to Use
- Evaluating gold as an inflation hedge
- Assessing gold's role in long-term portfolios
- Comparing gold's returns to other asset classes over multi-decade periods
- Analyzing purchasing power preservation strategies

## Historical Performance (1802-2012)

### Inflation Hedge Effectiveness
**Value Preservation**:
- 1802: $1 gold → 2012: $86.40
- Price level increase: 19.12x (inflation)
- **Result**: Gold preserved and exceeded purchasing power

**Conclusion**: Gold effectively protects against inflation over very long periods (centuries).

### Return Characteristics
**Absolute Growth**: 86.4x over 210 years
**Comparison**: Significantly lags equities (which compound at higher rates)
**Income**: Zero dividend/yield (unlike stocks)

## Portfolio Impact

### Diversification Benefits
- Non-correlated with equities
- Crisis hedge (short-term flight to safety)

### Long-Term Drag
- No compounding income stream
- Storage costs
- **Historical result**: Holding gold reduces long-term portfolio returns compared to equity-heavy allocations

## Strategic Application

### When to Include Gold
1. **Hyperinflation protection**: Extreme monetary instability scenarios
2. **Short-term hedging**: Geopolitical crisis periods (temporary allocation)
3. **Currency debasement hedge**: When fiat currency credibility questioned

### When to Avoid Heavy Allocation
1. **Long-term wealth building**: Equities historically superior
2. **Income needs**: Gold generates no cash flow
3. **Moderate inflation periods**: 2-3% inflation handled better by equity cash flow growth

## Key Metric
**Real return expectation**: Preservation of capital only, not growth. Gold maintains purchasing power but does not generate real wealth accretion over long periods.