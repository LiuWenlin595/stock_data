# Conrail私有化财务细节

## 关键变量
- `government_investment`: 政府累计投入超70亿美元（7.0十亿美元）
- `ipo_amount`: IPO募资16亿美元（1.6十亿美元）
- `initial_price`: 股票发行价为每股10美元
- `current_price`: 至作者写作时股价已涨至46美元

## 投资回报率计算
使用公式：
```
ROI = (current_price / initial_price) - 1
```
代入数据：
```
ROI = (46 / 10) - 1 = 3.6 → 360%
```

## 历史背景补充
- Conrail由Penn Central及美国东北部5家破产铁路公司残余部分于1976年合并成立；
- 里根政府推动私有化，认为这是终结企业持续寻求“财政施舍”的唯一办法；
- 国会否决了将其出售给Norfolk Southern等现有铁路公司的提案，坚持公众发行以确保公平与市场定价。