---
name: Cultural Adaptation of Food Recipes
description: 将异域食谱通过成分改良与标准化包装转化为本地市场接受的国民级调味品。当存在对某食材（如番茄）的毒性误解，且已有可借鉴的异国配方原型时使用本技能。
---

# Cultural Adaptation of Food Recipes

## When to Use
Use this skill when:
- A target ingredient (e.g., tomato) faces cultural resistance or public misconceptions about toxicity
- An existing foreign recipe prototype (e.g., ketsiap) provides a structural basis for adaptation
- Standardized packaging (e.g., glass bottles) is available to build consumer trust

## How to Execute
1. **Identify the original foreign recipe** and its core components.
2. **Replace culturally problematic or inaccessible ingredients** with locally acceptable alternatives (e.g., substitute fermented fish with tomatoes).
3. **Address public misconceptions** through demonstrative actions or trusted endorsements if necessary.
4. **Package the product in transparent, standardized containers** (e.g., glass bottles) to signal purity, consistency, and safety.
5. **Scale production and distribution** by:
   - Diversifying product lines around the adapted recipe
   - Establishing regional manufacturing facilities
   - Building direct relationships with agricultural suppliers
   - Deploying global sales and distribution networks
6. **Position the product as a versatile condiment** to encourage broad culinary adoption.

> Note: This approach is specific to tomato-based or similar vegetable-derived condiments and requires historical context of ingredient skepticism.