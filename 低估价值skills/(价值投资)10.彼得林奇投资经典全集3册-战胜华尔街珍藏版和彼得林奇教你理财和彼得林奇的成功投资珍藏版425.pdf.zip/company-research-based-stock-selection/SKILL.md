---
name: Company Research-Based Stock Selection
description: Use this skill when a fundamental analyst, portfolio manager, or long-term investor seeks to generate long-term alpha by focusing on deep company-level understanding rather than stock price movements. Apply it specifically when evaluating equities in markets with adequate disclosure quality and when direct access to management or IR is feasible.
---

# Company Research-Based Stock Selection

Follow this structured workflow to identify and validate investment opportunities through rigorous company research:

## 1. Collect Public Information
- Gather and read annual reports, quarterly filings, prospectuses, regulatory disclosures, and official press releases.
- Consult foundational reference materials such as *Standard & Poor’s Stock Guide*.
- Review internal analyst summaries from prior interactions with the company.

## 2. Expand Research Leads
- Engage securities analysts and investor relations (IR) personnel to uncover supplementary insights.
- Identify anomalies, inconsistencies, or strategic shifts that warrant deeper investigation.

## 3. Verify Through Primary Sources
- Contact company representatives directly via phone or in-person meetings.
- Focus inquiries on business model sustainability, competitive positioning, capital allocation, and management strategy.

## 4. Document and Review Findings
- Immediately after each interaction, record in a loose-leaf notebook:
  - Company name
  - Current stock price
  - 1–2 sentence summary of key takeaways
- Periodically revisit notes to reinforce original investment theses and avoid emotional trading.

## 5. Allocate Time Strategically
- Minimize low-value activities (e.g., extended social lunches) to prioritize direct company outreach.
- Dedicate time to conversations with management over monitoring short-term price fluctuations.

> **Core Principle**: "The key to successful investing is to focus on the company, not the stock." Do not let short-term market noise override your assessment of intrinsic value.