---
name: Stock Selection as Art, Not Science
description: Apply the core philosophy that successful stock selection relies on business understanding, common sense, and independent thinking—not complex quantitative models. Use this skill when an investor overemphasizes statistical or computational methods for picking stocks, especially if they believe advanced math or supercomputers are necessary for success.
---

# Stock Selection as Art, Not Science

## When to Use This Skill
Use this skill when:
- An investor attempts to apply overly complex statistical models or high-powered computing to stock selection.
- There is a belief that advanced mathematics is required to succeed in investing.
- Investment decisions ignore fundamental business realities in favor of abstract market theories.
- The user questions whether human judgment still matters in modern investing.

## How to Apply This Philosophy

1. **Reject the myth of mathematical necessity**
   - Confirm that basic arithmetic (equivalent to elementary school level) is sufficient for evaluating companies.
   - Example: Understanding that a company with ¥1 billion cash and ¥500 million debt has net cash of ¥500 million requires no advanced math.

2. **Prioritize relevant disciplines**
   - Emphasize history, philosophy, and logic over statistics.
   - Use logic to detect “Wall Street-specific illogicality”—such as debating stock price movements without examining actual business operations.

3. **Adopt a grounded investigative mindset**
   - Avoid theoretical debates disconnected from reality (like ancient Greeks arguing how many teeth a horse has without counting).
   - Instead, directly study the company’s products, management, financial health, and competitive position.

4. **Challenge absolute market theories**
   - Recognize that the Efficient Market Hypothesis and Random Walk Theory, while useful frameworks, do not eliminate the value of deep fundamental analysis and human insight.

5. **Focus on business essence**
   - Evaluate what the company actually does, how it makes money, and whether its strategy is sound.
   - Trust independent thinking over consensus forecasts or algorithmic signals.

> **Result**: Investors should cultivate commercial intuition and critical thinking rather than seeking a mathematical formula for stock selection.