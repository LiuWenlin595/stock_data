# Historical Case Studies: Why Macro Predictions Fail Without Stock Selection

## Real-World Examples from Investment History

### 1. Florida Real Estate Boom
- **Macro Prediction**: Correctly anticipated real estate boom in Florida
- **Stock Chosen**: Radice Corporation
- **Outcome**: Lost 95% of investment despite being right about the trend

### 2. Computer Industry Growth (Early 1980s)
- **Macro Prediction**: Correctly foresaw expansion of computer industry
- **Stock Chosen**: Fortune Systems
- **Outcome**: Stock price fell from $22 (1983) to $1.875 (1984)

### 3. Airline Industry Recovery
- **Macro Prediction**: Believed airlines would rebound
- **Stocks Chosen**: People Express (went bankrupt), Pan Am (fell from $9 to $4)
- **Outcome**: Severe losses despite correct industry outlook

### 4. Steel Industry Rebound (1980s)
- **Macro Prediction**: Anticipated recovery in steel sector
- **Random Pick**: LTV Corporation — stock dropped from $26.50 (1981) to $1.125 (1986)
- **Contrast**: Nucor Corporation — rose from $10 to $50 in same period

## Key Takeaway
Even with perfect macro timing, poor stock selection leads to failure. Success comes from deep company-level analysis, not top-down forecasting.