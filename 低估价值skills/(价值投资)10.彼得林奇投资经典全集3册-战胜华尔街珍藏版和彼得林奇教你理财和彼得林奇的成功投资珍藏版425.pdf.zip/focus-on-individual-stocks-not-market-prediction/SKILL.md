---
name: Focus on Individual Stocks, Not Market Prediction
description: Use this skill when an investor is considering buying stocks based on predictions of overall market trends (e.g., bull/bear markets) or macroeconomic conditions (e.g., economic booms or recessions). This skill guides the user to shift focus from market forecasting to analyzing the fundamentals of specific companies, as historical evidence shows that even accurate macro predictions often lead to losses if the wrong stocks are chosen.
---

# Focus on Individual Stocks, Not Market Prediction

## When to Use This Skill
Use this skill whenever you find yourself making investment decisions primarily based on:
- Expectations about whether the overall stock market will rise or fall
- Forecasts of macroeconomic trends (e.g., interest rates, GDP growth, industry cycles)
- Belief that a booming sector will automatically lift all stocks within it

This approach is especially relevant for individual investors, stock investors, and value investors who are willing to research company fundamentals.

## How to Execute

1. **Stop trying to predict the market or economy.** Acknowledge that even accurate macro forecasts do not guarantee profitable stock picks.

2. **Shift your focus to individual companies.** Ask concrete questions about specific businesses, such as:
   - "How is WestPoint-Pepperell’s bedding business performing?"
   - "Are Taco Bell’s new Super Burritos selling well?"

3. **Evaluate each company on its own merits**, including:
   - Profitability and cash flow
   - Competitive advantages and product quality
   - Management competence
   - Valuation relative to intrinsic worth

4. **Only buy a stock if the company meets your investment criteria**, regardless of what the broader market or economy is doing.

5. **Remember**: The stock market will “take care of itself.” Your job is to find companies you understand and believe in.

> ⚠️ Do not use this skill if you rely solely on technical analysis, engage in short-term speculation, or employ macro-driven hedging strategies—this method is designed for fundamental, long-term investors.