# 日常生活中常见的上市公司示例（按场景分类）

## 起床
- 通用电气（闹钟）
- 美标（卫浴）
- 宝洁（牙膏）
- 吉列（剃须刀，隶属宝洁）
- 高露洁（牙刷）

## 穿衣
- Fruit of the Loom（内衣，隶属伯克希尔·哈撒韦）
- Gap（服饰）
- Galey（布料供应商）
- 杜邦（纤维材料）

## 支付与金融
- 花旗银行（VISA卡发行方之一）

## 鞋履
- 锐步（Reebok，曾属阿迪达斯，现归Authentic Brands Group；Foot Locker为上市公司）

## 早餐
- 通用磨坊（麦片）
- 凯洛格（玉米片）
- 施格兰（Seagram，历史品牌，现资产分散；橙汁可能来自上市公司如Keurig Dr Pepper）
- 菲利普莫里斯（曾拥有多样食品业务，现专注烟草；安德曼糕点需核实当前归属）
- 吐司大师（Toastmaster，家电品牌，历史上属多家上市公司）

## 家电
- 咖啡壶、微波炉、冰箱等通常由惠而浦、美的集团（A股/H股）、海尔智家等上市公司制造

## 购物
- 沃尔玛、家乐福（Carrefour）、永辉超市等大型连锁超市多为上市公司

## 交通
- 通用汽车（含供应链：伯利恒钢铁已破产，PPG工业、固特异轮胎、美国铝业均为上市公司）
- 埃克森美孚（汽油）
- 安泰保险（车险）
- Laidlaw（校车服务，曾为上市公司，后被收购）

## 教育出版
- 麦格劳-希尔（现为S&P Global一部分）
- 霍顿·米夫林·哈考特（Houghton Mifflin Harcourt，曾上市）
- 西蒙与舒斯特（隶属派拉蒙全球，Paramount Global为上市公司）

## 午餐与快餐
- 雷神公司（Raytheon）不涉及餐饮；原文“Amerada餐饮”疑为笔误（Amerada Hess为能源公司）
- 麦当劳（NYSE: MCD）
- 温迪（Wendy's, NASDAQ: WEN）
- 汉堡王（隶属Restaurant Brands International, NYSE: QSR）
- 可口可乐（NYSE: KO）
- 百事公司（NASDAQ: PEP，旗下含塔可钟、必胜客、肯德基原属百胜，现已分拆；菲多利仍属百事）

## 零食
- 好时公司（NYSE: HSY）
- 箭牌（隶属玛氏，私人企业；但箭牌口香糖在部分市场由上市公司代理）
- 士力架（玛氏公司，私人企业，**例外**）

## 通讯
- 历史电信公司：NYNEX、PacTel（现属AT&T）
- Sprint、MCI（已被T-Mobile、Verizon收购）
- AT&T（NYSE: T）
- 设备制造商如思科（CSCO）、爱立信（ERIC）

## 媒体与娱乐
- 索尼、松下等日本上市公司（电视机）
- 康卡斯特（有线电视，NASDAQ: CMCSA）
- CBS（隶属派拉蒙全球）
- NBC（隶属康卡斯特）
- ABC（隶属迪士尼，NYSE: DIS）
- CNN（隶属华纳兄弟探索，NASDAQ: WBD）
- King World（《奥普拉秀》制作方，已被CBS收购）
- 新闻集团（NASDAQ: NWSA，《辛普森一家》由福克斯广播播出，隶属迪士尼）

> 注：公司结构随并购频繁变动，投资前请核实最新股权与上市状态。