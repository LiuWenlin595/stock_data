---
name: Industry Insider Stock Selection
description: Use this skill when you are a frontline employee in a cyclical industry (e.g., chemicals, tires, real estate, gold/oil/timber/media) and observe clear operational improvements or hidden assets not yet reflected in stock prices. Apply it to identify undervalued public companies based on direct industry insights rather than Wall Street recommendations.
---

# Industry Insider Stock Selection

## When to Use
Use this skill if:
- You work directly in a cyclical industry and have real-time visibility into product demand, pricing, inventory, or capacity changes.
- You notice significant positive shifts such as surging orders, falling inventory, rising prices, or absence of new competitors.
- You suspect the company holds hidden assets (e.g., undervalued real estate, natural resources, or media licenses) recorded at historical cost.

Do **not** use this skill for industries you do not understand or for sectors with highly transparent, real-time public data (e.g., automotive).

## How to Execute

1. **Confirm industry turning-point signals**: 
   - Verify sustained demand recovery (e.g., after years of slump, orders exceed capacity).
   - Observe consistent price increases.
   - Note declining inventory levels.
   - Confirm no new competitors have entered the market.
   - Assess that new capacity requires long lead times (typically 2–3 years), extending profit windows.

2. **Identify hidden assets**:
   - In real estate: check if the company owns prime properties booked at outdated historical costs.
   - In resource/media sectors: look for undeveloped reserves, spectrum rights, or broadcast licenses carried below fair value.

3. **Compare asset value to market price**:
   - Estimate true net asset value per share.
   - Only proceed if estimated asset value per share > current market price per share.

4. **Take action**:
   - Contact your broker to research the specific company’s latest fundamentals.
   - Initiate a position based on your ground-level insight—do not wait for analyst coverage.

5. **Hold for revaluation**:
   - Expect market recognition within 6–12 months as financial results reflect operational improvements.
   - Exit when price approaches or exceeds intrinsic asset value.

> **Note**: This heuristic leverages your informational edge as an insider. Professional analysts often lag behind grassroots observers in detecting early-cycle recoveries.