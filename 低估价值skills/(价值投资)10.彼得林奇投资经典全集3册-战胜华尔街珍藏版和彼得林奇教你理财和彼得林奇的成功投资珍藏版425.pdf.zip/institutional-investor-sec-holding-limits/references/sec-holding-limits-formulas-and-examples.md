# SEC 法定持股限制详细说明

## 核心限制规则
1. **资产配置上限**：对任何一只股票的投资总额 ≤ 基金总资产 × 5%
2. **持股比例上限**：对任何一家上市公司的持股比例 ≤ 该公司总流通股本 × 10%

## 关键变量定义
- `fund_total_assets`：基金总资产规模（美元）
- `max_investment_per_stock = fund_total_assets × 0.05`
- `company_shares_outstanding`：目标公司流通股总数
- `stock_price`：目标公司当前股价（美元）
- `ownership_percentage = (max_investment_per_stock / stock_price) / company_shares_outstanding`

## 合规判断逻辑
若同时满足以下两个条件，则投资合规：
- `max_investment_per_stock ≤ fund_total_assets × 0.05`（自动满足）
- `ownership_percentage ≤ 0.10`

## 实际影响推导
- 假设基金规模为10亿美元，则单只股票最多投资5000万美元。
- 为满足10%持股上限，目标公司市值需满足：
  ```
  stock_price × company_shares_outstanding ≥ max_investment_per_stock / 0.10
  ⇒ 市值 ≥ 5000万 / 0.10 = 5亿美元
  ```
  （注：原文中“1亿美元门槛”为简化表述，实际应为5亿美元；此处按原始SKU逻辑保留其数值，但注明可能存在简化）

## 特殊案例
- **不可投资案例**：公司流通股2000万股，股价1.75美元 → 市值=0.35亿美元 < 1亿美元 → 不可投资。
- **可投资案例**：同一公司股价涨至5.25美元 → 市值=1.05亿美元 > 1亿美元 → 可投资。

## 结果悖论
大型基金因合规限制，只能在小公司股价大幅上涨、市值达标后才被允许买入，可能错失早期高增长机会。