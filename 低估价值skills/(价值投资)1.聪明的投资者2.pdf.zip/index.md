```markdown
# 价值投资与股票分析技能集

本技能集源自专业投资文献（Book ID: Aa32C197-79Ea-4Df2-B1Cf-06A16266B07E），专注于中等公司股票的价值投资策略与资本配置分析。帮助用户评估被低估股票的盈利途径，审查公司金融效率，以及制定合理的投资决策和退出策略。

## Available Skills

| Skill | Description | Use When |
|-------|-------------|----------|
| [cheap-medium-stock-profit-strategies](cheap-medium-stock-profit-strategies/SKILL.md) | 分析持有被低估非成长型中等公司股票的五种盈利途径：股息收益、再投资回报、牛市溢价、价格调整和基本面改善 | 需要分析廉价中等公司股票的获利机制、评估退出策略，或制定价值投资方案时 |
| [financial-efficiency-capital-allocation-review](financial-efficiency-capital-allocation-review/SKILL.md) | 评估上市公司金融效率与资本配置合理性，区分运营效率与金融效率 | 公司运营表现良好但股东回报不足，管理层要求追加资本，或需要审查资本使用是否符合股东最大利益时 |

## Quick Navigation

### 股票盈利策略
- **[cheap-medium-stock-profit-strategies]**: 分析被低估中等公司股票的五种盈利途径及退出时机

### 资本配置与效率分析
- **[financial-efficiency-capital-allocation-review]**: 审查公司金融效率和管理层资本配置决策的合理性

## How to Use

使用这些技能时，请明确告知Claude您需要分析的具体场景：

1. **直接调用技能**：提及技能名称（如"使用 cheap-medium-stock-profit-strategies 分析这只股票"）
2. **描述任务需求**：描述您的分析目标（如"帮我评估这家公司的资本配置效率"或"分析这只被低估的中等公司股票如何盈利"）
3. **提供背景信息**：提供相关公司的财务数据、股票代码或具体的投资情境，以便获得更精准的分析

Claude将根据您的需求自动选择合适的技能框架，引导您完成专业的价值投资分析。
```