---
name: Industry Research “Thick-to-Thin” Cognitive Refinement Methodology
description: 构建新行业认知体系的核心方法论：先通过广泛资料收集“把行业变厚”，再通过抽象提炼“把研究变薄”，最终形成可操作、可迭代的行业分析指标体系。适用于初次接触陌生行业、需从零构建系统性理解的研究场景，不适用于已有成熟框架的复用或短期交易决策。
---

# Industry Research “Thick-to-Thin” Cognitive Refinement Methodology

## When to Use This Skill
- 研究者首次进入一个全新行业领域
- 需要从零开始建立对该行业的系统性认知
- 目标是开发一套原创的、可预测行业趋势的指标体系
- 可获取行业历史资料、企业传记及国际比较数据

**Do not use** when:
- 行业已有成熟分析框架可直接复用
- 决策需求为短期战术判断（如日内交易）

## How to Execute

### Step 1: Expand – “Make the Industry Thick”
Gather comprehensive materials to build contextual depth:
- Collect industry development history
- Study pathways taken by developed countries
- Analyze current state in advanced markets
- Assess China’s current stage and unique conditions
- Read biographies of leading companies, founders, and industry pioneers to “immerse yourself in historical context” and understand competitive dynamics

### Step 2: Condense – “Make the Research Thin”
Distill accumulated knowledge into a lean, actionable framework:
- Abstract core attributes that define the industry’s essence
- Identify a minimal set of key indicators or parameters that capture its operating logic
- Validate your framework through discussions with industry insiders
- Formalize a predictive judgment system based on these indicators
- Commit to continuous iteration: refine observation focus and metrics as real-world evidence accumulates

### Core Principle
> “First make the industry thick, then make the research thin.”

Prioritize cognitive depth over data volume. The goal is simplification without loss of essential insight.

## Output
A validated, iterative industry analysis indicator system ready for forecasting and strategic decision-making.