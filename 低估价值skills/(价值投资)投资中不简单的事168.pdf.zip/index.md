```markdown
# 克劳德价值投资技能库

本技能库源自专业投资著作《5492270B-188F-43E9-81B8-E98Dc0C579Eb》，系统整合了价值投资、基本面分析、行业研究、组合管理、行为金融及组织建设等领域的核心方法论。用户可借助这些技能进行深度企业评估、识别市场错配机会、构建长期投资框架、规避认知偏差，并在A股、港股及全球市场中提升决策质量与长期回报。

## Available Skills

| Skill | Description | Use When |
|-------|-------------|----------|
| [价值投资核心原则与长期主义](价值投资核心原则与长期主义/SKILL.md) | 阐述价值投资的根本理念，包括做时间的朋友、安全边际、定价权等 | 投资者致力于通过企业内在价值增长获取长期回报，而非短期博弈时 |
| [行业与公司四维评估框架](行业与公司四维评估框架/SKILL.md) | 提供行业分析四维度（商业模式、竞争格局、行业空间、门槛）和公司评估双维度（质量、管理层） | 需从宏观到微观全面评估投资标的时 |
| [研究驱动的决策简化方法论](研究驱动的决策简化方法论/SKILL.md) | 提供研究聚焦、三环节循环和时间分配方法论，减少无效决策 | 面临复杂信息环境且需提高决策确定性时 |
| [逆向投资与市场情绪应对](逆向投资与市场情绪应对/SKILL.md) | 提供逆向投资逻辑、市场常态/非常态识别及双重反馈协调原则 | 市场出现极端情绪或需理解定价机制时 |
| [基本面投资三大核心变量](基本面投资三大核心变量/SKILL.md) | 阐述企业价值判断、产业大趋势、系统性风险水平三大变量 | 试图在复杂市场中提高投资确定性与长期收益时 |
| [投资哲学与长期成功原则](投资哲学与长期成功原则/SKILL.md) | 阐述长期成功投资的稳定性、可重复性、可持续性及适配性原则 | 希望建立长期有效的投资体系时 |
| [格雷厄姆价值投资基础与估值原则](格雷厄姆价值投资基础与估值原则/SKILL.md) | 阐述基于客观数据、不依赖市场情绪的格雷厄姆式分析方法 | 希望采用保守、数据驱动的估值方法时 |
| [周期行业投资策略与风险管理](周期行业投资策略与风险管理/SKILL.md) | 提供行业周期策略、价值股下跌表现特征及系统性风险应对 | 面对周期性行业或系统性市场风险时 |
| [投资绩效归因与认知偏差检验](投资绩效归因与认知偏差检验/SKILL.md) | 提供对抗认知偏见的业绩基准归因检验机制 | 基金经理需识别自身偏差或验证研究有效性时 |
| [集中投资与组合管理原则](集中投资与组合管理原则/SKILL.md) | 阐述集中投资、自上而下与自下而上结合选股及管理层评估 | 已完成深度研究且具备高确定性判断时 |
| [价值投资核心选股框架](价值投资核心选股框架/SKILL.md) | 系统化评估“估值、品质、时机”三要素，聚焦“好行业中的好公司” | 需简化选股逻辑、识别高确定性标的或判断买入条件时 |
| [高确定性投资研究体系](高确定性投资研究体系/SKILL.md) | 构建以深度研究和心理检验为核心的高胜率投资体系 | 希望提升投资确定性、验证买入决策或调整心态时 |
| [市场无效性下的长期价值布局策略](市场无效性下的长期价值布局策略/SKILL.md) | 识别A股等低效市场中“基本面强但股价低迷”的错配机会 | 发现优质公司因市场忽视而长期低估且持续盈利时 |
| [牛市中后期防御性资产配置策略](牛市中后期防御性资产配置策略/SKILL.md) | 构建以估值合理、流动性高的行业龙头为核心的防御组合 | 确认多数个股估值显著高于基本面支撑时 |
| [系统性风险下的对冲式逆向投资策略](系统性风险下的对冲式逆向投资策略/SKILL.md) | 通过“买入低估优质股+股指期货对冲”控制回撤并积累资产 | 市场极端下跌、优质股绝对低估但系统性风险未释放时 |
| [机构投资组合的硬性约束机制](机构投资组合的硬性约束机制/SKILL.md) | 强制在行业比例范围内配置，避免极端偏离 | 受托管理社保等需遵守行业比例限制的产品时 |
| [长期投资回报驱动模型](长期投资回报驱动模型/SKILL.md) | 四要素公式分解10年期复利潜力来源 | 计划长期股权投资并关注基本面增长驱动时 |
| [capital-market-efficiency-and-alpha-generation](capital-market-efficiency-and-alpha-generation/SKILL.md) | 判断资本市场有效性及获取阿尔法的难度 | 需评估某市场中专业机构战胜基准的可能性时 |
| [top-down-asset-allocation-and-sector-rotation](top-down-asset-allocation-and-sector-rotation/SKILL.md) | 基于宏观-中观-微观三层逻辑执行资产配置与行业轮动 | 市场处于风格切换期或有明确宏观驱动因素时 |
| [macro-driven-investment-framework-for-fixed-income-background-investors](macro-driven-investment-framework-for-fixed-income-background-investors/SKILL.md) | 帮助固收背景投资者迁移宏观能力至权益投资 | 具有债券投研经验并需管理含权益资产组合时 |
| [2016-2017-market-outlook-and-strategy-framework](2016-2017-market-outlook-and-strategy-framework/SKILL.md) | 提供2016–2017年市场预判与结构性行情应对范式 | 需回溯历史策略或面对类似“分化+盈利改善”环境时 |
| [cyclical-industry-phase-assessment](cyclical-industry-phase-assessment/SKILL.md) | 判断周期性行业所处阶段（底部、上行初期、高点等） | 分析对象属周期行业且具备供需、库存、价格数据时 |
| [investor-perspective-market-feedback-reflection](investor-perspective-market-feedback-reflection/SKILL.md) | 警示反思认知框架对市场信号解读的影响 | 采用特定分析框架（如仅依赖财报）研究A股时 |
| [long-term-industry-allocation-framework-using-us-benchmark](long-term-industry-allocation-framework-using-us-benchmark/SKILL.md) | 基于标普500 40年数据构建中国市场长期行业配置框架 | 需建立跨周期行业配置策略时 |
| [pre-field-research-preparation-for-a-share-companies](pre-field-research-preparation-for-a-share-companies/SKILL.md) | 执行A股公司实地调研前的四重准备流程 | 计划对A股公司实地调研且已有初步投资意向时 |
| [industry-abandonment-and-retracking-guidelines](industry-abandonment-and-retracking-guidelines/SKILL.md) | 判断是否暂停行业跟踪并设定重新纳入条件 | 行业已过高速成长期并出现结构性拐点时 |
| [innovation-based-value-creation-assessment](innovation-based-value-creation-assessment/SKILL.md) | 评估是否基于“伟大创新”实现价值创造（≥10倍体验/效率提升） | 分析对象展现重构产品/商业模式潜力时 |
| [moat-evolution-and-investment-strategy](moat-evolution-and-investment-strategy/SKILL.md) | 识别不同历史时期护城河类型并制定投资策略 | 需判断企业竞争优势时代特征及估值方法时 |
| [high-valuation-small-cap-vs-low-valuation-blue-chip-risk-opportunity-assessment](high-valuation-small-cap-vs-low-valuation-blue-chip-risk-opportunity-assessment/SKILL.md) | 评估高估小盘股 vs 低估蓝筹股的风险机会 | 中小盘PE/PB/PS超100倍而蓝筹PE<15倍时 |
| [undervalued-high-roc-industry-investment-opportunity-identification](undervalued-high-roc-industry-investment-opportunity-identification/SKILL.md) | 判断高资本回报率行业是否存在盈利驱动的长期机会 | 行业基本面好、盈利增长但估值未修复时 |
| [bank-npl-shock-and-strategic-valuation-opportunity-assessment](bank-npl-shock-and-strategic-valuation-opportunity-assessment/SKILL.md) | 评估银行坏账冲击后的战略性投资机会 | 银行坏账率近10%、PB约6%且风险准备充足时 |
| [gao-yi-asset-value-investing-organization-and-methodology](gao-yi-asset-value-investing-organization-and-methodology/SKILL.md) | 构建以长期价值投资为核心的资管组织机制 | 机构希望建立可持续价值投资文化并吸引顶尖人才时 |
| [企业可持续竞争力三维评估](企业可持续竞争力三维评估/SKILL.md) | 系统评估企业长期竞争力与商业模式健康度 | 需判断企业是否具备持久壁垒或为社会创造正向价值时 |
| [researcher-core-traits-assessment](researcher-core-traits-assessment/SKILL.md) | 评估个体是否具备求知欲、诚实、独立三项研究员核心特质 | 需判断自身或他人是否适合长期研究角色时 |
| [researcher-wisdom-circle-construction](researcher-wisdom-circle-construction/SKILL.md) | 为重要课题构建并运营专家智慧圈网络 | 启动长期高价值研究课题需整合外部认知资源时 |
| [growth-valuation-matching-investment-decision](growth-valuation-matching-investment-decision/SKILL.md) | 判断高确定性成长企业是否估值显著低于其潜力 | 企业高增长且当前估值远低于成长应得水平时 |
| [valuation-based-position-sizing](valuation-based-position-sizing/SKILL.md) | 根据市场整体或蓝筹股PE偏离历史中值动态调仓 | PE显著偏离长期均值（通常约15倍）时 |
| [identify-structural-market-opportunities](identify-structural-market-opportunities/SKILL.md) | 识别结构性分化中具备真实盈利与效率优势的优质企业 | 经济企稳、盈利基础稳固、流动性改善、预期调整时 |
| [compare-hk-and-a-share-bottom-strategies](compare-hk-and-a-share-bottom-strategies/SKILL.md) | 比较港股与A股底部形成机制、交易时机及标的筛选 | 计划在市场底部逆向布局并需对比两市时 |
| [基本面投资卖出三原则](基本面投资卖出三原则/SKILL.md) | 基于估值过高、基本面恶化、机会成本三维度做出卖出决策 | 出现任一卖出触发条件时 |
| [价值投资三好选股原则](价值投资三好选股原则/SKILL.md) | 系统评估“好行业、好公司、好价格”三个必要条件 | 目标为基本面长期投资且需筛选高安全边际标的时 |
| [long-term-alpha-in-efficient-markets](long-term-alpha-in-efficient-markets/SKILL.md) | 在市场效率提升背景下转向长期价值判断与独立研究 | 主动管理面临超额收益挑战需克服短期考核压力时 |
| [a-share-fundamental-investing-long-term-effectiveness](a-share-fundamental-investing-long-term-effectiveness/SKILL.md) | 判断A股基本面投资长期有效性并发出逆向信号 | 市场高波动且定价明显偏离企业长期价值时 |
| [growth-stage-industry-investment-screening](growth-stage-industry-investment-screening/SKILL.md) | 在行业快速成长期优先评估企业家能力与治理机制 | 行业需求远大于供给、处于高需求低供给阶段时 |
| [growth-stock-valuation-by-demand-stage](growth-stock-valuation-by-demand-stage/SKILL.md) | 根据成长股需求释放阶段及流动性动态调整PE容忍度 | 分析标的属成长股且行业具明确需求爆发特征时 |
| [top-down-bottom-up-investment-framework](top-down-bottom-up-investment-framework/SKILL.md) | 系统构建行业与个股选择逻辑：宏观圈定行业→微观选个股 | 需从宏观趋势出发筛选高胜率行业并选优质个股时 |
| [identify-growth-stock-opportunities-via-supply-demand-analysis](identify-growth-stock-opportunities-via-supply-demand-analysis/SKILL.md) | 判断行业是否具备“未来需求大+当前供给小”的成长股潜力 | 需评估未被满足强需求是否存在，尤其在经济转换期 |
| [economic-main-channel-investment-system](economic-main-channel-investment-system/SKILL.md) | 构建聚焦长期结构性经济变革领域的投资决策框架 | 需系统筛选创新驱动、优质模式、卓越组织、合理价格资产时 |
| [gao-zengzhang-yu-gao-ziben-huibao-qudong-fenxi](gao-zengzhang-yu-gao-ziben-huibao-qudong-fenxi/SKILL.md) | 分析标的是否兼具高增长潜力与高资本回报能力 | 需判断增长可持续性与回报质量时 |
| [stock-decline-classification-and-bottom-fishing-strategy](stock-decline-classification-and-bottom-fishing-strategy/SKILL.md) | 将下跌分为“杀估值/业绩/逻辑”并生成操作建议 | 股票大幅下跌且具备基本面分析能力时 |
| [structural-market-trend-and-industry-consolidation-investment-logic](structural-market-trend-and-industry-consolidation-investment-logic/SKILL.md) | 应用“结构性需求明确+供给效率分化+集中度提升”逻辑 | 经济度过下滑期，行业呈现结构性需求与头部效率优势时 |
| [strong-demand-sector-entry-timing](strong-demand-sector-entry-timing/SKILL.md) | 判断环保、健康、TMT等强需求行业是否处早期窗口期 | 行业有真实紧迫需求、未过度资本涌入、模式初步可行时 |
| [assess-technology-disruption-in-traditional-industries](assess-technology-disruption-in-traditional-industries/SKILL.md) | 评估新技术对传统产业核心运作方式的颠覆潜力 | 新技术改变生产、物流、销售、品牌或管理时 |
| [business-quality-quadrant-classification](business-quality-quadrant-classification/SKILL.md) | 用护城河、增长性、资本强度、ROIC四维度划分生意质量等级 | 需评估生意或公司长期投资价值（非短期投机）时 |
| [consumption-upgrade-driven-industry-boom-investment-framework](consumption-upgrade-driven-industry-boom-investment-framework/SKILL.md) | 识别由消费升级驱动的需求爆发型行业机会 | 观察到产品因规模化降价、收入持续增长进入爆发临界点时 |
| [zhen-chuang-xin-ping-gu-biao-zhun](zhen-chuang-xin-ping-gu-biao-zhun/SKILL.md) | 判断创新是否在核心体验带来≥10倍可量化提升 | 需评估某项“突破性创新”是否真正有意义时 |
| [zhen-chuangxin-xiao-lu-pan-duan](zhen-chuangxin-xiao-lu-pan-duan/SKILL.md) | 判断效率/成本创新是否构成“真创新” | 需验证某商业模式/产品是否属根本性创新时 |
| [high-potential-innovation-penetration-assessment](high-potential-innovation-penetration-assessment/SKILL.md) | 评估创新产品是否处高潜力快速渗透阶段 | 观察到创新扩散且具备可量化增长与技术/模式创新时 |
| [innovation-moat-defense-strategy](innovation-moat-defense-strategy/SKILL.md) | 制定基于现有护城河的防御策略并评估主动转型可能 | 成熟企业面临新技术/模式竞争挑战时 |
| [innovation-triad-assessment](innovation-triad-assessment/SKILL.md) | 评估创新活动的区域路径、实现可能性与创新强度 | 规划、评审或优化应用导向创新方案时 |
| [focus-on-core-priorities-and-pursue-excellence](focus-on-core-priorities-and-pursue-excellence/SKILL.md) | 指导将全部精力集中于最关键任务并以卓越标准执行 | 确认某任务对长期目标具决定性影响且有复利效应时 |
| [scale-and-differentiation-coevolution](scale-and-differentiation-coevolution/SKILL.md) | 评估企业是否通过五大要素实现规模化与差异化互促 | 需分析企业能否在成本可控下实现个性化供给并扩规模时 |
| [organizational-expansion-six-stage-model](organizational-expansion-six-stage-model/SKILL.md) | 识别组织扩张阶段并指导引入下一阶段核心技术/管理创新 | 组织面临管理复杂度瓶颈或规模不经济风险时 |
| [education-industry-standardized-expansion](education-industry-standardized-expansion/SKILL.md) | 判断教育产业是否具备有质量的规模化扩张条件 | 教育机构计划扩张且需评估教材、师资、授课标准化时 |
| [zhudao-hangdao-shengyi-pinggu](zhudao-hangdao-shengyi-pinggu/SKILL.md) | 判断新兴行业/创业公司是否具备主航道投资潜力 | 需评估新生意的长期增长性、规模效应与资本回报前景时 |
| [detect-mature-business-exit-signals](detect-mature-business-exit-signals/SKILL.md) | 判断成熟生意是否已退出主航道投资阶段 | 需评估某成熟业务是否仍具高速增长潜力时 |
| [zhudao-hangye-panduan-biaozhun](zhudao-hangye-panduan-biaozhun/SKILL.md) | 判定新兴技术/互联网赛道是否构成“正在崛起的主航道” | 需评估科技趋势或商业机会是否成未来主导性赛道时 |
| [identify-emerging-tech-main-channels](identify-emerging-tech-main-channels/SKILL.md) | 分析六大领域是否符合“新兴主航道”特征 | 需评估某科技/数字经济领域是否处商业化早期至成长期时 |
| [four-dimensional-logic-validation-for-research-questions](four-dimensional-logic-validation-for-research-questions/SKILL.md) | 用宏观、产业、业务、财务四维度交叉验证研究对象 | 需判断研究对象战略合理性、趋势契合度与经营质量时 |
| [industry-essence-identification](industry-essence-identification/SKILL.md) | 识别产业经济本质属性（如“高杠杆利率产品”） | 需分析水电、零售、TMT等成熟行业的内在模式与风险时 |
| [consumer-goods-macro-industry-analysis](consumer-goods-macro-industry-analysis/SKILL.md) | 评估中国消费品企业长期竞争力与增长潜力 | 分析对象为消费品企业且需判断存量升级背景下的定位时 |
| [消费品企业业务与财务验证指标体系](消费品企业业务与财务验证指标体系/SKILL.md) | 验证消费品企业实际执行能力与持续创新能力 | 需评估老品类盈利、新品类质量、份额动态及消费者行为时 |
| [professional-expertise-development-timeline](professional-expertise-development-timeline/SKILL.md) | 估算早期职业者达成专业 expertise 所需时间并引导长期心态 | 用户处于职业早期且需规划专业成长路径时 |
| [zhi-ji-zhuan-zhu-he-xin-shi-wu](zhi-ji-zhuan-zhu-he-xin-shi-wu/SKILL.md) | 在已明确核心任务前提下实现超越常规的深度执行 | 投资专业人士等在非危机场景下追求专业极致时 |
| [structured-research-system-construction](structured-research-system-construction/SKILL.md) | 构建可复用、可迭代的结构化研究文档体系 | 开始对一家公司或行业进行系统性持续研究时 |
| [graham-margin-of-safety-evaluation](graham-margin-of-safety-evaluation/SKILL.md) | 评估股票是否符合格雷厄姆安全边际标准（内在价值≥1.5倍市价） | 已完成基本面分析并获内在价值估算结果时 |
| [3g-capital-value-creation-methodology](3g-capital-value-creation-methodology/SKILL.md) | 系统释放因管理不善而陷入困境的强势品牌企业内在价值 | 目标企业有强大品牌但运营低效，且可获控股权时 |
| [3g-capital-talent-incentive-mechanism](3g-capital-talent-incentive-mechanism/SKILL.md) | 实施3G资本式高绩效导向人才激励体系 | 组织需通过低固定薪酬、高奖金、股权绑定激发自驱力时 |
| [识别可持续结构性变化的投资方法](识别可持续结构性变化的投资方法/SKILL.md) | 判断变化是否结构性、可持续、不可逆并确定投资优先级 | 观察到行业格局重塑、消费行为转变或技术突破时 |
| [understand-china-capital-market-complexity](understand-china-capital-market-complexity/SKILL.md) | 建立对中国资本市场结构性复杂性的整体认知 | 计划在中国市场进行基本面分析或长期价值投资前 |
| [detect-concept-hype-bubbles-in-a-share-market](detect-concept-hype-bubbles-in-a-share-market/SKILL.md) | 识别A股“从0到1”概念炒作形成的高风险泡沫 | 上市公司提未经验证新技术/模式却获远超VC合理估值时 |
| [cong-1-dao-n-tou-zi-ce-lue](cong-1-dao-n-tou-zi-ce-lue/SKILL.md) | 评估已确立龙头地位、估值合理（PE 8–15倍）的A/H股企业机会 | 分析“唯一、第一或最好之一”企业是否处可扩展增长阶段时 |
| [analyze-china-market-inefficiency-phases](analyze-china-market-inefficiency-phases/SKILL.md) | 识别A股阶段性无效状态并判断阿尔法机会形成时机 | 市场出现极端共识、优质资产被系统忽视或情绪定价偏离时 |
| [structural-cost-advantage-analysis-in-telecom-equipment](structural-cost-advantage-analysis-in-telecom-equipment/SKILL.md) | 分析人力密集型高科技企业是否具备结构性成本优势 | 行业满足研发人员≥1/3、研发费占收10–15%、工程师薪酬跨国差异大时 |
| [跨国通信企业中国市场失败根源分析](跨国通信企业中国市场失败根源分析/SKILL.md) | 分析跨国通信设备企业在华因标准化战略、高定价、无本地产品权而失败 | 需诊断类似跨国企业市场退出问题且满足高壁垒+新兴市场+无产品定义权时 |
| [assess-chinese-banking-profit-share](assess-chinese-banking-profit-share/SKILL.md) | 评估中国银行业利润占中国企业总利润的真实比例 | 用户引用“银行业占上市公司利润一半”等片面数据质疑暴利时 |
| [analyze-chinese-bank-profit-sustainability](analyze-chinese-bank-profit-sustainability/SKILL.md) | 评估中国银行业高利润是否源于真实成本结构与劳动生产率优势 | 需对比国际银行业成本收入比或分析盈利能力可持续性时 |
| [industry-evolution-and-alpha-shift-analysis](industry-evolution-and-alpha-shift-analysis/SKILL.md) | 分析行业生命周期如何驱动超额收益来源转变 | 行业渗透率达高位且竞争成熟时 |
| [active-alpha-creation-paradigm](active-alpha-creation-paradigm/SKILL.md) | 指导投资者从“外部观察者”转为“内部价值创造者”构建阿尔法 | 具备企业改造能力与治理干预权限的主动投资者 |
| [prioritize-high-growth-large-market-industries](prioritize-high-growth-large-market-industries/SKILL.md) | 优先将研究资源分配给高增长性+大体量行业 | 研究者面临多行业选择且资源有限时 |
| [industry-research-thick-to-thin-methodology](industry-research-thick-to-thin-methodology/SKILL.md) | 构建新行业认知：先“变厚”再“变薄”形成可操作指标体系 | 初次接触陌生行业需从零构建系统理解时 |
| [automotive-capital-efficiency-bias-correction](automotive-capital-efficiency-bias-correction/SKILL.md) | 纠正对中国整车企业“重资产、低回报”的常见误判 | 分析对象为中国整车制造企业且需评估资产轻重属性时 |
| [automotive-industry-cyclical-tracking-model](automotive-industry-cyclical-tracking-model/SKILL.md) | 用产能利用率、库存系数、价格折扣、产业链分配判断汽车盈利周期 | 需评估整车企业投资价值、预测利润拐点或判断价格战时 |
| [analyze-market-fragmentation-for-value-investing](analyze-market-fragmentation-for-value-investing/SKILL.md) | 在市场明显分化时识别价值投资核心驱动力 | 观察到结构性割裂、板块轮动异常或估值离散度扩大时 |
| [value-investing-three-elements](value-investing-three-elements/SKILL.md) | 在A股评估机会，聚焦估值与品质，弱化择时 | 寻找长期标的、判断是否追高龙头或面对高度共识环境时 |
| [comprehensive-market-logic-based-investment-decision](comprehensive-market-logic-based-investment-decision/SKILL.md) | 通过评估未被充分定价逻辑做出高关注度股票决策 | 面对多个看多/看空逻辑、缺乏深度研究能力时 |
| [demand-satisfaction-based-industry-selection](demand-satisfaction-based-industry-selection/SKILL.md) | 识别由强未满足需求驱动的高成长性行业 | 需在早期发现环保、消费升级等产业机会且不预判商业模式优劣时 |
| [优质龙头企业筛选标准](优质龙头企业筛选标准/SKILL.md) | 判断企业是否符合“优质龙头”长期价值投资标准 | 需评估白酒、白电、自主品牌车、电子制造等行业企业时 |
| [automotive-retail-inventory-coefficient-assessment](automotive-retail-inventory-coefficient-assessment/SKILL.md) | 根据月度库存系数评估乘用车行业库存健康状况 | 获得月度库存系数并需判断供需状态或制定决策时 |
| [identify-hit-vehicle-potential](identify-hit-vehicle-potential/SKILL.md) | 判断新上市自主品牌车型是否具备月销过万爆款潜力 | 分析10万元左右新SUV/轿车是否可能热销且合资竞品价差显著时 |
| [automotive-sector-valuation-and-competition-analysis](automotive-sector-valuation-and-competition-analysis/SKILL.md) | 分析传统整车企业估值偏低原因及合资vs自主竞争动态 | 需判断汽车股是否被低估、何时修复估值或理解自主破局路径时 |
| [high-leverage-heavy-asset-investment-evaluation](high-leverage-heavy-asset-investment-evaluation/SKILL.md) | 评估已运营的高初始投资、低运营成本重资产项目价值 | 分析对象具资源独占性/自然垄断且非技术快速迭代行业时 |
| [leverage-double-edged-effect-and-strategy-failure-risk](leverage-double-edged-effect-and-strategy-failure-risk/SKILL.md) | 识别杠杆放大收益与损失的双重效应及策略失效风险 | 讨论高杠杆投资、融资策略、对冲基金操作或资本结构优化时 |
| [xu-shi-jie-he-investment-analysis](xu-shi-jie-he-investment-analysis/SKILL.md) | 评估成长股“实”（基本面确定性）与“虚”（成长预期）结合质量 | 需判断潜在标的是否值得长期持有或隐含风险时 |
| [跨行业公司可比性分析](跨行业公司可比性分析/SKILL.md) | 用生态、人、组织、竞争力四维度实现跨行业公司横向质量评估 | 需构建多元化组合或识别跨行业可持续竞争优势时 |
| [circle-of-competence-based-trading-strategy](circle-of-competence-based-trading-strategy/SKILL.md) | 根据自身认知层级（内行/外行/中间）选择匹配交易策略 | 已明确自身在目标领域的能力圈定位并需制定操作指令时 |
| [data-driven-enterprise-transformation](data-driven-enterprise-transformation/SKILL.md) | 指导B2C等企业将数据作为核心生产要素重构运营模式 | 企业具备用户触点、能采集行为数据并有基础处理能力时 |
| [entrepreneurial-spirit-as-value-creation-driver](entrepreneurial-spirit-as-value-creation-driver/SKILL.md) | 评估企业家精神作为动态环境中长期价值创造核心驱动力 | 企业面临不确定性、竞争力挑战或需突破路径依赖时 |
| [企业家学习自省与创新能力框架](企业家学习自省与创新能力框架/SKILL.md) | 指导企业家在成功后构建持续学习、制度创新、深度自省能力 | 企业已成功但遭遇环境剧变或未来高度不确定时 |
| [growth-stock-screening-10-3-principle](growth-stock-screening-10-3-principle/SKILL.md) | 用“10-3原则”对A股非金融成长企业双重验证筛选 | 需判断企业是否具长期生存确定性与中期盈利/估值双升潜力时 |
| [market-risk-three-stage-classification](market-risk-three-stage-classification/SKILL.md) | 按“低风险—潜在风险—绝对风险”三阶段分类判断市场风险性质 | 需评估成长股等资产是否具安全边际、容错空间或长期回报潜力时 |
| [shuang-lu-jing-qi-ye-zhan-lue-xuan-ze](shuang-lu-jing-qi-ye-zhan-lue-xuan-ze/SKILL.md) | 基于双路径模型评估企业应采成本领先、差异化或双轨战略 | 需判断企业如何建可持续优势、分析当前定位或制定战略时 |
| [zhongguo-xianjin-zhizao-ye-guoji-bijiao-youshi-fenxi](zhongguo-xianjin-zhizao-ye-guoji-bijiao-youshi-fenxi/SKILL.md) | 评估中国先进制造业企业是否具可持续国际竞争力 | 需判断技术/资本密集型中企在全球产业链定位潜力时 |
| [enterprise-1-to-n-system-capability-assessment](enterprise-1-to-n-system-capability-assessment/SKILL.md) | 评估企业是否具备产品、市场、组织“从1到Nⁿ”系统能力 | 企业处经济转型期并希望提升份额与竞争力时 |
| [assess-core-competitiveness-via-culture-and-governance](assess-core-competitiveness-via-culture-and-governance/SKILL.md) | 分析企业文化、治理结构及企业家精神制度化程度 | 需判断企业能否维持领先或跨越重大困境时 |
| [tech-giant-ecosystem-integration-analysis](tech-giant-ecosystem-integration-analysis/SKILL.md) | 评估科技巨头如何通过纵向横向一体化构建内部生态系统 | 需理解平台型企业结构性优势、判断长期价值或分析垄断成因时 |
| [you-chun-you-e-tou-zi-ji-lu](you-chun-you-e-tou-zi-ji-lu/SKILL.md) | 通过“蠢”（承认无知）与“饿”（扫描错杀资产）构建理性投资操作系统 | 长期投资者面临市场剧烈波动、热门叙事干扰或决策压力时 |
| [penetration-rate-based-product-lifecycle-analysis](penetration-rate-based-product-lifecycle-analysis/SKILL.md) | 根据渗透率判断产品生命周期阶段及最佳投资窗口期 | 分析消费品、科技产品等市场边界清晰且用户基数明确的领域时 |
| [market-share-competition-valuation-analysis](market-share-competition-valuation-analysis/SKILL.md) | 分析行业从渗透率红利转向市占率竞争对龙头估值影响 | 行业渗透率>70%、需求增速放缓、竞争加剧时 |
| [personal-investor-loss-patterns-in-a-share-market](personal-investor-loss-patterns-in-a-share-market/SKILL.md) | 识别个人投资者因追涨杀跌导致的系统性亏损规律 | 用户为A股个人投资者且以绝对收益为目标时 |
| [主动管理型基金长期跑输基准评估](主动管理型基金长期跑输基准评估/SKILL.md) | 评估主动基金在成熟市场长期跑输基准的普遍现象 | 讨论主动策略有效性、基金选择或质疑主动管理价值时 |
| [a-share-investment-methods-evolution](a-share-investment-methods-evolution/SKILL.md) | 提供A股三大投资方法（技术、基本面、量化）演变分析框架 | 需理解A股流派演变、比较方法论优劣或为策略选择提供依据时 |
| [investment-cognitive-bias-detection](investment-cognitive-bias-detection/SKILL.md) | 识别损失厌恶、概率计算缺失、存活者偏差三大认知偏差 | 用户描述投资冲动、彩票倾向、赌博行为或过度关注暴富案例时 |
| [hong-kong-equity-investment-strategy](hong-kong-equity-investment-strategy/SKILL.md) | 提供基于本土信息优势的低估值高增长港股系统性策略 | 处于全球低利率资产荒且具备草根调研或深度分析能力时 |
| [chinese-auto-brand-substitution-analysis](chinese-auto-brand-substitution-analysis/SKILL.md) | 分析自主品牌结构性替代合资品牌的可行性与路径 | 需评估国产车崛起机会、判断标的或制定本地化竞争策略时 |
| [liquidity-risk-impact-on-equity-valuation](liquidity-risk-impact-on-equity-valuation/SKILL.md) | 评估利率走高、流动性趋紧是否引发系统性“杀估值”风险 | 利率持续上升且企业盈利不足以抵消影响时 |
| [real-estate-long-term-demand-and-policy-stimulus-boundary](real-estate-long-term-demand-and-policy-stimulus-boundary/SKILL.md) | 判断中国房地产在人口恶化与政策受限下的长期趋势 | 需评估住宅销售、房价走势或政策效果且满足结婚对数年降4%等条件时 |
| [hong-kong-equity-ecosystem-shift-analysis](hong-kong-equity-ecosystem-shift-analysis/SKILL.md) | 分析内地资金流入对港股生态结构的长期影响 | 需评估港股未来风险收益特征、制定跨境策略或判断稳定性时 |
| [internet-industry-consolidation-investment-analysis](internet-industry-consolidation-investment-analysis/SKILL.md) | 判断互联网子行业在用户红利放缓、大公司挤压下的投资价值 | 行业进入整合阶段（用户增长放缓+大公司持续进入）时 |
| [pan-internet-sustainable-business-model-evaluation](pan-internet-sustainable-business-model-evaluation/SKILL.md) | 在巨头集中趋势下识别泛互联网行业长期价值公司 | 需排除服务简单、无壁垒、流量黏性不足的模式时 |
| [build-fundamental-investment-research-system](build-fundamental-investment-research-system/SKILL.md) | 指导资管机构系统构建基本面研究为核心的投研能力 | 机构目标通过深度研究实现可持续业绩且具备团队基础时 |
| [asset-management-firm-development-logic](asset-management-firm-development-logic/SKILL.md) | 指导私募按“机制与团队→业绩→规模”因果链制定发展战略 | 机构希望可持续增长、避免盲目追求短期规模时 |
| [consumption-upgrade-investment-analysis](consumption-upgrade-investment-analysis/SKILL.md) | 在GDP>5%、中产扩大等条件下识别消费升级驱动机会 | 分析品牌消费品、白酒、汽车等在政策扰动但需求韧性时的配置价值 |
| [er-xian-cheng-shi-fang-di-chan-qu-ku-cun-tou-zi-luo-ji](er-xian-cheng-shi-fang-di-chan-qu-ku-cun-tou-zi-luo-ji/SKILL.md) | 判断哪些二线城市房地产去库存具备高成功概率 | 关注中国房地产去库存政策下省会、计划单列市等二线城市机会时 |
| [real-estate-collateral-risk-assessment](real-estate-collateral-risk-assessment/SKILL.md) | 评估银行因高度依赖房地产抵押面临的资产质量风险 | 房价进入下行周期或产能过剩行业去产能未完成时 |
| [a-share-valuation-divergence-risk-identification](a-share-valuation-divergence-risk-identification/SKILL.md) | 识别A股显著估值分化下高估值股票潜在风险 | 传统蓝筹PE<15倍而新兴板块PE>70倍且具备2015–2016年数据时 |
| [dumbbell-asset-allocation-and-stock-selection](dumbbell-asset-allocation-and-stock-selection/SKILL.md) | 构建价值型防守资产+精选成长型资产的“哑铃型”组合 | 低利率、高不确定性、基本面未明显改善但资金充裕时 |
| [systematic-market-crash-position-and-hedge](systematic-market-crash-position-and-hedge/SKILL.md) | 在A股连续千股跌停中执行降仓、对冲、反弹三阶段操作 | 高仓位（>90%）组合面临流动性枯竭的系统性下跌时 |
| [growth-stock-risk-mitigation-and-selection](growth-stock-risk-mitigation-and-selection/SKILL.md) | 在“三高”成长股热潮中回避高风险、筛选真实增长标的 | 需识别高估值、高预期、高市值成长股中的优质机会时 |
| [evaluate-good-industry-investment-potential](evaluate-good-industry-investment-potential/SKILL.md) | 判断行业是否具备长期投资价值（护城河、定价权、技术稳定） | 行业分析师等初步筛选可投资行业时 |
| [a-share-company-tiering-and-investment-scarcity-awareness](a-share-company-tiering-and-investment-scarcity-awareness/SKILL.md) | 建立对A股上市公司质量金字塔分布与标的稀缺性的清醒认知 | 在A股寻找优质标的、筛选股票池或评估机会时 |
| [ni-xiang-tou-zi-yu-long-tou-gu-xuan-ze](ni-xiang-tou-zi-yu-long-tou-gu-xuan-ze/SKILL.md) | 在新兴行业混战或全行业受冲击时等待格局清晰后选龙头 | 适用于小盘股、新兴行业及受系统性危机影响行业 |
| [assess-industry-competition-via-executive-comments](assess-industry-competition-via-executive-comments/SKILL.md) | 通过高管对竞争对手评价判断行业竞争激烈程度与格局稳定性 | 可直接接触高管、了解行业背景的投资分析师实地调研时 |
| [value-creation-logic-in-industrial-evolution](value-creation-logic-in-industrial-evolution/SKILL.md) | 评估产业重构、生产力进步如何共同驱动股东价值 | 需判断前期失败与资本浪费是否具战略意义且关注生产率提升时 |
| [labor-cost-adaptation-strategy](labor-cost-adaptation-strategy/SKILL.md) | 评估企业是否具备通过提升生产率应对劳动力成本上升的能力 | 共同富裕政策背景下分析企业可持续性时 |
| [feng-liu-industry-selection-logic](feng-liu-industry-selection-logic/SKILL.md) | 指导散户基于行业稳定性与可理解性筛选适合长期投资行业 | 用户为散户、寻求长期稳定回报且无专业信息渠道时 |
| [feng-liu-inverse-concentrated-positioning](feng-liu-inverse-concentrated-positioning/SKILL.md) | 执行高仓位、无对冲、无杠杆、长期持有的逆向投资操作 | 已确认标的为“好企业”且以合理/低估价格买入时 |
| [private-fund-absolute-return-investment-framework](private-fund-absolute-return-investment-framework/SKILL.md) | 提供私募绝对收益投资完整执行流程 | 管理以绝对收益为目标、合规允许使用对冲工具的私募产品时 |
| [dynamic-position-adjustment-for-core-holdings](dynamic-position-adjustment-for-core-holdings/SKILL.md) | 对重点持仓公司进行动态跟踪与头寸调整 | 公司运营变化、股价与基本面偏离或行业格局演变时 |
| [识别高壁垒公司甜蜜点投资机会](识别高壁垒公司甜蜜点投资机会/SKILL.md) | 判断高技术壁垒设备商成为顶级客户核心供应商是否处“甜蜜点” | 公司曾有产品缺陷但已解决、前五大客户高度集中时 |
| [zhuang-gu-bengpan-reflection-for-institutional-investors](zhuang-gu-bengpan-reflection-for-institutional-investors/SKILL.md) | 指导机构投资者反思庄股崩盘事件并转向基本面研究驱动 | 分析2001年前后因坐庄模式失效引发的行业行为变革时 |
| [validate-value-investing-effectiveness-in-china](validate-value-investing-effectiveness-in-china/SKILL.md) | 验证价值投资在A股能否实现可持续超额收益 | 用户为百亿级公募、社保或长期投资者且有基本面研究能力时 |
| [thermal-power-investment-three-factor-framework](thermal-power-investment-three-factor-framework/SKILL.md) | 评估火电行业是否进入反转投资窗口（煤价见顶回落+连续亏损） | 火电因“计划电、市场煤”矛盾亏损且煤价高位见顶时 |
| [baijiu-industry-contrarian-investment](baijiu-industry-contrarian-investment/SKILL.md) | 在政策冲击致白酒估值下杀但收入企稳时高配优质白酒企业 | 高端白酒因八项规定等政策冲击估值大幅下杀时 |
| [high-market-liquidity-risk-control](high-market-liquidity-risk-control/SKILL.md) | 为私募绝对收益产品提供高点流动性风险应对流程 | 市场高点、资金涌入流动性差小盘股且普遍带杠杆时 |
| [qingdao-beer-valuation-model](qingdao-beer-valuation-model/SKILL.md) | 对转型期报表利润被低估但实际盈利强劲的合资消费品企业重估 | 公司消化历史包袱、管理优秀、行业稳定且实际盈利强劲时 |
| [public-to-private-fund-manager-transition](public-to-private-fund-manager-transition/SKILL.md) | 识别公募转私募的目标差异、能力缺口与客户沟通策略 | 基金经理从相对收益转向绝对收益产品时 |
| [industry-trend-research-framework](industry-trend-research-framework/SKILL.md) | 提供聚焦高社会价值量行业的深度研究方法论 | 研究团队面临海量信息需提前识别产业变迁潜在赢家时 |
| [economic-transition-enterprise-differentiation-analysis](economic-transition-enterprise-differentiation-analysis/SKILL.md) | 识别经济增速换挡期具备持续高回报潜力的优势企业 | 经济背景需求饱和、增长放缓且分析对象为上市公司时 |
| [chuangye-ban-paomo-risk-assessment](chuangye-ban-paomo-risk-assessment/SKILL.md) | 识别创业板因非理性行为和转型叙事过度炒作形成的估值泡沫 | 创业板整体估值显著脱离盈利、现金流、ROE等基本面时 |
| [extreme-market-drawdown-dynamic-positioning](extreme-market-drawdown-dynamic-positioning/SKILL.md) | 在系统性快速下跌且仓位>90%时执行降仓、对冲、反弹三步操作 | 主动管理型基金等面临连续千股跌停的系统性风险时 |
| [platform-hedge-fund-competitive-advantage-analysis](platform-hedge-fund-competitive-advantage-analysis/SKILL.md) | 分析平台型私募如何通过五大机制构建系统性竞争优势 | 需评估或解释高毅类平台型私募相较于个体户的持续优势时 |
| [客户信任与平台使命互动机制](客户信任与平台使命互动机制/SKILL.md) | 识别、强化并回应客户因平台理性应对产生的深度信任信号 | 平台已建立五大机制、获市场认可且有稳定业绩记录时 |
| [gao-yi-asset-core-incentive-mechanism](gao-yi-asset-core-incentive-mechanism/SKILL.md) | 构建投资经理与客户利益高度绑定的制度体系 | 平台型私募旨在通过跟投、命名权等机制强化受托责任时 |
| [zhong-shen-xue-xi-he-xin-neng-li-gou-jian](zhong-shen-xue-xi-he-xin-neng-li-gou-jian/SKILL.md) | 帮助个体构建面向未来的终身学习核心能力 | 面临AI替代风险、希望提升长期适应力或转向深度创造性应用时 |
| [zhanlu-reading-three-tier-methodology](zhanlu-reading-three-tier-methodology/SKILL.md) | 指导根据学习目标选择泛读、通读或精读模式 | 用户希望突破阅读障碍且已安装湛庐阅读APP时 |
| [scan-book-barcode-for-digital-benefits](scan-book-barcode-for-digital-benefits/SKILL.md) | 指导通过扫条形码解锁湛庐图书专属数字内容 | 用户持有带条形码湛庐实体书并已安装湛庐阅读APP时 |
| [chun-lu-investment-reading-recommendations](chun-lu-investment-reading-recommendations/SKILL.md) | 提供基于“主题关联+权威背书”的四本核心延伸阅读书目 | 用户正在阅读或咨询湛庐金融投资类图书时 |

## Quick Navigation

### 投资哲学与基本原则
- **价值投资核心原则与长期主义**: 阐述做时间的朋友、安全边际、定价权等根本理念
- **投资哲学与长期成功原则**: 强调稳定性、可重复性、可持续性三大属性
- **格雷厄姆价值投资基础与估值原则**: 基于客观数据的保守分析方法

### 行业与公司分析框架
- **行业与公司四维评估框架**: 系统性行业四维度+公司双维度评估
- **企业可持续竞争力三维评估**: 评估企业长期竞争力与商业模式健康度
- **business-quality-quadrant-classification**: 用四维度划分生意质量等级

### 选股与估值方法
- **价值投资三好选股原则**: 系统评估“好行业、好公司、好价格”
- **价值投资核心选股框架**: 聚焦“估值、品质、时机”三要素
- **graham-margin-of-safety-evaluation**: 评估是否符合格雷厄姆安全边际标准

### 市场周期与逆向投资
- **逆向投资与市场情绪应对**: 提供市场常态/非常态识别与逆向逻辑
- **周期行业投资策略与风险管理**: 基于行业周期的投资策略框架
- **牛市中后期防御性资产配置策略**: 构建估值合理龙头为核心的防御组合

### 组合管理与卖出决策
- **集中投资与组合管理原则**: 阐述集中投资与自上而下/下而上结合框架
- **基本面投资卖出三原则**: 基于估值、基本面、机会成本三维度卖出
- **dynamic-position-adjustment-for-core-holdings**: 对核心持仓动态跟踪调整

### 创新与主航道识别
- **innovation-based-value-creation-assessment**: 评估是否基于“伟大创新”创造价值
- **zhudao-hangye-panduan-biaozhun**: 判定新兴赛道是否构成“正在崛起的主航道”
- **identify-emerging-tech-main-channels**: 分析六大科技领域是否符合主航道特征

### A股市场特性与策略
- **understand-china-capital-market-complexity**: 建立对中国资本市场复杂性的整体认知
- **a-share-fundamental-investing-long-term-effectiveness**: 判断A股基本面投资长期有效性
- **detect-concept-hype-bubbles-in-a-share-market**: 识别A股概念炒作高风险泡沫

### 研究方法与认知提升
- **研究驱动的决策简化方法论**: 通过深度研究减少无效决策
- **structured-research-system-construction**: 构建可复用结构化研究文档体系
- **investment-cognitive-bias-detection**: 识别三大典型认知偏差

### 机构与组织建设
- **gao-yi-asset-value-investing-organization-and-methodology**: 构建价值投资资管组织机制
- **build-fundamental-investment-research-system**: 系统构建基本面投研能力
- **asset-management-firm-development-logic**: 按“机制→业绩→规模”制定发展战略

### 个人成长与学习
- **researcher-core-traits-assessment**: 评估求知欲、诚实、独立三项研究员特质
- **zhong-shen-xue-xi-he-xin-neng-li-gou-jian**: 构建面向未来的终身学习能力
- **focus-on-core-priorities-and-pursue-excellence**: 聚焦核心任务并追求卓越

## How to Use
当您需要解决特定投资、研究或决策问题时，请根据问题性质参考上方“Quick Navigation”或“Available Skills”表格，选择最匹配的技能。在与Claude对话中，可直接说明您希望调用的技能名称（如“请使用‘价值投资三好选股原则’帮我分析…”），Claude将自动加载对应方法论并提供结构化指导。
```