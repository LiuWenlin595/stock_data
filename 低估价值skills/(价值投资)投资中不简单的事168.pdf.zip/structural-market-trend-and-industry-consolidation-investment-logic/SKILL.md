---
name: Structural Market Trend and Industry Consolidation Investment Logic
description: 识别并应用“结构性需求明确、供给端效率分化初显、行业集中度有望提升”的投资逻辑。当经济已度过主要下滑阶段，且目标行业（如消费品、周期性行业、制造业、环保）呈现由地区/收入/年龄差异驱动的结构性需求，同时供给端仍分散但头部企业已展现效率优势时，使用本技能筛选具备高集中度提升潜力的行业和标的。
---

# Structural Market Trend and Industry Consolidation Investment Logic

## When to Use
Use this skill when:
- The macro economy has passed its main downturn phase (e.g., post-2010 adjustment period in China);
- Demand exhibits structural characteristics due to demographic, regional, or income disparities;
- The target industry remains fragmented with many inefficient players;
- Leading firms demonstrate clear advantages in management efficiency, cost control, and market share expansion;
- Industry participants still misinterpret challenges as cyclical rather than structural.

Do **not** use this skill for:
- Industries with highly volatile demand or unpredictable policy environments;
- Emerging sectors where efficiency differentiation among firms has not yet emerged.

## How to Execute

1. **Confirm macroeconomic timing**: Verify the economy is past its primary adjustment phase.
2. **Identify structural demand drivers**: Determine if demand heterogeneity stems from region, income level, age, or other structural factors.
3. **Screen eligible industries** by checking:
   - Fragmented competitive landscape with numerous low-efficiency firms;
   - Presence of leading companies showing consistent gains in market share and profitability;
   - Industry-wide misperception that current challenges are temporary/cyclical.
4. **Assess efficiency differentiation**: Evaluate whether only the most efficient firms can sustain stable gross margins regardless of capital inflows or minor policy shifts.
5. **Project consolidation outcome**: Anticipate a future state where only a few highly efficient firms dominate, enjoy pricing power, and benefit from high entry barriers.
6. **Validate with historical precedents**: Cross-check against successfully consolidated sectors (e.g., home appliances) and compare with current candidates (e.g., automotive, environmental services, manufacturing).

## Expected Output
Prioritize investment allocation toward industries where structural demand is clear, supply-side efficiency gaps are widening, and market leaders are steadily increasing their market share.