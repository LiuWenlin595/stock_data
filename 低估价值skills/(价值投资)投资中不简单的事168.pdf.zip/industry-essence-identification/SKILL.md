---
name: Industry Essence Identification
description: 识别特定产业的经济本质属性（如“高杠杆利率产品”或“商业地产租赁”），用于指导长期投资决策、估值建模与战略制定。当用户需要分析水电、零售、动画、TMT或消费品等成熟行业的内在商业模式和风险特征时使用本技能。
---

# Industry Essence Identification

## When to Use
Use this skill when:
- Evaluating the long-term investment or strategic value of a specific industry.
- Preparing valuation models that require understanding the underlying economic nature of the business.
- Comparing industries with seemingly different surface operations but potentially similar core economics.

Do not use for experimental or pre-commercial sectors without stable revenue models.

## How to Execute

1. **Observe core economic features** of the target industry:
   - Is capacity utilization stable over time?
   - How volatile is downstream demand? (low / medium / high)
   - Is the cost structure transparent and predictable?
   - How are prices determined? (regulated, competitive, negotiated, etc.)

2. **Map the industry to a known financial or business archetype** based on these features:
   - If capacity, demand, costs, and pricing are all highly stable (e.g., hydropower), treat it as a **“leveraged interest-rate-like asset”**.
   - If revenue primarily comes from leasing physical space (e.g., traditional retail), model it as **“commercial real estate leasing”**.
   - If success depends on the fusion of creative content and software tools (e.g., animation), classify it as **“creative-content-enhanced IT”**.

3. **Validate the analogy** by checking whether:
   - Cash flow patterns match the archetype.
   - Capital structure (e.g., debt levels) aligns with typical risk profiles.
   - Primary risk sources (e.g., regulatory, technological, demand shocks) are consistent.

4. **Output the essence label** (e.g., “high-leverage rate product”) to inform downstream analysis such as:
   - Valuation methodology selection
   - Competitive positioning assessment
   - Strategic growth ceiling estimation

> ⚠️ Never rely solely on surface-level business descriptions—always drill into economic fundamentals.