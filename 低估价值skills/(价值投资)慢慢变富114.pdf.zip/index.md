```markdown
# 价值投资实战技能库

本技能库基于专业投资著作构建，为 Claude Code 提供系统化的价值投资分析能力。涵盖从投资哲学、选股框架、估值方法到心态管理的完整知识体系，帮助个人投资者建立长期盈利的投资系统，实现财富的稳健增长。

## Available Skills

| Skill | Description | Use When |
|-------|-------------|----------|
| [investment-worldview-methodology-framework](investment-worldview-methodology-framework/SKILL.md) | 构建投资系统的哲学基础，确立投资世界观与方法论的二元框架 | 投资系统构建初期、投资理念迷茫期、需要统一投资认知体系时 |
| [valuation-philosophy-and-framework](valuation-philosophy-and-framework/SKILL.md) | 建立正确的估值心态，强调定性思考优于机械计算，使用四因素敏感性框架评估内在价值 | 建立估值体系、避免机械估值、评估企业内在价值时 |
| [value-investment-framework](value-investment-framework/SKILL.md) | 建立完整的五维价值投资系统框架（哲学、选股、估值、持有、修养） | 构建系统化投资体系、从0到1建立投资框架时 |
| [hot-theme-investment-decision](hot-theme-investment-decision/SKILL.md) | 通过四问评估框架决定是否参与热门主题投资 | 市场出现热点板块、主题投资概念、牛市概念炒作诱惑时 |
| [quality-first-selection](quality-first-selection/SKILL.md) | 在企业质地与买入价格之间做出优先排序决策，确立"安全边际"原则 | 筛选股票、构建优质企业股票池、处理"好公司vs好价格"权衡时 |
| [investment-psychology-discipline](investment-psychology-discipline/SKILL.md) | 投资心理学与自我纪律管理，建立投资心理定力 | 面临情绪化决策、市场信息过载、需要克服人性弱点时 |
| [weak-cyclical-industry-selection](weak-cyclical-industry-selection/SKILL.md) | 识别适合长期持有的弱周期性行业，规避经济周期波动风险 | 构建防御性组合、长期养老型资产配置、基于常识的行业筛选时 |
| [value-investor-self-reflection](value-investor-self-reflection/SKILL.md) | 诊断长期亏损原因并理解价值投资实践难度 | 长期亏损、频繁交易、理论学习但实践效果不佳时 |
| [margin-of-safety-valuation](margin-of-safety-valuation/SKILL.md) | 运用安全边际原则进行估值和买入决策 | 评估买入价格、管理估值不确定性、为优质企业确定容错空间时 |
| [ten-year-holding-test](ten-year-holding-test/SKILL.md) | 应用十年持有测试和长期资金心态管理框架 | 考虑买入股票、面对市场波动心态不稳、考虑提取长期资金时 |
| [tcm-enterprise-investment-analysis](tcm-enterprise-investment-analysis/SKILL.md) | 分析中医药企业投资价值，评估国家保密配方的品牌护城河 | 分析同仁堂、云南白药等中药企业、评估大健康领域标的时 |
| [equity-coupon-vs-bond-coupon-valuation](equity-coupon-vs-bond-coupon-valuation/SKILL.md) | 股权票息与债券票息估值比较 | 评估股权相对债券的长期投资价值时 |
| [dividend-yield-valuation](dividend-yield-valuation/SKILL.md) | 对分红稳定的上市公司进行绝对估值，比较股息率与无风险收益率 | 高股息策略、退休投资规划、优质蓝筹股估值分析时 |
| [free-cash-flow-lifecycle-analysis](free-cash-flow-lifecycle-analysis/SKILL.md) | 结合企业生命周期分析自由现金流，判断低现金流性质 | 企业自由现金流异常、评估真实盈利能力、判断成长型企业价值时 |
| [major-shareholder-buyback-valuation-analysis](major-shareholder-buyback-valuation-analysis/SKILL.md) | 分析大股东/管理层增持信号作为估值锚点 | 上市公司出现大股东增持、股价经历显著下跌、判断估值合理性时 |
| [return-expectation-setting](return-expectation-setting/SKILL.md) | 为普通投资者设定合理的年化收益目标，纠正不切实际的暴富预期 | 投资顾问咨询、个人投资规划、避免过度交易的心理建设时 |
| [japan-recession-stock-analysis](japan-recession-stock-analysis/SKILL.md) | 分析经济衰退期长期赢家股票特征，识别防御性投资板块分布 | 研究日股1992-2017数据、经济衰退期投资策略制定时 |
| [leading-company-holding-validation](leading-company-holding-validation/SKILL.md) | 基于历史回测数据验证"选择行业龙头、长期持有"策略的有效性 | 寻求历史证据支持长期投资策略、评估龙头企业投资价值时 |
| [peg-ratio-limitations-analysis](peg-ratio-limitations-analysis/SKILL.md) | 评估成长型公司估值时使用PEG指标并识别其局限性 | 评估具有稳定盈利增长预期的成熟企业或稳定成长型公司时 |
| [premium-brand-investment-screening](premium-brand-investment-screening/SKILL.md) | 评估知名品牌公司的投资价值，识别具备深厚护城河的消费品牌 | 消费品与服务类股票分析、品牌护城河深度调研时 |
| [personal-investment-framework](personal-investment-framework/SKILL.md) | 为个人投资者构建完整的投资体系，包括复利增长理念和被动投资策略 | 业余投资者、有正职工作的投资者解决盲目选择、估值不准、拿不住股票等问题时 |
| [value-investment-mindset](value-investment-mindset/SKILL.md) | 建立价值投资的核心心态和哲学体系 | 构建投资系统、培养合伙人思维、控制投资情绪时 |
| [noahs-ark-investment-strategy](noahs-ark-investment-strategy/SKILL.md) | 执行诺亚方舟分批买入策略，"不预测风雨，只打造方舟" | 市场出现便宜价格、标的为优秀企业、资金为长期性质时 |
| [bull-market-position-management](bull-market-position-management/SKILL.md) | 在牛市行情中管理持仓，"装睡"坚守或转向估值洼地 | 持有优质低估股票面临板块轮动、热点诱惑时的仓位管理决策时 |
| [growth-stock-valuation-risk-analysis](growth-stock-valuation-risk-analysis/SKILL.md) | 分析成长股估值压缩风险，进行情景化反向估值评估安全边际 | 评估高市盈率成长股、分析估值下行风险时 |
| [a股长期牛股行业筛选](a股长期牛股行业筛选/SKILL.md) | 基于A股1996-2016年历史数据回测，筛选长期牛股集中的行业 | 分析A股历史牛股分布、寻找行业配置方向、验证消费医药行业长期价值时 |
| [business-insight-cultivation](business-insight-cultivation/SKILL.md) | 通过阅读企业家传记获取间接经验，培养商业洞察力 | 普通投资者希望提升商业理解能力、选择学习榜样、弥补直接经验不足时 |
| [economic-moat-evaluation](economic-moat-evaluation/SKILL.md) | 识别和评估企业经济护城河（特许经营权），区分真实护城河与虚假陷阱 | 筛选长期投资标的、评估企业竞争优势持久性、识别护城河陷阱时 |
| [investor-pain-point-diagnosis](investor-pain-point-diagnosis/SKILL.md) | 诊断投资者面临的六大核心痛点（宏观与微观层面） | 投资者出现投资失误、绩效持续不佳或情绪困扰时 |
| [margin-of-safety-evaluation](margin-of-safety-evaluation/SKILL.md) | 评估投资是否具备安全边际，包括基于风险的本质定义和静态/动态分类 | 所有证券投资标的、资产配置决策、投资组合风险评估时 |
| [healthcare-sector-leader-strategy](healthcare-sector-leader-strategy/SKILL.md) | 采用"抓龙头"策略投资大健康产业，通过多重优势筛选规避单一业务风险 | 缺乏专业背景但希望投资医药/医疗器械/医疗服务、识别细分领域龙头时 |
| [pharmaceutical-rd-strategy-analysis](pharmaceutical-rd-strategy-analysis/SKILL.md) | 分析医药企业研发驱动战略与全球趋势 | 评估医药企业核心竞争力、对标国际研发基准、追踪前沿疗法趋势时 |
| [investor-growth-career-synergy](investor-growth-career-synergy/SKILL.md) | 帮助投资者理解投资对个人成长和职业发展的积极影响 | 业余投资者、企业领导者希望在投资过程中实现个人能力提升和职业发展时 |
| [investment-style-mismatch-detection](investment-style-mismatch-detection/SKILL.md) | 检测并纠正格派（格雷厄姆）与费派（费雪）投资策略的错误应用 | 考虑对优质企业使用"低估买入高估卖出"或对普通企业使用长期持有策略时 |
| [high-quality-enterprise-screening](high-quality-enterprise-screening/SKILL.md) | 使用巴菲特标准筛选高质量投资标的（ROE>15%、轻资产、持久竞争优势） | 筛选投资候选、避免价值陷阱、寻找长期复利机器时 |
| [cultural-heritage-moat-analysis](cultural-heritage-moat-analysis/SKILL.md) | 分析具有深厚历史文化底蕴的企业是否能构筑独特竞争护城河 | 评估百年品牌、百年老店或具有深厚历史底蕴的企业长期竞争优势时 |
| [growth-quality-assessment](growth-quality-assessment/SKILL.md) | 评估企业成长性质量，识别真正的成长性与伪成长陷阱 | 成长型企业筛选、股票估值对象分析、长期投资组合构建时 |
| [circle-of-competence-definition](circle-of-competence-definition/SKILL.md) | 界定真正的能力圈范围——能看懂商业模式并判断长期竞争优势 | 评估是否理解某家企业、界定自身投资边界、避免能力圈误区时 |
| [bear-market-beach-fishing-strategy](bear-market-beach-fishing-strategy/SKILL.md) | 在大熊市或系统性股灾期间，利用市场极度恐慌进行逆向投资 | 市场出现千股跌停、千股停牌、千股熔断等极端行情，市场情绪极度低迷时 |
| [industry-leader-concentration](industry-leader-concentration/SKILL.md) | 在同一行业内集中配置真正的行业龙头，避免退而求其次 | 在同一行业内选择投资标的、评估行业集中度趋势、判断谁是最终赢家时 |
| [stock-selection-strategies](stock-selection-strategies/SKILL.md) | 运用多种方法筛选优质股票 | 寻找长牛股、快速筛选投资标的、识别高成长潜力企业时 |
| [financial-report-manager-mindset](financial-report-manager-mindset/SKILL.md) | 运用"假想开办公司"的经营者思维深度阅读财报 | 需要充分理解企业本质、把握行业竞争格局、进行深度企业研究时 |
| [chain-service-investment](chain-service-investment/SKILL.md) | 评估连锁服务企业的投资价值，判断商业模式的可复制性 | 连锁扩张验证、成长股筛选、规避复制失败风险时 |
| [century-brand-antique-holding-strategy](century-brand-antique-holding-strategy/SKILL.md) | 对百年品牌稀缺性企业（如同仁堂）的养老/收藏级资产持有策略 | 持有成本较低、市场长期给予估值溢价的百年品牌标的，决定是否因高估值卖出时（严禁用于高成本新建仓） |
| [circle-of-competence-principle](circle-of-competence-principle/SKILL.md) | 在进行任何投资决策前，判断该决策是否在自身能力圈范围内 | 所有投资者面对投资选择时，需要评估自己是否真正理解该行业、企业类型和投资工具时 |
| [investment-discipline-psychology](investment-discipline-psychology/SKILL.md) | 帮助投资者建立投资纪律、管理投资心理、避免常见行为陷阱 | 难以获利的业余投资者和频繁交易者，克服追涨杀跌、追逐热点、预测市场等错误行为时 |
| [five-views-investment-framework](five-views-investment-framework/SKILL.md) | 构建投资思想系统的五观框架（理论观、历史观、全球观、国情观、行业观） | 构建投资思想系统、进入选股/估值/持有环节前准备、校正投资方向时 |
| [stock-selection-framework](stock-selection-framework/SKILL.md) | 应用股票筛选框架，通过负面清单（八不投）和正面清单（九把快刀）识别标的 | 评估A股上市公司、筛选长期价值投资标的、构建核心股票池时 |
| [long-term-value-investing-core](long-term-value-investing-core/SKILL.md) | 建立长期价值投资的核心框架，制定长期持股策略和持有卖出决策标准 | 构建长期投资组合、理解中国股市价值投资有效性、处理持股期间市场波动时 |
| [life-observation-stock-discovery](life-observation-stock-discovery/SKILL.md) | 通过日常生活观察发现消费行业投资机会 | 从电视广告、社交媒体、社交圈子中发现潜在牛股线索，培养"生活即投资"思维时 |
| [bubble-exit-strategy-execution](bubble-exit-strategy-execution/SKILL.md) | 在股票达到泡沫估值时执行纪律性卖出决策 | 持仓达到极端估值、需要避免追涨、执行个性化市盈率上限纪律时 |
| [pharma-repeat-consumption-valuation](pharma-repeat-consumption-valuation/SKILL.md) | 评估慢性非传染性疾病治疗药物的投资价值，区分医药重复消费与烟酒成瘾消费 | 慢性病用药企业和具备治疗依赖特征的药品标的分析时 |
| [stock-selection-methods](stock-selection-methods/SKILL.md) | 股票选择与估值方法 | 筛选优质企业、评估投资标的长期价值、面临选股决策或行业选择时 |
| [china-manufacturing-investment](china-manufacturing-investment/SKILL.md) | 评估中国制造业投资价值，识别制造业崛起主题下的龙头公司 | 布局国家崛起主题、评估中国制造2025相关投资、分析产业升级机会时 |
| [financial-stock-valuation-risk-assessment](financial-stock-valuation-risk-assessment/SKILL.md) | 评估金融股（银行、保险、证券）估值风险，当市净率低于1.0时 | 分析金融股估值、评估市净率跌破净值的风险、评价市销率局限性时 |
| [long-term-investment-risk-return-framework](long-term-investment-risk-return-framework/SKILL.md) | 评估长期投资风险（重新定义风险为永久性损失），计算系统性风险承受能力 | 长期投资者制定投资策略、评估投资组合风险、设定年度收益目标时 |
| [growth-equity-investment-strategy](growth-equity-investment-strategy/SKILL.md) | 构建成长股权投资组合，通过真假成长性识别实现长期超额收益 | 制定超越市场平均收益的股票策略、识别伪成长企业、预判企业未来3-5年增长潜力时 |
| [long-term-holding-strategy](long-term-holding-strategy/SKILL.md) | 长期持有策略与回撤管理 | 持有优秀企业股权面临市场大幅波动、卖出诱惑、需要建立长期持有信心时 |
| [pe-ratio-applicability-assessment](pe-ratio-applicability-assessment/SKILL.md) | 确定市盈率何时适用于估值、何时失效，区分市场层面与个股应用 | 应用市盈率估值前、判断PE指标适用性、避免PE估值陷阱时 |
| [leading-enterprise-dynamic-monitoring](leading-enterprise-dynamic-monitoring/SKILL.md) | 对已持有的行业龙头进行竞争格局动态监测和定期体检 | 行业竞争格局变化、新竞争对手显现优势、需要持续跟踪行业竞争态势时 |
| [roe-calculation-and-dupont-analysis](roe-calculation-and-dupont-analysis/SKILL.md) | 计算净资产收益率（ROE）并使用杜邦分析法拆解盈利能力驱动因素 | 分析企业盈利能力、比较公司绩效、调查ROE变化原因时 |
| [fundamental-based-selling-system](fundamental-based-selling-system/SKILL.md) | 基于基本面恶化条件（商业模式颠覆或竞争根基动摇）的卖出系统 | 考虑卖出长期持有股票、面对股价高估或大幅下跌时，坚决规避情绪驱动卖出 |
| [value-growth-classification](value-growth-classification/SKILL.md) | 按生命周期阶段将股票分类为价值型或成长型，制定差异化组合策略 | 投资组合构建、策略匹配、识别"估值陷阱"与"估值杀"风险时 |
| [dividend-retention-decision](dividend-retention-decision/SKILL.md) | 评估企业不分红决策的合理性，基于费雪和巴菲特投资哲学 | 分析成长型公司、伯克希尔类公司，评估不分红公司投资价值时 |
| [cctv-ad-stock-screening](cctv-ad-stock-screening/SKILL.md) | 通过央视广告快速筛选潜在大牛股候选标的 | 业余投资者初步筛选、识别具有实力的消费品牌、构建初步股票观察池时 |
| [mature-company-investment](mature-company-investment/SKILL.md) | 评估成熟企业投资价值，以股息率与无风险利率比较为核心 | 企业表现出收入增速放缓、净利率提升、寡头地位稳固等成熟特征时 |
| [extreme-bear-market-valuation-comparison](extreme-bear-market-valuation-comparison/SKILL.md) | 对比当前市盈率与2008年大熊市极端估值水平，判定是否处于合理偏下区间 | 市场显著调整期，优质蓝筹股市盈率接近历史危机水平时 |
| [crisis-opportunity-investment](crisis-opportunity-investment/SKILL.md) | 在优质企业遭遇暂时性困难或市场出现系统性风险时识别投资机会 | 行业龙头遭遇黑天鹅事件、增长放缓导致估值杀、市场股灾级别调整时 |
| [market-valuation-timing-principles](market-valuation-timing-principles/SKILL.md) | 理解股票市场预期定价机制（两阶段预期模型）和长期ROE收敛原理 | 分析股票估值与基本面背离、判断成长股买卖时机、评估长期投资价值时 |
| [quality-company-selection](quality-company-selection/SKILL.md) | 为个人投资者提供优质企业筛选方法，采用质量优先原则和合伙人思维 | 业余投资者、有正职工作的投资者从数千家上市公司中筛选2-3家优秀企业时 |
| [relative-victory-leader-investment](relative-victory-leader-investment/SKILL.md) | 投资已确立行业领军地位的A股龙头企业，通过"相对胜出"时机判定实现长期共赢 | 询问何时买入行业龙头、判断企业护城河深度、制定7年以上长期持有策略时 |
| [buying-opportunity-identification](buying-opportunity-identification/SKILL.md) | 识别股市中的重大买入机遇 | 大熊市、黑天鹅事件或牛股调整时寻找买入时机 |
| [comprehensive-financial-analysis](comprehensive-financial-analysis/SKILL.md) | 对上市公司进行全面的财务报表分析和战略解读 | 评估企业财务健康状况、投资价值及管理层战略意图时 |
| [long-term-winner-deep-correction-entry](long-term-winner-deep-correction-entry/SKILL.md) | 在已验证的长牛股出现深度调整、估值进入射猎区时执行分批逐步建仓 | 历史表现优异的成长股、大牛股阶段性回调后的逢低布局（不适用于新股或题材股） |
| [low-valuation-earnings-inflection-add-position](low-valuation-earnings-inflection-add-position/SKILL.md) | 识别并执行历史低估值与业绩拐点叠加时的加仓策略 | 优质成长股估值处于历史低位且最新财报显示收入或利润出现向上拐点时 |
| [analytical-valuation-anti-framing](analytical-valuation-anti-framing/SKILL.md) | 使用分析型思维和保守估值计算克服投资中的框架效应和锚定心理 | 因股价已从历史低点上涨而犹豫，或因锚定历史高点而恐慌时 |
| [value-investing-schools](value-investing-schools/SKILL.md) | 识别价值投资三大流派（格雷厄姆派、费雪派、巴菲特-芒格派）的特征差异 | 梳理价值投资体系、选择投资风格、理解不同大师方法差异时 |
| [consumer-historical-constancy-investing](consumer-historical-constancy-investing/SKILL.md) | 基于"历史恒定性"原则投资消费品行业，识别技术免疫、需求永恒的标的 | 分析食品饮料等消费股投资价值、评估品牌历史延续性、构建长期消费组合时 |
| [personal-investor-guide](personal-investor-guide/SKILL.md) | 个人投资者策略指南，发挥本金较少的个人投资者优势 | 本金较少的个人投资者、业余投资者规划投资生涯、建立长期投资策略时 |
| [medical-sector-investment](medical-sector-investment/SKILL.md) | 分析医疗服务行业投资机会，评估医疗连锁及平台型企业的长期价值 | 专科连锁医院、第三方医疗中心、医药平台生态系统的投资分析时 |
| [pharmaceutical-pricing-power-assessment](pharmaceutical-pricing-power-assessment/SKILL.md) | 评估医药企业是否具备定价权优势 | 分析医药企业护城河、判断企业在医保谈判中的地位、识别抵御政策降价压力的企业时 |
| [business-model-management-evaluation](business-model-management-evaluation/SKILL.md) | 评估企业投资价值时判断商业模式与管理层的优先级关系 | 企业投资分析、商业模式评估和管理层评价，决定优先选择好商业模式还是优秀管理层时 |
| [management-integrity-assessment](management-integrity-assessment/SKILL.md) | 在定性分析阶段评估上市公司管理层是否值得信赖 | 长期投资前的管理层德行审查、排查潜在公司治理风险、进行"一票否决"决策时 |
| [margin-of-safety-principles](margin-of-safety-principles/SKILL.md) | 应用安全边际概念，包括内在价值估计、"模糊正确胜于精确错误"思维 | 评估投资是否具备足够安全边际、寻找" fat pitch "机会时 |
| [long-term-value-investment-strategy](long-term-value-investment-strategy/SKILL.md) | 制定长期价值投资策略，识别优质企业、理解长期持有的理论依据 | 股票投资者、企业价值评估者、长期投资者分析市场资源配置机制时 |
| [investment-opinion-social-sharing](investment-opinion-social-sharing/SKILL.md) | 通过公开分享投资分析获得反馈、验证逻辑、提升认知 | 完成投资分析后希望在雪球、博客等平台发布观点，与同道及反对者建设性互动时 |
| [investment-psychology-decision](investment-psychology-decision/SKILL.md) | 克服投资心理障碍、建立独立决策原则 | 面对市场波动、处理外部信息、确定能力圈、克服买入恐惧时 |
| [scenario-model-validation](scenario-model-validation/SKILL.md) | 验证情景模型估值结论的适用范围与局限性，并进行参数调整 | 使用情景模型（如倒推法）得出估值结论后，确认模型是否适用于当前行业、市场情绪及企业特征时 |
| [national-comparative-advantage-screening](national-comparative-advantage-screening/SKILL.md) | 从宏观视角筛选具备长期潜力的A股标的，寻找具有全球化布局能力的行业龙头 | 基于国家产业竞争力的主题投资、全球化扩张机会识别、长期产业趋势分析时 |
| [tech-platform-investment-evaluation](tech-platform-investment-evaluation/SKILL.md) | 评估科技平台公司投资价值，区分传统科技公司与平台生态型公司 | 互联网巨头估值、平台型公司分析、数字化转型主题投资时 |
| [long-term-investment-fundamentals](long-term-investment-fundamentals/SKILL.md) | 证明股票是长期最优投资工具，解释长期持有如何降低风险，计算复利增长潜力 | 投资教育、养老规划、长期资金配置决策时 |
| [non-sale-asset-evaluation](non-sale-asset-evaluation/SKILL.md) | 评估高股息率蓝筹股是否应归类为"非卖品"，基于个人持有成本计算实际股息率 | 长期持有优质股票、判断是否因恐慌性下跌而卖出、市场剧烈回调期间评估持仓策略时 |
| [manufacturing-tech-platform-evaluation](manufacturing-tech-platform-evaluation/SKILL.md) | 区分制造业与科技公司的投资逻辑，评估"中国制造2025"相关标的 | 先进制造业投资和科技公司的分类评估与风险识别时 |
| [long-term-stock-returns-historical-benchmarks](long-term-stock-returns-historical-benchmarks/SKILL.md) | 进行超长期资产配置决策（≥20年），解释股票相对于债券/黄金/现金的长期优势 | 退休规划、代际财富传承和战略资产配置（SAA）时 |
| [valuation-metrics-and-methods](valuation-metrics-and-methods/SKILL.md) | 对上市公司进行快速估值判断，识别低估值买入机会 | 买入时机判断、周期性估值分析、简易推算决策时 |
| [dividend-strategy-and-permanent-holding](dividend-strategy-and-permanent-holding/SKILL.md) | 评估企业分红质量以验证财务真实性，实施股息再投资策略，判断是否达到负成本基础的永久持有条件 | 高股息策略、被动收入构建、长期持有决策时 |
| [berkshire-investment-framework](berkshire-investment-framework/SKILL.md) | 建立价值投资世界观，辨析不同价值投资流派差异，运用巴菲特-芒格认知工具 | 需要掌握伯克希尔系统的核心原则、思想武器及流派归属判断方法时 |
| [consumer-sector-long-term-investment](consumer-sector-long-term-investment/SKILL.md) | 评估消费行业长期配置价值，识别品质消费升级标的 | 长期价值投资中消费板块（特别是食品饮料等"围着嘴巴转"的领域）的筛选和配置决策时 |
| [buffett-business-classification](buffett-business-classification/SKILL.md) | 运用巴菲特三类生意分类法（梦幻般的生意/良好的生意/糟糕的生意）评估企业 | 判断企业资本回报效率、分析资本支出与收入增长关系、筛选长期股权投资标的时 |
| [fundamental-valuation-methods](fundamental-valuation-methods/SKILL.md) | 评估股票的内在价值、理解股价形成机制，在低市盈率环境下估算投资回报 | 企业整体估值、PE压缩情景分析、投资回报来源拆解时 |
| [equity-vs-property-long-term-allocation](equity-vs-property-long-term-allocation/SKILL.md) | 比较股票与房地产长期投资回报，评估中国家庭资产配置合理性 | 投资期限>10年的跨资产类别长期配置决策、房产投资评估、家庭财富规划时 |
| [fundamental-stock-screening](fundamental-stock-screening/SKILL.md) | 从财务质量和商业模式角度筛选可长期持有的优质企业 | 构建核心股票池、排除劣质标的、深度基本面分析时 |
| [portfolio-performance-metrics-calculation](portfolio-performance-metrics-calculation/SKILL.md) | 计算投资组合净值（NAV）、年化复合增长率（CAGR）、总收益率 | 定期投资绩效评估、仓位再平衡决策和长期投资跟踪时 |
| [industry-destiny-analysis](industry-destiny-analysis/SKILL.md) | 运用行业命相分析框架，区分稳定割据型、赢家通吃型、混战苦命型三类行业 | 进行行业投资价值评估、筛选长期投资标的、分析行业竞争格局时 |
| [investment-research-writing](investment-research-writing/SKILL.md) | 通过深度写作暴露认知漏洞并深化思考，验证真实理解程度 | 研究完某一投资问题或具体企业案例后自认为已经弄通弄懂，需要固化投资感悟时 |
| [post-crash-value-strategy](post-crash-value-strategy/SKILL.md) | 市场经历股灾或剧烈调整后，放弃市场时机预测并转向以企业价值为核心的长期持有战略 | 灾后重建期构建防御型"挪亚方舟"组合，利用灾后分化期优化配置时 |
| [big-health-aging-investment-framework](big-health-aging-investment-framework/SKILL.md) | 评估大健康产业长期投资价值，分析中国老龄化社会医药健康投资机会 | 老龄化主题投资和医药板块战略配置决策时 |
| [global-equity-bull-stock-industry-patterns](global-equity-bull-stock-industry-patterns/SKILL.md) | 识别长期大牛股高发行业，进行跨市场行业配置验证 | 20年以上投资期限的行业比较研究和全球权益配置时 |
| [family-wealth-inheritance-planning](family-wealth-inheritance-planning/SKILL.md) | 为子女规划长期财富积累，建立以子女名义但由父母管理的长期股票账户体系 | 准备嫁妆或教育金、通过股票投资对抗长期通胀并实现代际财富传承时 |
| [long-term-portfolio-execution](long-term-portfolio-execution/SKILL.md) | 构建投资体系、决定集中或分散配置、选择长期持有标的、抵制波段操作诱惑 | 建立以"超级印钞机"企业为核心的长期投资组合时 |
| [graham-perpetual-growth-valuation](graham-perpetual-growth-valuation/SKILL.md) | 评估具有永续经营特征企业（消费、医药等长寿型企业）的长期内在价值 | 成长股估值、长期价值投资分析，特别是具备品牌护城河、需求稳定的企业时 |
| [value-investing-psychology-management](value-investing-psychology-management/SKILL.md) | 建立正确的投资心态、收益预期和心理素质框架，培养长期持有所需的定力 | 面临短期业绩落后压力、产生暴富幻想、感到投资焦虑痛苦时 |
| [investment-anchoring-bias-recognition](investment-anchoring-bias-recognition/SKILL.md) | 识别框架效应与锚定心理，切换至分析型思维进行理性估值 | 买卖决策受历史价格、持仓成本或市场指数锚定，产生"不敢想象"特定价格水平时 |
| [china-a-share-valuation-adjusted-return-analysis](china-a-share-valuation-adjusted-return-analysis/SKILL.md) | 计算中国A股市场长期真实收益率，消除估值波动扭曲 | 评估股市长期投资价值、与国际市场比较、反驳"中国股市不涨"的误判时 |

## Quick Navigation

### 投资哲学与系统构建
- **[investment-worldview-methodology-framework]**: 构建投资世界观与方法论二元框架
- **[value-investment-framework]**: 建立五维价值投资系统框架
- **[five-views-investment-framework]**: 构建投资思想系统的五观框架
- **[berkshire-investment-framework]**: 掌握伯克希尔系统的核心原则与思想武器
- **[value-investment-mindset]**: 建立价值投资核心心态和哲学体系
- **[personal-investment-framework]**: 为业余投资者构建完整投资体系
- **[long-term-value-investing-core]**: 建立长期价值投资核心框架

### 选股与行业分析
- **[stock-selection-framework]**: 通过负面清单（八不投）和正面清单（九把快刀）筛选标的
- **[quality-first-selection]**: 确立"质地优先于价格"的选股原则
- **[weak-cyclical-industry-selection]**: 识别适合长期持有的弱周期性行业
- **[high-quality-enterprise-screening]**: 使用巴菲特标准筛选高质量企业（ROE>15%、轻资产）
- **[economic-moat-evaluation]**: 识别和评估企业经济护城河（特许经营权）
- **[industry-destiny-analysis]**: 运用行业命相分析框架（稳定割据/赢家通吃/混战苦命）
- **[circle-of-competence-definition]**: 界定真正的能力圈范围
- **[stock-selection-strategies]**: 运用多种方法筛选优质股票

### 估值方法与工具
- **[valuation-philosophy-and-framework]**: 建立正确的估值心态与四因素敏感性框架
- **[margin-of-safety-valuation]**: 运用安全边际原则进行估值和买入决策
- **[dividend-yield-valuation]**: 基于股息率与无风险收益率比较进行绝对估值
- **[free-cash-flow-lifecycle-analysis]**: 结合生命周期分析自由现金流
- **[peg-ratio-limitations-analysis]**: 使用PEG指标并识别其局限性
- **[pe-ratio-applicability-assessment]**: 确定市盈率何时适用、何时失效
- **[graham-perpetual-growth-valuation]**: 评估永续经营企业的长期内在价值
- **[fundamental-valuation-methods]**: 评估股票内在价值与股价形成机制
- **[valuation-metrics-and-methods]**: 快速估值判断与低估值买入识别

### 买卖与持有策略
- **[ten-year-holding-test]**: 应用"不愿持有十年则不持有一分钟"的筛选原则
- **[noahs-ark-investment-strategy]**: 执行诺亚方舟分批买入策略
- **[fundamental-based-selling-system]**: 基于基本面恶化（商业模式颠覆）的卖出系统
- **[bull-market-position-management]**: 牛市行情中"装睡"坚守或转向估值洼地
- **[bear-market-beach-fishing-strategy]**: 大熊市期间"海滩拾鱼"逆向投资
- **[bubble-exit-strategy-execution]**: 股票达到泡沫估值时执行纪律性卖出
- **[long-term-winner-deep-correction-entry]**: 长牛股深度调整后的分批建仓
- **[low-valuation-earnings-inflection-add-position]**: 低估值与业绩拐点叠加时的加仓
- **[century-brand-antique-holding-strategy]**: 百年品牌养老级资产的持有策略（高估值也不卖出）

### 特定行业投资
- **[tcm-enterprise-investment-analysis]**: 中医药企业（同仁堂、片仔癀等）投资价值分析
- **[healthcare-sector-leader-strategy]**: 大健康产业"抓龙头"投资策略
- **[pharmaceutical-rd-strategy-analysis]**: 医药企业研发驱动战略分析
- **[pharmaceutical-pricing-power-assessment]**: 评估医药企业定价权优势
- **[pharma-repeat-consumption-valuation]**: 慢性病用药重复消费估值
- **[consumer-historical-constancy-investing]**: 基于"历史恒定性"投资消费品行业
- **[premium-brand-investment-screening]**: 评估知名品牌公司投资价值
- **[chain-service-investment]**: 评估连锁服务企业投资价值与可复制性
- **[china-manufacturing-investment]**: 评估中国制造业崛起主题投资机会
- **[tech-platform-investment-evaluation]**: 评估科技平台公司（互联网巨头）投资价值
- **[financial-stock-valuation-risk-assessment]**: 金融股（银行、保险、证券）估值风险评估

### 风险管理与安全边际
- **[margin-of-safety-evaluation]**: 评估投资是否具备安全边际（静态/动态分类）
- **[margin-of-safety-principles]**: 应用"模糊正确胜于精确错误"的安全边际思维
- **[growth-stock-valuation-risk-analysis]**: 分析成长股估值压缩风险与情景化反向估值
- **[extreme-bear-market-valuation-comparison]**: 对比当前估值与2008年大熊市极端水平
- **[crisis-opportunity-investment]**: 优质企业遭遇暂时性困难时的危机投资机会识别
- **[long-term-investment-risk-return-framework]**: 重新定义风险为永久性损失，计算长期风险承受能力

### 投资心态与纪律
- **[investment-psychology-discipline]**: 建立投资心理定力，克服人性弱点
- **[investor-pain-point-diagnosis]**: 诊断投资者六大核心痛点（宏观与微观层面）
- **[investment-discipline-psychology]**: 建立投资纪律，避免追涨杀跌等行为陷阱
- **[value-investing-psychology-management]**: 管理短期业绩落后压力与暴富幻想
- **[investment-anchoring-bias-recognition]**: 识别并克服锚定心理与框架效应
- **[analytical-valuation-anti-framing]**: 使用分析型思维克服价格锚定
- **[return-expectation-setting]**: 设定合理的年化收益目标（纠正不切实际的暴富预期）

### 投资组合管理
- **[long-term-portfolio-execution]**: 构建以"超级印钞机"企业为核心的长期组合
- **[portfolio-performance-metrics-calculation]**: 计算投资组合NAV、CAGR、总收益率
- **[equity-vs-property-long-term-allocation]**: 股票与房地产长期投资回报比较
- **[family-wealth-inheritance-planning]**: 为子女规划长期财富积累与代际传承
- **[dividend-strategy-and-permanent-holding]**: 股息再投资策略与负成本基础永久持有
- **[non-sale-asset-evaluation]**: 评估高股息蓝筹股是否应归类为"非卖品"

### 市场分析与历史验证
- **[japan-recession-stock-analysis]**: 分析日本1992-2017年衰退期长期赢家特征
- **[a股长期牛股行业筛选]**: 基于A股1996-2016年数据筛选长期牛股集中行业
- **[leading-company-holding-validation]**: 验证"选择行业龙头、长期持有"策略的历史有效性
- **[global-equity-bull-stock-industry-patterns]**: 识别美股/日股/A股长期大牛股行业分布规律
- **[china-a-share-valuation-adjusted-return-analysis]**: 计算A股长期真实收益率（消除估值波动扭曲）
- **[long-term-stock-returns-historical-benchmarks]**: 股票相对于债券/黄金/现金的长期收益基准

### 企业分析与定性研究
- **[financial-report-manager-mindset]**: 以"假想开办公司"的经营者思维阅读财报
- **[comprehensive-financial-analysis]**: 全面财务报表分析与战略解读
- **[business-model-management-evaluation]**: 评估商业模式与管理层的优先级关系
- **[management-integrity-assessment]**: 评估管理层是否值得信赖（一票否决）
- **[growth-quality-assessment]**: 评估企业成长性质量，识别伪成长陷阱
- **[buffett-business-classification]**: 运用巴菲特三类生意分类法（梦幻/良好/糟糕）
- **[leading-enterprise-dynamic-monitoring]**: 对行业龙头进行竞争格局动态监测
- **[cultural-heritage-moat-analysis]**: 分析历史文化底蕴是否构筑独特护城河

### 投资者成长与方法论
- **[business-insight-cultivation]**: 通过阅读企业家传记培养商业洞察力
- **[investor-growth-career-synergy]**: 理解投资对个人成长和职业发展的积极影响
- **[investment-style-mismatch-detection]**: 检测格派与费派投资策略的错误应用
- **[value-investor-self-reflection]**: 诊断长期亏损原因与价值投资实践难度
- **[investment-research-writing]**: 通过深度写作验证理解程度并固化投资感悟
- **[investment-opinion-social-sharing]**: 通过公开分享获得反馈并提升认知
- **[personal-investor-guide]**: 发挥本金较少的个人投资者优势

## How to Use

1. **明确当前投资阶段**：首先判断自己处于投资流程的哪个环节（哲学构建、选股、估值、买入、持有、卖出、心态调整）。

2. **匹配技能场景**：根据上表"Use When"列或快速导航分类，找到与当前任务最匹配的技能。

3. **调用技能**：在 Claude Code 对话中直接提及技能名称（如"请使用 `ten-year-holding-test` 技能帮我分析是否应该买入这只股票"），或描述当前面临的场景，Claude 将自动匹配相应技能。

4. **遵循技能指引**：每个技能都包含特定的分析框架、检查清单和决策流程，请按照技能文档中的步骤逐一执行。

5. **交叉验证**：重大投资决策建议同时使用多个相关技能进行交叉验证（如选股时使用 `economic-moat-evaluation` + `quality-first-selection`，估值时使用 `margin-of-safety-valuation` + `dividend-yield-valuation`）。

**注意**：本技能库基于长期价值投资理念构建，适用于以年为单位的投资决策，不适用于短期交易或技术分析。
```