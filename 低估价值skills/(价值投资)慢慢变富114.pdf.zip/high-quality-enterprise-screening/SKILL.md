---
name: High Quality Enterprise Screening
description: Screen for high-quality investment targets using Buffett-style criteria focusing on ROE > 15%, light asset model, and durable competitive advantages. Use when filtering investment candidates, avoiding capital-intensive businesses, or identifying companies with strong profitability and economic moats. Triggers on requests for stock screening, quality company identification, or Buffett investment methodology application.
---

# 轻资产高盈利企业筛选法

## 何时使用

- 需要筛选盈利性强的投资标的时
- 希望避开"烧钱机器"和限制性盈余多的企业时
- 应用巴菲特投资哲学进行企业筛选时
- 建立长期核心持仓股票池时

## 三层过滤框架

### 第一层：定性排除

**排除重资产企业特征：**
- 资本开支占经营现金流比例 > 50%
- 需要持续大额投入维持市场地位
- 固定资产周转率低
- 属于"烧钱机器"模式

**目标企业画像（四要素）：**
| 要素 | 识别标准 |
|-----|---------|
| 轻资产 | 有形资产/总收入比例低 |
| 小资本开支 | 维护性CAPEX低，自由现金流充裕 |
| 消费垄断 | 定价权强，客户粘性高 |
| 品牌商誉 | 无形资产价值巨大 |

### 第二层：核心指标筛选

**首要指标：ROE（巴菲特最钟情指标）**

```
合格标准：长期ROE > 15%
关键要求："长期"而非单一年份，至少5-10年数据
```

> 快速过滤掉没有回报的企业

### 第三层：交叉验证

| 验证指标 | 公式 | 优秀标准 | 验证目的 |
|---------|------|---------|---------|
| ROA | 净利润/总资产 | > 6% | 资产使用效率 |
| ROIC | 税后净营业利润/投入资本 | > 12% | 真实投资回报 |

**通过标准：**三项指标同步优秀，无明显短板

## 完整筛选流程

```
步骤1：定性排除重资产、高资本开支企业
    ↓
步骤2：识别消费垄断、品牌商誉特征
    ↓  
步骤3：检验ROE长期>15%
    ↓
步骤4：交叉验证ROA、ROIC
    ↓
步骤5：通过 = 高盈利性投资标的
```

## 输出模板

```
【企业筛选结果】
公司名称：[名称]

【定性评估】
资产模式：[轻资产/重资产]
竞争优势：[消费垄断/品牌/成本/网络效应/无]
资本需求：[低/中/高]

【量化指标】
5年平均ROE：X.XX% [✓/>15% 或 ✗/<15%]
ROA：X.XX% [✓/>6% 或 ✗/<6%]
ROIC：X.XX% [✓/>12% 或 ✗/<12%]

【综合判定】[通过/不通过] —— [核心原因]
```