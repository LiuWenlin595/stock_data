# 东阿阿胶2015年案例分析

## 基本情况
- **市值**：295.49亿元
- **2014年净利润**：13.66亿元
- **2015年涨幅**：仅9.53%（显著跑输大盘）
- **高点回撤**：28.76%

## 估值变化
- **2014年市盈率**：21.63倍
- **2015年预期市盈率**：18.03倍（进一步压缩）
- **估值判断**：处于历史低位区间

## 关键信号
- **2015年Q1收入增长**：50%以上
- **业绩拐点确认**：从低速增长转向加速增长
- **基本面**：核心竞争力未受损

## 决策执行
- **市场情绪**：恐慌性下跌
- **策略选择**：利用下跌加大仓位而非恐慌卖出
- **决策依据**：估值历史低位 + 业绩拐点确认 + 基本面稳固

## 关键数据指标

### 变量定义
| 变量名 | 类型 | 说明 | 示例值 |
|--------|------|------|--------|
| 当前市盈率 | ratio | 当前股价/每股收益 | 18.03倍 |
| 历史市盈率区间 | range | 该股票过去5-10年的市盈率波动范围 | 15-35倍 |
| 季度收入增长率 | percentage | 最新季度营业收入同比增长率 | 50%以上 |
| 业绩拐点信号 | boolean | 是否出现从低速到高速增长的明确转折证据 | true |

### 价值陷阱识别
以下情况**不适用**此策略：
1. 行业整体衰退导致的低估值
2. 公司竞争力丧失导致的业绩下滑
3. 财务造假或治理问题
4. 一次性收益造成的业绩虚高

### 周期性与长期拐点区分

**周期性行业拐点**：
- 受宏观经济周期影响
- 增长持续性有限
- 需结合行业周期位置判断

**长期增长拐点**：
- 受企业自身竞争力驱动
- 增长具有可持续性
- 重点关注市场份额、产品创新等内在因素

## 执行模板

```python
# 决策逻辑伪代码
def should_add_position(current_pe, historical_pe_range, quarterly_growth, fundamentals_solid):
    
    # 检查估值是否处于历史低位
    valuation_low = current_pe <= historical_pe_range[0] * 1.2  # 允许20%容差
    
    # 检查业绩拐点
    earnings_inflection = quarterly_growth > 30  # 假设30%为显著加速阈值
    
    # 检查基本面
    fundamentals_ok = fundamentals_solid
    
    # 决策矩阵
    if valuation_low and earnings_inflection and fundamentals_ok:
        return "加仓"
    elif valuation_low and not earnings_inflection and fundamentals_ok:
        return "持有观望"
    elif not fundamentals_ok:
        return "卖出止损"
    else:
        return "进一步分析"
```