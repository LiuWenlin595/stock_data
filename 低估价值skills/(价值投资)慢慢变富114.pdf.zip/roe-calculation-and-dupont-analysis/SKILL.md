---
name: ROE Calculation and DuPont Analysis
description: Calculate Return on Equity (ROE) and decompose it using DuPont analysis to diagnose profitability drivers. Use when analyzing enterprise profitability, comparing company performance, or investigating the sources of ROE variation. Triggers on requests involving ROE calculation, DuPont decomposition, or profitability driver analysis.
---

# ROE计算与杜邦分析

## 何时使用

- 需要量化企业盈利能力时
- 需要拆解ROE来源、诊断盈利驱动因素时
- 比较不同企业或同一企业不同时期的ROE表现时
- 分析净利润与净资产关系的变化原因时

## 核心流程

### 第一步：选择ROE类型

明确使用的ROE计算方式：
- **加权扣非ROE**（推荐）：更准确反映经营绩效，剔除非经常性损益影响
- **摊薄ROE**：基于期末净资产计算
- **加权ROE**：考虑期间净资产变动

> 优先使用"加权扣非后的净资产收益率"进行跨期比较

### 第二步：基础计算

```
ROE = 净利润 / 净资产
```

反映一年内净资产的回报情况。

### 第三步：杜邦分解（核心）

将ROE分解为三个驱动因子：

```
ROE = 销售净利率 × 资产周转率 × 权益乘数
```

| 因子 | 公式 | 含义 |
|------|------|------|
| 销售净利率 | 净利润 / 收入 | 盈利能力 |
| 资产周转率 | 收入 / 总资产 | 运营效率 |
| 权益乘数 | 总资产 / 净资产 | 财务杠杆 |

### 第四步：诊断分析

根据三因子的组合判断企业盈利模式：
- **高净利率型**：品牌/技术壁垒（如茅台）
- **高周转率型**：薄利多销模式（如零售）
- **高杠杆型**：金融/房地产行业
- **均衡型**：综合竞争力强

## 辅助公式

每股收益推导：
```
每股收益 = 净资产收益率 × 每股资产净值
```

> 注意：低ROE企业可通过增发、少分红增加每股净资产来推高EPS，需警惕此操纵手段。

## 输出模板

```
【ROE分析结果】
ROE类型：[加权扣非/摊薄/加权]
ROE数值：X.XX%

【杜邦三因子分解】
销售净利率：X.XX% → 贡献度分析
资产周转率：X.XX次 → 效率评估  
权益乘数：X.XX倍 → 杠杆风险

【盈利模式判断】[高净利率/高周转/高杠杆/均衡]型
【关键洞察】[哪个因子是主要驱动/制约因素]
```