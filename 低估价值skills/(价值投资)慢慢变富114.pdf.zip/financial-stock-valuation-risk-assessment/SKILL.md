---
name: Financial Stock Valuation Risk Assessment
description: Assess valuation risks for financial sector stocks (banks, insurance, securities) when price-to-book ratio falls below 1.0, and evaluate price-to-sales ratio limitations. Use when analyzing financial stocks trading below book value, or when considering P/S ratio for loss-making or cross-industry comparisons. Triggers on financial stock undervaluation analysis, P/B < 1.0 scenarios, or P/S ratio usage decisions.
---

# 金融股估值风险评估与市销率局限性

## 第一部分：金融股市净率低于1.0风险警示

### 何时触发

- 分析银行、保险、证券公司等金融类股票时
- 发现目标公司市净率(P/B) < 1.0
- 考虑"抄底"低估值金融股时

### 风险识别流程

```
步骤1：确认市净率 < 1.0
    ↓
步骤2：立即暂停买入决策，标记为"需深入调查"
    ↓
步骤3：获取详细资产负债表
    ↓
步骤4：重点核查三项指标
    ↓
步骤5：评估账面价值真实可靠性
    ↓
步骤6：决策 → 可靠则可能是机会 / 不可靠则回避
```

### 必查项目清单

| 核查项目 | 关注要点 | 危险信号 |
|---------|---------|---------|
| 不良贷款规模 | 不良率、关注类贷款迁徙 | 不良率持续上升 |
| 资产减值准备 | 拨备覆盖率、拨贷比 | 拨备覆盖率<150% |
| 金融资产质量 | 非标资产、影子银行敞口 | 复杂结构化产品占比高 |
| 风险敞口披露 | 表外业务、衍生品头寸 | 披露不充分或模糊 |

### 关键认知

> 市净率<1.0对金融股**更可能是风险信号而非机会信号**
> 
> 与一般企业不同，金融股的账面价值可靠性高度依赖资产质量

---

## 第二部分：市销率使用约束

### 禁止场景

| 场景 | 原因 | 替代方案 |
|-----|------|---------|
| 作为唯一估值依据 | 忽略盈利能力，高销售额可能伴随亏损 | 结合利润率分析 |
| 跨行业比较 | 不同行业利润率差异巨大 | 行业内比较或结合P/E、EV/EBITDA |
| 亏损公司估值 | 无法判断收益水平 | 使用P/B或重置成本法 |

### 使用原则

1. **盈利验证优先**：高销售收入必须结合利润率分析
2. **单笔交易检验**：确认公司每笔交易是否盈利（而非仅总量盈利）
3. **辅助参考定位**：仅作为知识储备，非核心估值工具

### 风险警示模板

```
【市销率使用警告】
目标公司：[名称]
销售收入：[金额]
净利润率：[X.XX% / 未知 / 负值]

⚠️ 若净利润率<5%或未知/为负，市销率将产生严重误导
⚠️ 禁止与[其他行业名称]进行跨行业比较

建议：改用[具体替代估值方法]
```