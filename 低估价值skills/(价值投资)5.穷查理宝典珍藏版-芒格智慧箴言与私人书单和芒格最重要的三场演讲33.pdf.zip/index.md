```markdown
# 芒格智慧技能集

本技能集源自查理·芒格的多元思维模型与人生智慧，涵盖投资决策、商业分析、心理学应用、沟通技巧、职业发展和人生哲学等领域。这些技能帮助用户运用跨学科知识做出更明智的决策，避免常见认知偏差，并在复杂情境中找到最优解。

## Available Skills

| Skill | Description | Use When |
|-------|-------------|----------|
| [avoid-stereotyping-evaluation](avoid-stereotyping-evaluation/SKILL.md) | 避免基于群体统计特征对个体进行类型化判断的错误 | 招聘评估、投资决策、人才盘点等需要评估个体而非群体的场景 |
| [biographical-memoir-writing](biographical-memoir-writing/SKILL.md) | 帮助个人记录生活经历，创建可供长期保存的回忆录 | 希望保存个人记忆、家族历史或重要人生经历时 |
| [borrowed-item-return-protocol](borrowed-item-return-protocol/SKILL.md) | 按"优于借用时状态"原则归还他人物品，维护信任关系 | 借用车辆、工具、书籍等贵重物品后需要深化信任关系时 |
| [persian-messenger-syndrome-prevention](persian-messenger-syndrome-prevention/SKILL.md) | 建立组织信息机制确保坏消息及时上达决策者 | 需要克服领导者对坏消息的情绪厌恶，建立真实信息流通渠道时 |
| [derivative-book-value-risk-assessment](derivative-book-value-risk-assessment/SKILL.md) | 评估金融机构衍生品持仓的账面价值虚高风险 | 分析银行、保险公司的衍生品账本风险，识别会计标准宽松导致的价值高估时 |
| [mr-market-contrarian-investing](mr-market-contrarian-investing/SKILL.md) | 运用"市场先生"心智模型，在市场情绪极端时执行逆向投资 | 市场恐慌或狂热导致价格严重偏离内在价值时的买卖决策 |
| [pricing-power-identification](pricing-power-identification/SKILL.md) | 识别具备未利用定价权的优质企业，评估长期投资价值 | 企业拥有市场领先地位、产品需求价格弹性低、存在进入壁垒时 |
| [five-ws-communication-principle](five-ws-communication-principle/SKILL.md) | 应用五何原则进行高遵从度沟通，强制包含五要素 | 企业内部沟通、管理指令发布、跨部门协作等需要确保信息准确执行的场景 |
| [newton-principia-classical-mechanics](newton-principia-classical-mechanics/SKILL.md) | 分析牛顿《自然哲学的数学原理》的核心贡献与历史地位 | 研究物理学史、经典力学基础或牛顿科学成就时 |
| [cicero-late-life-philosophy](cicero-late-life-philosophy/SKILL.md) | 基于西塞罗《论老年》的晚年生活哲学指南 | 处于晚年阶段、考虑退休、面对衰老焦虑或寻求晚年生活意义时 |
| [competitive-destruction-surfing-model](competitive-destruction-surfing-model/SKILL.md) | 分析技术变革对行业的毁灭性影响，识别"冲浪"位置企业 | 评估创新战略、寻找长期投资标的或判断传统行业转型风险时 |
| [partnership-commitment-recovery](partnership-commitment-recovery/SKILL.md) | 合伙制企业项目进度落后时启动高强度联合工作模式补救 | 已建立合作关系的合伙人团队需要共同承担极端工作强度完成项目时 |
| [hate-bias-and-social-conformity-mechanisms](hate-bias-and-social-conformity-mechanisms/SKILL.md) | 分析仇恨情绪导致的认知偏差及群体压力下的非理性模仿 | 识别因憎恨产生的判断扭曲或困惑/压力下的社会认同影响时 |
| [procurement-zero-gift-defense](procurement-zero-gift-defense/SKILL.md) | 防止供应商通过小恩小惠触发采购人员的潜意识回馈倾向 | 使用第三方资金进行采购，需要消除潜意识心理操纵风险时 |
| [long-term-stock-option-valuation](long-term-stock-option-valuation/SKILL.md) | 处理期限超过90天的股票期权估值与会计处理 | 期权期限>90天、涉及股票期权会计处理或设计长期期权薪酬方案时 |
| [comparative-advantage-analysis](comparative-advantage-analysis/SKILL.md) | 应用比较优势理论确定最优专业化分工和交换策略 | 分析国家间贸易、企业管理中的任务分配或资源配置决策时 |
| [reason-respecting-communication](reason-respecting-communication/SKILL.md) | 通过提供理由显著提高服从度和理解效率的沟通方式 | 发布命令、传授知识或说服他人，需要提升管理效能时 |
| [tragedy-of-the-commons-and-carrying-capacity-analysis](tragedy-of-the-commons-and-carrying-capacity-analysis/SKILL.md) | 分析公共资源管理中的过度消耗风险与人口资源冲突 | 全球生态系统评估、人口政策制定及可持续发展规划时 |
| [multi-disciplinary-thinking-models](multi-disciplinary-thinking-models/SKILL.md) | 构建和应用跨学科思维模型体系解决复杂问题 | 面临复杂决策、需要多角度分析问题或试图理解世界本质时 |
| [scale-advantage-analysis](scale-advantage-analysis/SKILL.md) | 识别和分析企业规模优势的类型（几何学、广告、社会认同、赢家通吃） | 分析企业竞争优势、商业模式或市场地位时 |
| [economic-growth-morality-assessment](economic-growth-morality-assessment/SKILL.md) | 评估国家经济增长政策的道德政治影响 | 讨论经济增长的道德后果、评估发展政策或分析收入停滞对民主制度的威胁时 |
| [family-education-legacy](family-education-legacy/SKILL.md) | 通过日常行为和情感联结传递价值观，建立家族教育传统 | 进行家庭教育、培养子女或传承家族价值观时 |
| [communication-and-negotiation](communication-and-negotiation/SKILL.md) | 运用有效的沟通和谈判策略，包括原则谈判、冲突管理 | 需要达成共识、解决冲突或进行商业谈判时 |
| [career-development-framework](career-development-framework/SKILL.md) | 从人、机遇、未来、主导权和工作内容五维度评估工作机会 | 寻找新工作、评估当前职业路径或进行职业规划时 |
| [life-wisdom-and-success-principles](life-wisdom-and-success-principles/SKILL.md) | 应用芒格的人生智慧和成功原则，包括逆向思维、配得性原则 | 追求个人成长、制定人生决策或寻求成功路径时 |
| [knowledge-acquisition-methods](knowledge-acquisition-methods/SKILL.md) | 通过阅读商业杂志、学习跨学科知识积累智慧 | 需要提升认知能力、积累投资智慧或进行终身学习时 |
| [value-investment-strategy](value-investment-strategy/SKILL.md) | 应用价值投资的核心策略，包括集中投资、能力圈原则 | 进行投资决策、评估企业质量或配置资本时 |
| [incentive-system-design](incentive-system-design/SKILL.md) | 设计和评估激励机制，确保激励与工作成果直接关联 | 设计工作制度、评估组织效率或进行职业规划时 |
| [personal-habits-and-lifestyle](personal-habits-and-lifestyle/SKILL.md) | 坚持经久耐用、庄重正统的个人习惯和着装原则 | 选择服装、建立个人习惯或评估生活方式时 |
| [societal-survival-analysis](societal-survival-analysis/SKILL.md) | 评估社会面临环境危机时的制度响应能力和存续可能性 | 分析社会崩溃风险、评估环境政策或研究文明兴衰时 |
| [financial-assessment-reality-check](financial-assessment-reality-check/SKILL.md) | 评估财务假设的现实性，识别管理层主观偏差 | 分析公司财务报表、评估养老基金假设或判断盈利质量时 |
| [misjudgment-psychology](misjudgment-psychology/SKILL.md) | 理解和应用误判心理学原则，识别人类认知偏差 | 需要理解人类行为、做出重要决策或防范认知陷阱时 |
| [merchant-scholar-paradigm](merchant-scholar-paradigm/SKILL.md) | 践行"商才士魂"的现代成功范式，商业成功与道德修养并重 | 追求商业与道德双重成就、进行自我修养或规划人生道路时 |

## Quick Navigation

### 投资决策
- **[mr-market-contrarian-investing]**: 市场极端情绪时逆向投资
- **[pricing-power-identification]**: 识别具备定价权的企业
- **[value-investment-strategy]**: 价值投资核心策略应用
- **[competitive-destruction-surfing-model]**: 技术变革中的"冲浪"机会
- **[derivative-book-value-risk-assessment]**: 衍生品账面价值风险评估
- **[long-term-stock-option-valuation]**: 长期股票期权估值

### 商业分析
- **[scale-advantage-analysis]**: 企业规模优势类型识别
- **[comparative-advantage-analysis]**: 比较优势与专业化分工
- **[incentive-system-design]**: 激励机制设计
- **[financial-assessment-reality-check]**: 财务假设现实性检验
- **[economic-growth-morality-assessment]**: 经济增长政策道德评估

### 心理学与认知
- **[misjudgment-psychology]**: 误判心理学与认知偏差
- **[hate-bias-and-social-conformity-mechanisms]**: 仇恨偏见与社会认同机制
- **[avoid-stereotyping-evaluation]**: 避免类型化评估错误
- **[reason-respecting-communication]**: 理由尊重型沟通

### 沟通与谈判
- **[five-ws-communication-principle]**: 五何原则高遵从度沟通
- **[communication-and-negotiation]**: 有效沟通与谈判策略
- **[persian-messenger-syndrome-prevention]**: 防止"波斯信使综合征"

### 职业与个人发展
- **[career-development-framework]**: 五维度职业评估框架
- **[life-wisdom-and-success-principles]**: 芒格人生智慧与成功原则
- **[knowledge-acquisition-methods]**: 知识获取与终身学习方法
- **[personal-habits-and-lifestyle]**: 个人习惯与生活方式
- **[merchant-scholar-paradigm]**: "商才士魂"现代范式

### 人际关系与信任
- **[borrowed-item-return-protocol]**: 物品归还与信任维护
- **[partnership-commitment-recovery]**: 合伙承诺补救机制
- **[family-education-legacy]**: 家族教育与价值观传承
- **[biographical-memoir-writing]**: 个人回忆录撰写

### 组织与制度
- **[procurement-zero-gift-defense]**: 采购零礼品防御机制
- **[tragedy-of-the-commons-and-carrying-capacity-analysis]**: 公地悲剧与承载力分析
- **[societal-survival-analysis]**: 社会存续能力分析

### 跨学科思维
- **[multi-disciplinary-thinking-models]**: 跨学科思维模型体系
- **[newton-principia-classical-mechanics]**: 牛顿经典力学体系
- **[cicero-late-life-philosophy]**: 西塞罗晚年生活哲学

## How to Use

1. **识别场景**：根据当前任务或问题，判断所属领域（投资、商业、沟通、心理等）
2. **匹配技能**：查阅"Quick Navigation"找到最相关的技能，或直接浏览"Available Skills"表格
3. **查看详情**：点击技能名称链接，阅读完整的SKILL.md文件了解详细使用方法
4. **触发条件**：注意每个技能的"Use When"触发条件，确保在合适场景下应用
5. **组合使用**：复杂问题可组合多个技能，如投资决策可结合"value-investment-strategy"+"misjudgment-psychology"+"mr-market-contrarian-investing"

> **提示**：这些技能基于芒格的多元思维模型，强调跨学科知识的整合应用。遇到复杂问题时，主动调用[multi-disciplinary-thinking-models]作为基础框架。
```