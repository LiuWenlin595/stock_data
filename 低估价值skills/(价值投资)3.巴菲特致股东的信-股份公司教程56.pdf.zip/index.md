```markdown
# 伯克希尔·哈撒韦价值投资技能集

本技能集源自伯克希尔·哈撒韦投资哲学的专业文献，涵盖沃伦·巴菲特与查理·芒格的核心投资框架、企业估值方法、资本配置策略及公司治理原则。这些技能帮助用户应用经过验证的价值投资方法，进行企业分析、投资决策、并购评估和风险管理。

## Available Skills

| Skill | Description | Use When |
|-------|-------------|----------|
| [preferred-stock-performance-evaluation](preferred-stock-performance-evaluation/SKILL.md) | 评估优先股投资组合的多维度业绩表现 | 分析优先股投资的绝对收益、相对基准表现、安全目标达成度及隐性成本 |
| [goodwill-accounting-treatment](goodwill-accounting-treatment/SKILL.md) | 以事实为依据的商誉会计处理方法 | 企业收购需要记录商誉资产，按公允价值记录、保留账面不摊销、减值时减计 |
| [intrinsic-value-acquisition-evaluation](intrinsic-value-acquisition-evaluation/SKILL.md) | 评估企业并购交易是否创造价值 | 收购方管理层评估收购机会，判断收购交易是否创造价值 |
| [leveraged-buyout-analysis](leveraged-buyout-analysis/SKILL.md) | 分析杠杆收购的价值创造机制与风险 | 分析LBO或评估非LBO收购机会，识别四大价值驱动因素及其社会成本 |
| [creative-accounting-detection](creative-accounting-detection/SKILL.md) | 识别财务报表中的会计操纵手段 | 审查财务报表、评估企业真实盈利能力或进行尽职调查 |
| [berkshire-acquisition-policy](berkshire-acquisition-policy/SKILL.md) | 伯克希尔六项硬性收购筛选标准 | 评估潜在收购目标是否符合伯克希尔标准，执行快速响应流程 |
| [growth-value-relationship](growth-value-relationship/SKILL.md) | 将成长性纳入公司价值评估 | 分析成长型公司，判断成长性质量是否使投资者受益 |
| [shareholder-designated-contributions](shareholder-designated-contributions/SKILL.md) | 股东指定捐赠计划的完整流程 | 实施或评估股东指定捐赠计划，分析参与率和捐赠去向分布 |
| [berkshire-acquisition-agreement](berkshire-acquisition-agreement/SKILL.md) | 与伯克希尔签署收购协议的条款执行 | 企业卖家与伯克希尔达成收购交易，执行20/80权益分配等条款 |
| [mr-market-mental-model](mr-market-mental-model/SKILL.md) | 市场先生心理模型应对价格波动 | 面对股市每日价格波动、做出买卖决策或受市场情绪影响时 |
| [financial-sector-investment](financial-sector-investment/SKILL.md) | 银行股和困境债券投资策略 | 投资银行股、高收益债券或评估金融机构 |
| [zero-coupon-benign-application](zero-coupon-benign-application/SKILL.md) | 零息国债锁定长期复利 | 投资者需要锁定长期复利且消除再投资风险，适用于养老金、IRA |
| [owner-earnings-calculation](owner-earnings-calculation/SKILL.md) | 计算所有者盈利评估真实经济业绩 | 标准现金流分析可能夸大经济现实时，进行企业估值和投资项目分析 |
| [acquisition-valuation-preference](acquisition-valuation-preference/SKILL.md) | 比较部分收购与全资收购的性价比 | 面对收购机会，优先选择以每股X美元买入优秀企业10%股权 |
| [executive-compensation-design](executive-compensation-design/SKILL.md) | 基于扣除资本费用后的盈利能力设计薪酬 | 设计高管薪酬方案或审批期权计划，优先使用现金奖励而非股票期权 |
| [berkshire-acquisition-principles](berkshire-acquisition-principles/SKILL.md) | 寻找具有杰出经济特性的企业 | 进行收购决策或寻找投资标的，避免以便宜价格收购平庸公司 |
| [mr-market-principle](mr-market-principle/SKILL.md) | 利用市场先生极端情绪进行决策 | 市场报价极端偏离企业内在价值时，低价买入、高价忽略 |
| [financial-reporting-deep-analysis](financial-reporting-deep-analysis/SKILL.md) | 超越GAAP数字评估企业真实经济收益 | 评估企业内在价值、分析盈利质量或进行投资决策 |
| [intrinsic-value-calculation](intrinsic-value-calculation/SKILL.md) | 通过现金流折现计算内在价值 | 评估企业或投资的相对吸引力，理解账面价值的局限性 |
| [transaction-cost-impact-formula](transaction-cost-impact-formula/SKILL.md) | 计算交易成本对税前总回报的影响 | 评估长期投资回报或分析交易活跃度对收益的侵蚀 |
| [dilution-analysis-framework](dilution-analysis-framework/SKILL.md) | 计算内在价值稀释而非每股收益稀释 | 评估并购影响，将交易视角重构为"出售部分A以获得B" |
| [retained-earnings-incentive-evaluation](retained-earnings-incentive-evaluation/SKILL.md) | 评估留存收益回报率与薪酬激励 | 决定盈利分配或设计高管薪酬激励方案 |
| [airline-investment-risk-analysis](airline-investment-risk-analysis/SKILL.md) | 识别航空公司投资风险 | 评估航空运输业投资，分析无管制竞争环境下的生存能力 |
| [buffett-investment-criteria-and-philosophy](buffett-investment-criteria-and-philosophy/SKILL.md) | 巴菲特核心投资哲学框架 | 评估上市公司股票或企业收购机会，判断是否为优秀长期投资 |
| [zero-coupon-convertible-bond](zero-coupon-convertible-bond/SKILL.md) | 零息可转换债券的结构化设计 | 发行零息可转换债券，设定转换、赎回和回售条款 |
| [shareholder-attraction-retention](shareholder-attraction-retention/SKILL.md) | 应用餐馆理论保持一致性沟通 | 制定投资者关系策略或吸引特定类型股东 |
| [circle-of-competence-investing](circle-of-competence-investing/SKILL.md) | 判断投资机会是否在自身能力圈内 | 评估投资机会，识别持续竞争优势，预测5-20年收益增长 |
| [concentrated-investment-portfolio](concentrated-investment-portfolio/SKILL.md) | 构建集中投资组合决定资产配置 | 决定投资分散程度、选择核心持仓企业 |
| [buffett-dual-track-investment](buffett-dual-track-investment/SKILL.md) | 优先尝试100%协议收购，否则公开市场买入 | 发现具有出色经济特性并由杰出经理经营的公司 |
| [intrinsic-risk-assessment](intrinsic-risk-assessment/SKILL.md) | 评估投资机会的真实风险水平 | 判断投资安全性而非价格波动风险 |
| [holding-company-vs-marketable-securities](holding-company-vs-marketable-securities/SKILL.md) | 比较控股公司与可流通证券的优劣 | 伯克希尔式的大型资本配置决策 |
| [buyer-type-evaluation](buyer-type-evaluation/SKILL.md) | 评估潜在买家类型及其干预风险 | 企业所有者计划出售企业，进行并购谈判准备 |
| [zero-coupon-risk-identification](zero-coupon-risk-identification/SKILL.md) | 识别零息债券的财务欺诈风险 | 遇到零息债券或PIK债券投资机会，执行尽职调查 |
| [capital-allocation-governance](capital-allocation-governance/SKILL.md) | 评估企业资本配置效率和治理质量 | 分析企业管理层质量、评估资本配置决策 |
| [high-price-stock-gifting-strategy](high-price-stock-gifting-strategy/SKILL.md) | 高股价股票的税务优化馈赠策略 | 股价超过10,000美元且希望利用年度免税额度进行馈赠 |
| [restricted-earnings-dividend-policy](restricted-earnings-dividend-policy/SKILL.md) | 处理限定用途收益的分红政策 | 评估企业收益性质、制定分红政策，识别通货膨胀对收益的影响 |
| [saver-investor-price-preference](saver-investor-price-preference/SKILL.md) | 长期储蓄者面对股价下跌的心态转换 | 5年以上投资期限、定期买入股票的投资者 |
| [insurance-portfolio-allocation](insurance-portfolio-allocation/SKILL.md) | 保险公司在5大类资产中的选择配置 | 保险投资组合的资产配置决策 |
| [convertible-securities-analysis](convertible-securities-analysis/SKILL.md) | 评估可转换优先股等混合型证券价值 | 分析可转换证券、评估股票期权影响 |
| [margin-of-safety-principle](margin-of-safety-principle/SKILL.md) | 仅在价格显著低于内在价值时建立头寸 | 普通股买入和证券投资决策 |
| [investment-decision-framework](investment-decision-framework/SKILL.md) | 投资决策双重一致性验证原则 | 评估投资标的、制定收购策略或考虑非常规投资 |
| [intrinsic-valuation-methods](intrinsic-valuation-methods/SKILL.md) | 现金流折现模型与长期收益上限法则 | 计算企业内在价值、评估长期投资回报上限 |
| [financial-metrics-critical-analysis](financial-metrics-critical-analysis/SKILL.md) | 批判性财务分析框架 | 使用EBITDA评估企业业绩、识别会计操纵手段 |
| [graham-value-investing-principle](graham-value-investing-principle/SKILL.md) | 利用市场无效性建立头寸 | 市场价格低于内在价值25%且企业质量达标时 |
| [berkshire-decentralized-management](berkshire-decentralized-management/SKILL.md) | 分权管理、不干预哲学和资本集中配置 | 管理多元化企业集团、授权子公司CEO运营 |
| [mergers-acquisitions-accounting](mergers-acquisitions-accounting/SKILL.md) | 商誉处理方案与收购成本真实计算 | 进行企业并购会计处理、评估商誉的经济实质 |
| [value-investment-valuation](value-investment-valuation/SKILL.md) | 安全边际原则、伊索估值公式、经济商誉分析 | 证券投资决策、企业估值或价值投资分析 |
| [corporate-philanthropy-governance](corporate-philanthropy-governance/SKILL.md) | 捐赠分类决策框架与效率原则 | 设计企业慈善捐赠结构、管理股东指定捐赠计划 |
| [investment-execution-due-diligence](investment-execution-due-diligence/SKILL.md) | 投资执行、尽职调查与错误反思程序 | 执行具体投资操作、分析投资错误归因 |
| [corporate-governance-structures](corporate-governance-structures/SKILL.md) | 三种公司治理模式下的董事职责 | 组建董事会、评估CEO表现、设计治理机制 |
| [capital-allocation-equity-transactions](capital-allocation-equity-transactions/SKILL.md) | 股票回购与发行的算术逻辑与信号逻辑 | 考虑股票回购、发行股票进行并购 |
| [tax-efficient-investing](tax-efficient-investing/SKILL.md) | 递延纳税优势与公司税负转嫁规则 | 设计投资持有期策略、评估企业所有权结构 |
| [fixed-income-valuation](fixed-income-valuation/SKILL.md) | 零息债券定价与收益率计算机制 | 定价零息债券、计算贴现债券收益率 |
| [arbitrage-investment-strategy](arbitrage-investment-strategy/SKILL.md) | 套利四问框架与伯克希尔套利原则 | 考虑参与并购套利、风险套利或需要管理现金 |
| [shareholder-relations-communication](shareholder-relations-communication/SKILL.md) | 股东沟通与投资者筛选策略 | 设计股东年会形式、管理投资者关系 |
| [tax-regulatory-impacts](tax-regulatory-impacts/SKILL.md) | 监管影响分析框架 | 评估税务规则变更对企业价值和现金流的影响 |

## Quick Navigation

### 投资哲学与原则
- **[mr-market-mental-model]**: 市场先生心理模型应对价格波动
- **[mr-market-principle]**: 利用市场极端情绪进行逆向操作
- **[buffett-investment-criteria-and-philosophy]**: 巴菲特四项投资标准与能力圈原则
- **[graham-value-investing-principle]**: 格雷厄姆价值投资利用市场无效性
- **[margin-of-safety-principle]**: 安全边际原则避免大错误
- **[circle-of-competence-investing]**: 能力圈边界判断与竞争优势识别
- **[intrinsic-risk-assessment]**: 评估真实风险而非价格波动风险

### 企业估值方法
- **[intrinsic-value-calculation]**: 现金流折现计算内在价值
- **[intrinsic-valuation-methods]**: 长期收益上限法则与摩擦成本计算
- **[value-investment-valuation]**: 伊索估值公式与经济商誉分析
- **[owner-earnings-calculation]**: 所有者盈利评估真实经济业绩
- **[growth-value-relationship]**: 成长性质量判断与价值评估
- **[financial-reporting-deep-analysis]**: 超越GAAP评估真实经济收益

### 并购与收购
- **[berkshire-acquisition-policy]**: 六项硬性筛选标准快速响应
- **[berkshire-acquisition-principles]**: 避免癞蛤蟆陷阱的收购原则
- **[buffett-dual-track-investment]**: 协议收购与公开市场双轨策略
- **[intrinsic-value-acquisition-evaluation]**: 判断收购是否创造价值
- **[acquisition-valuation-preference]**: 部分收购vs全资收购性价比比较
- **[berkshire-acquisition-agreement]**: 20/80权益分配与现金支付条款
- **[buyer-type-evaluation]**: 评估买家类型及干预风险
- **[dilution-analysis-framework]**: 内在价值稀释而非EPS稀释计算
- **[leveraged-buyout-analysis]**: LBO四大价值驱动因素与风险识别

### 资本配置与分红
- **[capital-allocation-equity-transactions]**: 股票回购与发行的价值逻辑
- **[capital-allocation-governance]**: 评估资本配置效率与治理质量
- **[retained-earnings-incentive-evaluation]**: 留存收益回报率与薪酬激励
- **[restricted-earnings-dividend-policy]**: 限定用途收益的分红政策
- **[high-price-stock-gifting-strategy]**: 高股价税务优化馈赠策略

### 固定收益与特殊投资
- **[zero-coupon-benign-application]**: 零息国债锁定长期复利
- **[zero-coupon-convertible-bond]**: 零息可转债结构化设计
- **[zero-coupon-risk-identification]**: 识别零息债券财务欺诈风险
- **[fixed-income-valuation]**: 零息债券定价与收益率计算
- **[preferred-stock-performance-evaluation]**: 优先股投资组合多维度评估
- **[financial-sector-investment]**: 银行股与困境债券投资策略
- **[convertible-securities-analysis]**: 可转换证券估值与期权成本调整
- **[arbitrage-investment-strategy]**: 套利四问框架与时机选择

### 会计与财务分析
- **[goodwill-accounting-treatment]**: 事实为依据的商誉处理方法
- **[mergers-acquisitions-accounting]**: 商誉经济实质与收购成本计算
- **[creative-accounting-detection]**: 识别重组费用操纵等粉饰手段
- **[financial-metrics-critical-analysis]**: 批判性分析EBITDA等误导性指标
- **[transaction-cost-impact-formula]**: 交易成本对税前回报的影响计算

### 公司治理与管理
- **[berkshire-decentralized-management]**: 分权管理与不干预哲学
- **[corporate-governance-structures]**: 三种治理模式下的董事职责
- **[executive-compensation-design]**: 基于资本费用的薪酬设计
- **[shareholder-designated-contributions]**: 股东指定捐赠计划管理
- **[corporate-philanthropy-governance]**: 企业慈善捐赠效率原则

### 投资者关系与税务
- **[shareholder-attraction-retention]**: 餐馆理论保持一致性沟通
- **[shareholder-relations-communication]**: 股东年会与投资者筛选策略
- **[saver-investor-price-preference]**: 长期储蓄者利用低价增加收益
- **[tax-efficient-investing]**: 递延纳税与税负转嫁策略
- **[tax-regulatory-impacts]**: 税务规则变更影响分析
- **[holding-company-vs-marketable-securities]**: 控股公司与可流通证券比较
- **[insurance-portfolio-allocation]**: 保险资金五类资产配置决策

### 投资执行与反思
- **[investment-decision-framework]**: 双重一致性验证与非常规投资
- **[investment-execution-due-diligence]**: 执行操作、尽职调查与错误反思
- **[airline-investment-risk-analysis]**: 航空公司无管制竞争风险识别

## How to Use

1. **识别任务类型**：首先确定您面临的是投资决策、企业估值、并购分析、公司治理还是其他场景

2. **匹配技能类别**：参考"Quick Navigation"中的分类，找到最相关的技能组

3. **查看详细描述**：在"Available Skills"表格中阅读技能的完整描述和触发场景

4. **调用技能**：通过技能名称（如`buffett-investment-criteria-and-philosophy`）调用相应技能文件获取详细指导

5. **组合使用**：复杂问题可能需要多个技能配合，例如收购决策可同时使用`berkshire-acquisition-policy`、`intrinsic-value-acquisition-evaluation`和`dilution-analysis-framework`
```