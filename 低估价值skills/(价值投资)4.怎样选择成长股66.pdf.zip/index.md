```markdown
# 费雪成长股投资技能集

本技能集源自菲利普·费雪的经典著作《怎样选择成长股》，为投资者提供了一套完整的成长股投资方法论。这些技能涵盖了从投资哲学建立、公司深度调研、估值分析、买入时机选择到投资组合管理的全流程指导，帮助用户识别并长期持有具有卓越成长潜力的优质企业。

## 可用技能

| 技能 | 描述 | 适用场景 |
|------|------|----------|
| [fisher-growth-investment-philosophy](fisher-growth-investment-philosophy/SKILL.md) | 建立成长股投资核心理念，筛选投资标的并评估公司长期政策稳定性 | 建立投资框架、初步筛选和长期持有决策 |
| [growth-stock-investment-philosophy](growth-stock-investment-philosophy/SKILL.md) | 应用费雪八项原则和长期哲学发展方法 | 制定个人投资哲学、进行普通股投资决策 |
| [growth-stock-investment-framework](growth-stock-investment-framework/SKILL.md) | 通过六大维度筛选投资标的的评估框架 | 寻找长期成长潜力的投资标的 |
| [conservative-investment-criteria](conservative-investment-criteria/SKILL.md) | 评估低成本运营优势与管理层深度及人才培养体系 | 筛选长期稳健型投资标的 |
| [investment-research-process](investment-research-process/SKILL.md) | 寻找和调研高成长投资机会，执行行业深度调研 | 发现新的潜在投资标的、评估特定行业机会 |
| [investment-scuttlebutt-channel-check](investment-scuttlebutt-channel-check/SKILL.md) | 通过行业渠道调查验证投资标的基本面 | 分析潜在投资标的且仅依赖财务报告时 |
| [scuttlebutt-company-evaluation-checklist](scuttlebutt-company-evaluation-checklist/SKILL.md) | 深度基本面分析，评估市场成长潜力、劳资关系、管理层诚信度 | 尽职调查和最终投资决策 |
| [scuttlebutt-research-method](scuttlebutt-research-method/SKILL.md) | 执行"闲聊"调研法进行深度背景调查 | 需要了解管理层能力与行业竞争格局时 |
| [investment-research-scuttlebutt-method](investment-research-scuttlebutt-method/SKILL.md) | 从初步财务筛选到管理层拜访的完整流程 | 对潜在投资标的进行深度基本面调查 |
| [investment-research-framework](investment-research-framework/SKILL.md) | 运用"闲聊法"收集一手定性情报，结合三层结构评价 | 基本面投资者进行深度尽职调查 |
| [management-interview-preparation-and-access](management-interview-preparation-and-access/SKILL.md) | 完成管理层访谈前知识准备、获取访问权限并验证管理层能力 | 已通过闲聊获取充足背景资料后 |
| [annual-report-critical-analysis](annual-report-critical-analysis/SKILL.md) | 阅读和分析致股东年报，识别信息披露不足的风险信号 | 财务分析前的初步筛选和排除决策 |
| [management-quality-evaluation](management-quality-evaluation/SKILL.md) | 评估公司领导力、团队建设、员工关系等"人的因素" | 判断公司领导力和组织有效性时 |
| [management-quality-assessment](management-quality-assessment/SKILL.md) | 深度评估管理阶层质量、组织文化和授权机制 | 评估成长型公司、中小型成长企业长期潜力 |
| [management-quality-assessment-2](management-quality-assessment-2/SKILL.md) | 从沟通透明度、资本配置效率和长期经营策略评估管理层 | 识别高风险管理层与卓越管理层 |
| [competitive-advantage-profitability](competitive-advantage-profitability/SKILL.md) | 分析企业盈利能力、竞争保护机制和技术壁垒优势 | 评估长期维持高利润率的企业 |
| [sales-marketing-evaluation](sales-marketing-evaluation/SKILL.md) | 评估企业销售组织质量和营销能力 | 评估制造企业、科技行业公司的长期投资价值 |
| [marketing-organization-evaluation](marketing-organization-evaluation/SKILL.md) | 评估企业行销组织的需求监测、利益传达和渠道控制能力 | 分析制造、零售及服务企业的市场开拓能力 |
| [rd-investment-management-evaluation](rd-investment-management-evaluation/SKILL.md) | 重点分析管理阶层质量与研发支出趋势 | 评估研发驱动型成长公司长期投资价值 |
| [rd-commitment-evaluation](rd-commitment-evaluation/SKILL.md) | 评估公司持续研发承诺对长期利润的影响 | 成长型公司投资评估和长期财务成功潜力分析 |
| [rd-effectiveness-evaluation](rd-effectiveness-evaluation/SKILL.md) | 评估企业研发活动的效率与商业化潜力 | 分析科技类上市公司及制造企业的研发投入产出比 |
| [tech-transition-management-assessment](tech-transition-management-assessment/SKILL.md) | 评估管理层利用内部资源创造新营业额曲线能力 | 技术驱动型行业面临重大技术变革时 |
| [employee-management-and-participatory-systems](employee-management-and-participatory-systems/SKILL.md) | 实施参与式管理和员工关怀体系，提升人员效能 | 希望建立员工参与决策机制的制造企业 |
| [growth-stock-valuation](growth-stock-valuation/SKILL.md) | 分析本益比三大要素、识别成长股本益比比较陷阱 | 判断股票是否被低估、比较不同成长股相对价值 |
| [high-pe-growth-valuation](high-pe-growth-valuation/SKILL.md) | 评估高本益比成长股是否已反映未来盈余成长 | 本益比显著高于市场平均的成长股分析 |
| [historical-data-auxiliary-analysis](historical-data-auxiliary-analysis/SKILL.md) | 将历史数据作为辅助工具判断周期性和建立本益比基准 | 具备5-15年长期历史数据的股票分析 |
| [historical-data-bias-avoidance](historical-data-bias-avoidance/SKILL.md) | 避免过度依赖历史数据做出错误投资决策 | 基于过去5-10年的价格或盈余数据做决策时 |
| [conservative-investment-financial-standards](conservative-investment-financial-standards/SKILL.md) | 评估公司是否符合保守型投资的财务要素 | 财务健康评估和长期持有决策 |
| [profitability-sustainability-analysis](profitability-sustainability-analysis/SKILL.md) | 分析企业利润率水平、类型特征及未来维持机制 | 评估上市公司在不同经济周期中的盈利质量 |
| [equity-dilution-assessment](equity-dilution-assessment/SKILL.md) | 分析股票增发、可转换证券对现有股东权益的稀释影响 | 评估上市公司融资决策质量 |
| [growth-stock-timing-strategy](growth-stock-timing-strategy/SKILL.md) | 提供择时决策框架，拒绝经济预测、识别理想买点 | 面临买入时机选择、资本配置决策时 |
| [date-based-buying-strategy](date-based-buying-strategy/SKILL.md) | 采用业务里程碑日期而非价格目标作为买进依据 | 股价已显著高于基于已知因素的合理估值时 |
| [production-ramp-buying](production-ramp-buying/SKILL.md) | 识别新产品从试车转向量产遇到困难时的买入机会 | 成长型公司量产初期震荡期 |
| [special-situations-buying](special-situations-buying/SKILL.md) | 利用市场对短期问题的过度反应寻找买入机会 | 管理卓越的公司遭遇暂时性经营挫折时 |
| [contrarian-opportunity-after-rd-failure](contrarian-opportunity-after-rd-failure/SKILL.md) | 识别研发失败与组织重组后的投资机会 | 成长型公司发生重大研发项目失败时 |
| [management-transformation-buying](management-transformation-buying/SKILL.md) | 识别管理层重组但金融圈尚未认识到潜在价值的买入机会 | 大型企业进行管理层重组、现代化改造时 |
| [contrarian-investment-strategy](contrarian-investment-strategy/SKILL.md) | 执行逆向投资策略，捕捉市场主流看法与基本面的偏离 | 发现金融圈过分悲观的行业/公司时 |
| [asset-allocation-portfolio-construction](asset-allocation-portfolio-construction/SKILL.md) | 在保守型机构股票和积极型成长股之间进行资产配置 | 个人投资者、家庭资产配置者构建投资组合 |
| [asset-allocation-by-investor-status](asset-allocation-by-investor-status/SKILL.md) | 根据投资者现有持仓状况制定资金配置和择时策略 | 决定一次性买入还是分批建仓时 |
| [portfolio-allocation-rules](portfolio-allocation-rules/SKILL.md) | 根据A/B/C股票分类确定投资组合配置比例 | 资金充裕的投资人构建普通股投资组合 |
| [growth-stock-classification-diversification](growth-stock-classification-diversification/SKILL.md) | 对成长股进行A/B/C三级分类并评估外部分散投资需求 | 构建投资组合需要确定分散投资策略时 |
| [conservative-investment-risk-assessment](conservative-investment-risk-assessment/SKILL.md) | 基于五级风险量尺评估投资风险层级 | 保守型投资者、新资金首次购买决策 |
| [investment-domain-specialization](investment-domain-specialization/SKILL.md) | 确定投资范围和能力圈边界，避免在不熟悉的领域投资 | 应用于投资领域选择和行业配置时 |
| [stock-trading-execution-management](stock-trading-execution-management/SKILL.md) | 执行股票买入策略、修正投资错误、换股升级 | 股票投资者决定买入、卖出或调整持仓时 |
| [limit-order-psychology-trap](limit-order-psychology-trap/SKILL.md) | 克服限价单交易中的"锱铢必较"心理 | 确信股票具有长期大幅上涨潜力时 |
| [analysis-to-execution-discipline](analysis-to-execution-discipline/SKILL.md) | 将正确的市场预测或投资分析转化为实际交易执行 | 已完成分析但尚未执行具体交易时 |
| [otc-market-liquidity-analysis](otc-market-liquidity-analysis/SKILL.md) | 评估未上市股票流动性，比较店头市场与交易所差异 | 需要评估股票流动性、选择交易场所时 |
| [market-manipulation-awareness](market-manipulation-awareness/SKILL.md) | 识别股市操纵模式和异常交易行为 | 观察到异常交易活跃度、股价异常波动时 |
| [market-inefficiency-evidence-analysis](market-inefficiency-evidence-analysis/SKILL.md) | 通过股价表现差异分析验证市场非完全有效性 | 反驳高效率市场理论、评估长期投资机会时 |
| [cyclical-industry-value-trap-detection](cyclical-industry-value-trap-detection/SKILL.md) | 识别周期性行业在景气高峰时的价值陷阱风险 | 市场高估时期发现低本益比股票时 |
| [valuation-fundamentals-divergence](valuation-fundamentals-divergence/SKILL.md) | 识别行业评价与基本面的背离 | 逆向投资、本益比变动分析和行业周期判断 |
| [special-situation-evaluation](special-situation-evaluation/SKILL.md) | 评估特殊投资情境，包括店头股票和股利政策 | 考虑购买店头市场股票、评估股利政策时 |
| [defense-contract-rd-valuation](defense-contract-rd-valuation/SKILL.md) | 评估国防承包商研发投资价值 | 分析涉及国防研发业务的上市公司时 |
| [growth-stock-lifecycle-management](growth-stock-lifecycle-management/SKILL.md) | 识别杰出成长型公司并长期持有，判断何时卖出 | 寻找长期投资机会、监控已持有股票基本面 |
| [startup-low-cost-foundation](startup-low-cost-foundation/SKILL.md) | 通过极致成本控制和长期视角建立业务基础 | 创业初期资源有限时 |
| [crisis-opportunity-strategy](crisis-opportunity-strategy/SKILL.md) | 在经济危机或市场萧条期评估创业时机或谈判雇佣保护条款 | 金融从业者、创业者在职业转折点时 |
| [rd-related-diversification-strategy](rd-related-diversification-strategy/SKILL.md) | 评估研发资源配置是否符合"树干树枝"原则 | 公司研发方向审查、多元化战略评估时 |
| [marketing-habit-barrier-evaluation](marketing-habit-barrier-evaluation/SKILL.md) | 评估企业是否通过营销优势建立习惯性再订购壁垒 | 评估中高科技供应领域企业的竞争优势时 |
| [growth-reinvestment-assessment](growth-reinvestment-assessment/SKILL.md) | 评估管理层利润再投资策略，区分长期成长导向与短期利润最大化 | 筛选保守型成长投资标的 |
| [long-term-investment-strategy](long-term-investment-strategy/SKILL.md) | 采用长期持有杰出公司的策略 | 普通股投资者、长期财富积累者制定策略时 |
| [long-term-holding-strategy](long-term-holding-strategy/SKILL.md) | 比较短线交易与长期投资、应用三年守则 | 决定投资持有期限、评估是否应卖出股票时 |
| [long-term-stock-holding-principles](long-term-stock-holding-principles/SKILL.md) | 对具备持续竞争优势的公司执行"买入并持有"策略 | 已验证的优质普通股投资 |
| [raychem-rd-investment-criteria](raychem-rd-investment-criteria/SKILL.md) | 评估高科技制造企业、研发驱动型企业的战略质量 | 分析具备技术研发能力和专利保护潜力的公司 |
| [document-chapter-boundary-identification](document-chapter-boundary-identification/SKILL.md) | 识别章节标题标记、确定内容边界或建立章节导航索引 | 处理采用章节式组织结构的文档时 |
| [common-stocks-uncommon-profits-1999-metadata](common-stocks-uncommon-profits-1999-metadata/SKILL.md) | 提供特定版本的完整元数据记录 | 验证或引用特定版本书籍信息时 |
| [historical-investment-conflicts-analysis](historical-investment-conflicts-analysis/SKILL.md) | 分析1920年代银行投资部门的利益冲突机制 | 学习金融史、理解利益冲突时 |

## 快速导航

### 投资哲学与框架
- **fisher-growth-investment-philosophy**: 建立成长股投资核心理念，筛选投资标的
- **growth-stock-investment-philosophy**: 应用费雪八项原则和长期哲学发展方法
- **growth-stock-investment-framework**: 通过六大维度筛选投资标的的评估框架
- **conservative-investment-criteria**: 评估低成本运营优势与管理层深度及人才培养体系

### 研究与调研方法
- **investment-research-process**: 寻找和调研高成长投资机会，执行行业深度调研
- **investment-scuttlebutt-channel-check**: 通过行业渠道调查验证投资标的基本面
- **scuttlebutt-company-evaluation-checklist**: 深度基本面分析，评估市场成长潜力、劳资关系、管理层诚信度
- **scuttlebutt-research-method**: 执行"闲聊"调研法进行深度背景调查
- **investment-research-scuttlebutt-method**: 从初步财务筛选到管理层拜访的完整流程
- **investment-research-framework**: 运用"闲聊法"收集一手定性情报，结合三层结构评价
- **management-interview-preparation-and-access**: 完成管理层访谈前知识准备、获取访问权限并验证管理层能力
- **annual-report-critical-analysis**: 阅读和分析致股东年报，识别信息披露不足的风险信号

### 公司评估与管理层分析
- **management-quality-evaluation**: 评估公司领导力、团队建设、员工关系等"人的因素"
- **management-quality-assessment**: 深度评估管理阶层质量、组织文化和授权机制
- **management-quality-assessment-2**: 从沟通透明度、资本配置效率和长期经营策略评估管理层
- **competitive-advantage-profitability**: 分析企业盈利能力、竞争保护机制和技术壁垒优势
- **sales-marketing-evaluation**: 评估企业销售组织质量和营销能力
- **marketing-organization-evaluation**: 评估企业行销组织的需求监测、利益传达和渠道控制能力
- **rd-investment-management-evaluation**: 重点分析管理阶层质量与研发支出趋势
- **rd-commitment-evaluation**: 评估公司持续研发承诺对长期利润的影响
- **rd-effectiveness-evaluation**: 评估企业研发活动的效率与商业化潜力
- **tech-transition-management-assessment**: 评估管理层利用内部资源创造新营业额曲线能力
- **employee-management-and-participatory-systems**: 实施参与式管理和员工关怀体系，提升人员效能

### 估值与财务分析
- **growth-stock-valuation**: 分析本益比三大要素、识别成长股本益比比较陷阱
- **high-pe-growth-valuation**: 评估高本益比成长股是否已反映未来盈余成长
- **historical-data-auxiliary-analysis**: 将历史数据作为辅助工具判断周期性和建立本益比基准
- **historical-data-bias-avoidance**: 避免过度依赖历史数据做出错误投资决策
- **conservative-investment-financial-standards**: 评估公司是否符合保守型投资的财务要素
- **profitability-sustainability-analysis**: 分析企业利润率水平、类型特征及未来维持机制
- **equity-dilution-assessment**: 分析股票增发、可转换证券对现有股东权益的稀释影响

### 买入时机与策略
- **growth-stock-timing-strategy**: 提供择时决策框架，拒绝经济预测、识别理想买点
- **date-based-buying-strategy**: 采用业务里程碑日期而非价格目标作为买进依据
- **production-ramp-buying**: 识别新产品从试车转向量产遇到困难时的买入机会
- **special-situations-buying**: 利用市场对短期问题的过度反应寻找买入机会
- **contrarian-opportunity-after-rd-failure**: 识别研发失败与组织重组后的投资机会
- **management-transformation-buying**: 识别管理层重组但金融圈尚未认识到潜在价值的买入机会
- **contrarian-investment-strategy**: 执行逆向投资策略，捕捉市场主流看法与基本面的偏离

### 投资组合与风险管理
- **asset-allocation-portfolio-construction**: 在保守型机构股票和积极型成长股之间进行资产配置
- **asset-allocation-by-investor-status**: 根据投资者现有持仓状况制定资金配置和择时策略
- **portfolio-allocation-rules**: 根据A/B/C股票分类确定投资组合配置比例
- **growth-stock-classification-diversification**: 对成长股进行A/B/C三级分类并评估外部分散投资需求
- **conservative-investment-risk-assessment**: 基于五级风险量尺评估投资风险层级
- **investment-domain-specialization**: 确定投资范围和能力圈边界，避免在不熟悉的领域投资

### 交易执行
- **stock-trading-execution-management**: 执行股票买入策略、修正投资错误、换股升级
- **limit-order-psychology-trap**: 克服限价单交易中的"锱铢必较"心理
- **analysis-to-execution-discipline**: 将正确的市场预测或投资分析转化为实际交易执行
- **otc-market-liquidity-analysis**: 评估未上市股票流动性，比较店头市场与交易所差异

### 市场分析与特殊情境
- **market-manipulation-awareness**: 识别股市操纵模式和异常交易行为
- **market-inefficiency-evidence-analysis**: 通过股价表现差异分析验证市场非完全有效性
- **cyclical-industry-value-trap-detection**: 识别周期性行业在景气高峰时的价值陷阱风险
- **valuation-fundamentals-divergence**: 识别行业评价与基本面的背离
- **special-situation-evaluation**: 评估特殊投资情境，包括店头股票和股利政策
- **defense-contract-rd-valuation**: 评估国防承包商研发投资价值
- **growth-stock-lifecycle-management**: 识别杰出成长型公司并长期持有，判断何时卖出

### 创业与企业管理
- **startup-low-cost-foundation**: 通过极致成本控制和长期视角建立业务基础
- **crisis-opportunity-strategy**: 在经济危机或市场萧条期评估创业时机或谈判雇佣保护条款
- **rd-related-diversification-strategy**: 评估研发资源配置是否符合"树干树枝"原则
- **marketing-habit-barrier-evaluation**: 评估企业是否通过营销优势建立习惯性再订购壁垒
- **growth-reinvestment-assessment**: 评估管理层利润再投资策略，区分长期成长导向与短期利润最大化

### 长期持有策略
- **long-term-investment-strategy**: 采用长期持有杰出公司的策略
- **long-term-holding-strategy**: 比较短线交易与长期投资、应用三年守则
- **long-term-stock-holding-principles**: 对具备持续竞争优势的公司执行"买入并持有"策略

### 文档与元数据
- **document-chapter-boundary-identification**: 识别章节标题标记、确定内容边界或建立章节导航索引
- **common-stocks-uncommon-profits-1999-metadata**: 提供特定版本的完整元数据记录
- **historical-investment-conflicts-analysis**: 分析1920年代银行投资部门的利益冲突机制

## 如何使用

1. **确定任务类型**：根据您当前的投资决策阶段，选择对应的技能类别
   - 建立投资框架 → 投资哲学与框架
   - 寻找投资标的 → 研究与调研方法
   - 评估公司质量 → 公司评估与管理层分析
   - 判断买入时机 → 买入时机与策略
   - 管理投资组合 → 投资组合与风险管理

2. **调用技能**：在对话中明确提及您需要使用的技能名称，或描述您的具体需求，系统将自动推荐最合适的技能

3. **遵循流程**：按照技能中的步骤执行，特别是"闲聊"调研法强调在拜访管理层前必须完成50%的知识准备

4. **组合使用**：许多技能可以组合使用，例如先用 `investment-research-process` 发现标的，再用 `scuttlebutt-company-evaluation-checklist` 深度评估，最后用 `growth-stock-timing-strategy` 确定买入时机

5. **长期跟踪**：买入后使用 `growth-stock-lifecycle-management` 持续监控基本面变化
```