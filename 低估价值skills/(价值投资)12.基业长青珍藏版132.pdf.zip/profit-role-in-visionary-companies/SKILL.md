---
name: Profit Role in Visionary Companies
description: Reinterprets the role of profit in visionary companies by positioning it as a necessary means for survival and purpose realization—not as the ultimate goal. Use this skill when analyzing or advising organizations that claim to be driven by core ideals beyond shareholder wealth, especially when contrasting them with profit-maximizing firms.
---

# Profit Role in Visionary Companies

## When to Use
Use this skill when:
- Evaluating whether a company aligns with the "visionary company" archetype described in long-term organizational studies.
- Advising leadership teams on balancing idealistic missions with financial sustainability.
- Contrasting strategic drivers between visionary companies and conventional profit-focused firms.
- Clarifying misconceptions that equate business success solely with profit maximization.

## How to Execute

1. **Confirm the company qualifies as a visionary company**: Verify it has established a core ideology that transcends economic interests (prerequisite condition).

2. **Reframe profit’s role** using the following principles:
   - Treat profit as a *necessary condition for survival*, not the primary objective.
   - View profit as a *means to achieve broader, meaningful purposes* rooted in the company’s core ideology.
   - Reject the notion that maximizing shareholder wealth is the dominant driver.

3. **Apply the "both-and" integration approach**:
   - Simultaneously pursue the realization of core ideals *and* financial viability.
   - Avoid false trade-offs between purpose and profitability; instead, seek strategies where both reinforce each other.

4. **Use the biological analogy for communication**:
   - Explain that profit is like oxygen, food, water, or blood—essential for life but not the purpose of life.

5. **Validate against empirical patterns**:
   - Reference that among 18 matched company pairs in foundational research, 17 visionary companies exhibited this ideology-driven pattern as a key differentiator.

6. **Clarify common misunderstandings**:
   - Emphasize that visionary companies *do care* about long-term shareholder value—but it does not dominate all decisions.
   - Stress that rejecting profit-as-sole-purpose ≠ rejecting profit altogether.

> **Note**: Do not apply this framework to companies whose sole declared purpose is shareholder wealth maximization; it is explicitly constrained to visionary organizations with transcendent core ideologies.