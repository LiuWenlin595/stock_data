```markdown
# 高瞻远瞩公司构建技能库

本技能集合源自经典管理著作《基业长青》（Built to Last），聚焦于如何打造能够跨越时代、持续卓越的“高瞻远瞩公司”。通过这套技能，用户可系统性地定义核心理念、设定胆大包天目标（BHAG）、构建教派式文化、设计接班人机制、平衡核心坚守与持续进步，并避免常见误区（如依赖魅力型领袖或伟大构想）。无论您是创始人、高管、部门负责人，还是组织发展顾问，均可借助这些技能推动组织向长期主义、价值观驱动和自我进化方向演进。

## Available Skills

| Skill | Description | Use When |
|-------|-------------|----------|
| [big-hairy-audacious-goals-for-visionary-companies](big-hairy-audacious-goals-for-visionary-companies/SKILL.md) | 定义、验证并实施符合核心理念的胆大包天目标（BHAG），以激发组织活力并实现历史性突破。 | 企业被外界视为保守，或计划设定一个在外人看来近乎荒谬、大胆甚至非理性的长期目标时。 |
| [cult-like-culture-building-for-core-ideology](cult-like-culture-building-for-core-ideology/SKILL.md) | 设计并实施“灌输信仰、严密契合、精英主义”三位一体的文化机制，建立对核心理念有宗教般虔信的组织环境。 | 企业希望建立高度忠诚、行为一致且价值观驱动的强文化，适用于高瞻远瞩公司或初创/转型期组织。 |
| [balancing-core-preservation-with-progress-stimulation](balancing-core-preservation-with-progress-stimulation/SKILL.md) | 同步强化核心理念坚守与进步机制（如BHAG、进化式实验），避免文化失衡导致的集体思维或创造力枯竭。 | 组织已有强文化但面临创新僵化风险，或试图推动重大变革时。 |
| [evolutionary-progress-through-purposeful-experimentation](evolutionary-progress-through-purposeful-experimentation/SKILL.md) | 启动小步实验、快速验证并制度化成功变异，形成非规划性但高度适应的战略演进路径。 | 企业面临高度不确定性、异常顾客行为或意外机会，且无法预知未来具体形态时。 |
| [leadership-succession-and-core-ideology-preservation](leadership-succession-and-core-ideology-preservation/SKILL.md) | 评估继任风险、设计内部培养机制，确保新领导者与公司核心理念高度一致。 | 创始人或CEO即将离任、缺乏合格继任者，或必须从外部聘请高管时。 |
| [institutionalizing-never-satisfied-mechanisms](institutionalizing-never-satisfied-mechanisms/SKILL.md) | 设计并实施具有约束力、制度化的持续改善机制，确保组织在外部世界尚未要求前即主动变革。 | 公司已取得显著成功或成为行业领导者，面临自满风险时。 |
| [holistic-building-of-visionary-companies](holistic-building-of-visionary-companies/SKILL.md) | 强调数百种行动、机制、象征在长期内协调一致的整体素质，而非依赖孤立要素。 | 企业试图通过单一管理实践（如仅制定愿景）打造高瞻远瞩公司时。 |
| [构建高瞻远瞩公司的核心理念体系](构建高瞻远瞩公司的核心理念体系/SKILL.md) | 识别、验证并确立组织的核心价值观与根本目的，并通过具体行为和制度设计传递理念。 | 企业希望建立或强化长期身份认同、解决文化空心化问题，或在变革中锚定方向时。 |
| [保存核心与刺激进步的双轨机制设计](保存核心与刺激进步的双轨机制设计/SKILL.md) | 在坚守核心理念的同时系统性推动创新与变革，消除不协调要素并激发进步动力。 | 企业面临外部快速变化、内部僵化或历史辉煌但当前衰退时。 |
| [高瞻远瞩公司的人才与组织能力建设](高瞻远瞩公司的人才与组织能力建设/SKILL.md) | 设计并实施系统性人才培养与组织能力提升机制。 | 企业需构建可持续竞争优势、提升基层执行力，或在非CEO岗位推动局部高瞻远瞩实践时。 |
| [高瞻远瞩公司的战略决策与自我一致性原则](高瞻远瞩公司的战略决策与自我一致性原则/SKILL.md) | 以“是否契合自身理念”而非“外部评价”为决策依据，评估新业务方向或外部建议。 | 企业面临战略选择、行业惯例压力或需判断某做法是否应采纳时。 |
| [高瞻远瞩公司研究的评估与比较框架](高瞻远瞩公司研究的评估与比较框架/SKILL.md) | 系统化评估企业在理念表述、BHAG、教派文化、继任规划等维度的表现，并计算量化指数。 | 进行组织诊断、学术研究或对标分析时。 |
| [bhag-core-alignment-check](bhag-core-alignment-check/SKILL.md) | 检验胆大包天目标（BHAG）是否植根于公司已定义的自我定位并强化其不变的核心理念。 | 企业战略规划团队考虑采纳某一BHAG，且已有清晰身份认知时。 |
| [设定胆大包天目标的策略与历史验证](设定胆大包天目标的策略与历史验证/SKILL.md) | 帮助处于追赶地位的企业设计并验证BHAG的可行性与激励机制。 | 组织面临行业巨头、具备潜在突破口且领导层有冒险精神时。 |
| [bhag-completion-risk-management](bhag-completion-risk-management/SKILL.md) | 识别“我们完成了”病症风险，并制定继任BHAG以维持组织前进动力。 | 组织已成功实现一个BHAG并处于稳定或巅峰状态时。 |
| [paired-company-analysis-of-bold-goals](paired-company-analysis-of-bold-goals/SKILL.md) | 通过高瞻远瞩公司与其对照公司的配对比较，评估BHAG作为组织进步机制的实际效果。 | 需要验证该战略机制在历史案例中的有效性或比较不同公司目标设定差异时。 |
| [define-bhag-goals](define-bhag-goals/SKILL.md) | 指导用户评估目标是否具备明确性、动人性、易懂性和集中性四大核心特征，并确保其符合组织核心理念。 | 组织需要激发进步动力、缺乏强大驱动力，且已具备基本目标体系与核心理念基础时。 |
| [she-ji-dan-da-bao-tian-mu-biao](she-ji-dan-da-bao-tian-mu-biao/SKILL.md) | 帮助组织设计符合BHAG标准的长期战略目标，激发全员动力并与核心价值观一致。 | 组织已确立核心理念并希望制定能激发持久激励力的远大目标时。 |
| [zao-zhong-yu-bao-shi-ce-lue-qu-fen](zao-zhong-yu-bao-shi-ce-lue-qu-fen/SKILL.md) | 区分“造钟”与“报时”两类根本性组织战略，判断应采用哪种策略。 | 企业希望实现跨越多代领导者的持续成功、需选择战略实施路径或评估当前战略可持续性时。 |
| [establish-bhag-for-organizational-momentum](establish-bhag-for-organizational-momentum/SKILL.md) | 定义并制度化BHAG以维持高瞻远瞩公司在核心领袖离任后的持续动力。 | 企业面临创始人或英明领袖即将离任、组织活力可能出现衰退风险时。 |
| [institutionalize-bold-goals-as-progress-engine](institutionalize-bold-goals-as-progress-engine/SKILL.md) | 将胆大包天目标嵌入组织制度、流程与文化中，使其超越个人领导力，成为自动激励机制。 | 组织面临核心领袖离职、去世或影响力减弱，但需确认目标能否独立驱动持续进步时。 |
| [评估胆大包天目标的核心特征](评估胆大包天目标的核心特征/SKILL.md) | 判断一个目标是否符合BHAG定义，核心依据是是否要求高度献身精神与实质性风险承担。 | 需要评估企业战略目标的雄心程度、验证其驱动长期跃进的潜力，或对比不同组织愿景激进性时。 |
| [设定胆大包天目标](设定胆大包天目标/SKILL.md) | 制定并公开一个看似几乎不可能实现但方向明确的长期目标（BHAG），以激发全组织投入高风险高回报行动。 | 企业处于行业变革临界点、具备技术积累和资源承诺能力时。 |
| [core-ideology-and-progress-dynamic-mechanism](core-ideology-and-progress-dynamic-mechanism/SKILL.md) | 在稳定性与变革性之间实现动态协同，将抽象理念转化为具体机制。 | 高瞻远瞩公司、战略规划团队或组织制度设计者在已明确界定核心理念并具备制度化能力前提下使用。 |
| [visionary-company-internal-drive-mechanism](visionary-company-internal-drive-mechanism/SKILL.md) | 识别、激活并制度化高瞻远瞩公司特有的内生性进步驱动力。 | 组织已确立清晰核心理念，并展现出对持续改进、创新与卓越的内在渴望时。 |
| [保存核心与刺激进步的五类实践方法](保存核心与刺激进步的五类实践方法/SKILL.md) | 提供一套通过五类协同实践方法实现“保存核心”与“刺激进步”双重目标的操作指南。 | 组织需要在坚守核心价值观的同时推动持续创新与成长时。 |
| [visionary-company-dual-layer-framework](visionary-company-dual-layer-framework/SKILL.md) | 诊断或设计高瞻远瞩公司的组织基础架构，检查无形指导方针与有形机制的完整性。 | 组织希望评估自身是否具备成为高瞻远瞩公司的条件，或正在构建可持续发展的组织系统时。 |
| [识别追求进步的驱动力](识别追求进步的驱动力/SKILL.md) | 判断高瞻远瞩公司、创始人或领导者是否具备“追求进步的驱动力”这一核心特质。 | 需要评估一个组织是否具有持续探索、创造和改善的内在原动力，而非仅出于理性计算或短期利益时。 |
| [保存核心与刺激进步的辩证原则](保存核心与刺激进步的辩证原则/SKILL.md) | 正确区分并坚守不变的核心理念，同时持续革新所有非核心做法。 | 组织需要推动变革但不确定哪些要素应保留、哪些应调整时。 |
| [non-ceo-level-core-philosophy-development](non-ceo-level-core-philosophy-development/SKILL.md) | 指导非CEO层级管理者为所属团队或部门制定核心理念。 | 组织层级非CEO级别且需要为本部门/团队确立方向时，尤其适用于公司已有整体理念但允许下级发展补充理念场景。 |
| [define-enduring-organizational-purpose](define-enduring-organizational-purpose/SKILL.md) | 定义一个真实、根本且能持续百年的组织存在目的。 | 组织试图回答“我们为什么会在一起？”并确立长期存在的根本理由时。 |
| [zheng-hei-he-xin-jia-zhi-shi-bie-yu-zhi-ding](zheng-hei-he-xin-jia-zhi-shi-bie-yu-zhi-ding/SKILL.md) | 帮助组织领导者甄别并制定真实、不可妥协的核心价值观。 | 企业正在起草、修订或审查其核心价值宣言，且已有初步价值观列表时。 |
| [define-core-ideology](define-core-ideology/SKILL.md) | 帮助组织界定其完整的核心理念，由不可妥协的核心价值与超越利润的根本目的共同构成。 | 组织试图建立或修订长期指导原则时，确保不将短期策略误认为核心理念。 |
| [core-ideology-implementation-in-visionary-companies](core-ideology-implementation-in-visionary-companies/SKILL.md) | 指导长期导向型组织将已确立的核心理念制度化并贯穿于人才管理、战略执行与危机应对全过程。 | 适用于已被归类为高瞻远瞩公司、拥有明确核心理念且具备管理层继任机制的企业。 |
| [core-ideology-behavior-alignment-mechanism](core-ideology-behavior-alignment-mechanism/SKILL.md) | 解释和评估组织在公开声明核心理念后，其后续行为如何因“公开承诺一致性原则”而趋向一致。 | 需要判断某组织的理念声明是否可能转化为真实行为，或分析组织行为与公开价值观的一致性时。 |
| [analyze-core-ideology-diversity-in-visionary-companies](analyze-core-ideology-diversity-in-visionary-companies/SKILL.md) | 判断高瞻远瞩公司是否存在普适性的核心理念内容。 | 用户试图从多家长期卓越企业中归纳“必须包含”的核心价值观，或在设计自身企业文化时寻求标准模板时。 |
| [core-ideology-driven-corporate-culture-analysis](core-ideology-driven-corporate-culture-analysis/SKILL.md) | 判断一家企业是否具备由强烈、一致且超越利润的核心理念所驱动的文化。 | 观察到公司展现出超越股东财富的共同信念体系，并体现在管理层言行、日常行为及组织认同中时。 |
| [pragmatic-idealism-duality-for-visionary-companies](pragmatic-idealism-duality-for-visionary-companies/SKILL.md) | 评估和指导高瞻远瞩公司在面临核心价值观与商业现实冲突时，如何同时坚持理想主义原则并采取务实行动。 | 企业战略制定者或组织文化设计者需要在利润压力下维护长期使命、或将价值观融入具体决策流程时。 |
| [sales-growth-driven-corporate-strategy](sales-growth-driven-corporate-strategy/SKILL.md) | 判断企业是否采用以销售额增长为核心驱动力的战略模式。 | 分析高瞻远瞩企业（如德州仪器）的目标设定逻辑，评估某企业是否将规模扩张视为首要价值时。 |
| [enterprise-fundamental-purpose-definition](enterprise-fundamental-purpose-definition/SKILL.md) | 明确企业存在的根本目的——即通过提供有价值的产品、服务或推动人类福祉来对社会作出贡献，而非将利润视为终极目标。 | 企业正在制定使命、愿景或人才培养战略时。 |
| [profit-role-in-visionary-companies](profit-role-in-visionary-companies/SKILL.md) | 重新诠释利润在高瞻远瞩公司中的角色：作为生存和实现目的的必要手段，而非终极目标。 | 分析或指导高瞻远瞩公司时，需澄清利润与使命的关系。 |
| [visionary-company-core-ideology-definition](visionary-company-core-ideology-definition/SKILL.md) | 识别和定义高瞻远瞩公司或追求长期存续的持久性机构的核心理念。 | 用户需要判断一个组织是否具备高瞻远瞩特质、构建企业文化根基，或制定以长期主义为导向的战略时。 |
| [establish-enduring-corporate-philosophy](establish-enduring-corporate-philosophy/SKILL.md) | 在企业创立初期或重大转型阶段，优先确立并书面化一套持久、可执行的企业理念。 | 初创企业、转型期企业及其创始人与高管团队，尤其当企业尚无稳定盈利模式或面临生存压力但需构建长期文化驱动力时。 |
| [wu-shi-de-li-xiang-zhu-yi](wu-shi-de-li-xiang-zhu-yi/SKILL.md) | 提供一种双重逻辑框架，用于指导高瞻远瞩公司在重大战略决策中平衡核心价值与实际利益。 | 企业面临是否投资无直接财务回报但符合使命的项目（如社会公益、长期研发）时。 |
| [visionary-company-paradox-dimensions](visionary-company-paradox-dimensions/SKILL.md) | 提供一套用于分析或构建高瞻远瞩公司特征的典型矛盾维度框架。 | 企业诊断分析师、战略对标研究者或组织领导者需要识别、评估或设计高瞻远瞩公司的双重卓越能力时。 |
| [er-yuan-jian-rong-yuan-ze](er-yuan-jian-rong-yuan-ze/SKILL.md) | 指导组织在面对看似矛盾的两极目标时，拒绝非此即彼思维，转而追求两极同时极致化。 | 组织面临传统二分法所定义的对立命题且具备长期发展愿景时。 |
| [design-visionary-company-mechanisms](design-visionary-company-mechanisms/SKILL.md) | 指导组织系统性构建具备持久成功能力的内部机制，而非依赖伟大构想或魅力型领袖。 | 用户目标是打造一家能长期自我驱动、价值观驱动且不依赖个人英雄主义的组织时。 |
| [from-telling-time-to-clock-building-mindset-shift](from-telling-time-to-clock-building-mindset-shift/SKILL.md) | 帮助领导者将思维模式从依赖个人魅力（“报时”）转向构建可持续组织系统（“造钟”）。 | 用户试图建立能长期成功、不依赖创始人持续干预的组织时。 |
| [zhao-zhong-shi-vs-bao-shi-zhe-leader-comparison](zhao-zhong-shi-vs-bao-shi-zhe-leader-comparison/SKILL.md) | 区分“造钟师型”与“报时者型”领导者，评估其对组织长期生命力的影响。 | 需要判断某位企业创始人或公司领导者是否致力于构建可持续的组织机制与文化时。 |
| [founder-leadership-impact-on-organizational-sustainability](founder-leadership-impact-on-organizational-sustainability/SKILL.md) | 评估和指导科技公司创始人采用以人为本、鼓励异议、授权员工并注重管理传承的领导方式。 | 关注如何通过创始人行为塑造可持续组织文化、确保创始人离世后企业仍能稳健运营时。 |
| [企业传承与长期主义接班人机制](企业传承与长期主义接班人机制/SKILL.md) | 指导企业系统性地设计并实施基于价值观一致性和长期主义文化的接班人机制。 | 企业已建立初步成功模式且创始人有意规划身后事时。 |
| [walton-clock-builder-leadership](walton-clock-builder-leadership/SKILL.md) | 指导企业创始人、组织领导层和零售业高管从“报时者”转变为“造钟师”。 | 领导者希望打造一个在创始人离任后仍能自我进化、持续改进的组织时。 |
| [非魅力型领导力建设高瞻远瞩公司](非魅力型领导力建设高瞻远瞩公司/SKILL.md) | 消除领导者因缺乏高知名度、魅力型风格而影响公司长期成功的焦虑，聚焦于构建可持续组织机制。 | 公司创建或关键转型阶段，且领导者需承担组织能力建设责任时。 |
| [reject-charismatic-leader-theory-in-visionary-companies](reject-charismatic-leader-theory-in-visionary-companies/SKILL.md) | 排除“魅力型伟大领袖”作为高瞻远瞩公司成功解释变量。 | 基于系统性历史比较数据、而非个别领袖轶事的情境下分析绩效差异时。 |
| [zao-zhong-shi-ling-dao-te-zhi-ping-gu](zao-zhong-shi-ling-dao-te-zhi-ping-gu/SKILL.md) | 评估企业创始人、早期塑造者或高层领导者是否具备“造钟师式”领导特质。 | 需判断某位领导者是否致力于制度化建设、权力移交和长期组织繁荣时。 |
| [debunk-great-idea-myth-in-company-founding](debunk-great-idea-myth-in-company-founding/SKILL.md) | 证伪“高瞻远瞩公司源于初始伟大构想”的迷思。 | 分析一家高瞻远瞩公司的创立历史、评估创业叙事真实性，或指导创业者理解成功路径时。 |
| [chu-qi-cheng-gong-yu-gao-zhan-yuan-zhu-gong-si-fan-bi-gui-lu](chu-qi-cheng-gong-yu-gao-zhan-yuan-zhu-gong-si-fan-bi-gui-lu/SKILL.md) | 识别“初期事业成功”与“成为高瞻远瞩公司”之间的反比规律。 | 分析18对高瞻远瞩公司与对照公司的历史数据，帮助创业者避免过度追求短期成功时。 |
| [analyze-great-idea-dependency-in-startups](analyze-great-idea-dependency-in-startups/SKILL.md) | 评估高瞻远瞩公司或对照公司在创业初期是否依赖“伟大构想”。 | 需要分析企业创业起源模式、验证“伟大构想”迷思，或比较卓越企业与普通企业的创始特征时。 |
| [extract-timeless-principles-from-organizational-history](extract-timeless-principles-from-organizational-history/SKILL.md) | 从长期导向组织的历史数据中提炼不受时间限制的根本管理原则。 | 需要从跨越数十年的企业实践中识别可传承、可复用的核心理念时。 |
| [历史演进分析三大理由](历史演进分析三大理由/SKILL.md) | 通过历史演进视角深入理解高瞻远瞩公司长期成功的核心动因。 | 需要制定长期战略、开展组织比较研究或探究企业根本动力时。 |
| [debunk-visionary-company-myths](debunk-visionary-company-myths/SKILL.md) | 纠正将高瞻远瞩公司成功归因于远见宣言或魅力型领袖的误解，引导关注深层系统性特质。 | 企业创始人、CEO、组织发展顾问和管理学者在探索企业长寿与卓越根源时。 |
| [兼容并蓄的融合法应用于高瞻远瞩公司战略](兼容并蓄的融合法应用于高瞻远瞩公司战略/SKILL.md) | 拒绝非此即彼的二分法思维，设计机制使对立目标共存并相互强化。 | 组织面临看似互斥的战略选择（如稳定性与变革、价值观与利润）时。 |
| [visionary-company-research-methodology](visionary-company-research-methodology/SKILL.md) | 提供一套用于识别企业基业长青根本原则的实证研究方法论。 | 研究目标是探究“是什么使真正杰出且历经时间考验的企业区别于其他优秀企业”时。 |
| [visionary-company-purpose-and-profit-perspective](visionary-company-purpose-and-profit-perspective/SKILL.md) | 判断企业目标结构是否符合“利润为手段而非目的”的核心理念。 | 评估或制定高瞻远瞩公司的战略目标、使命或董事会决策框架时。 |
| [core-ideology-stability-principle](core-ideology-stability-principle/SKILL.md) | 指导组织在面对外部环境变化时，如何坚守不可动摇的核心价值与基本存在目的。 | 涉及企业长期战略定位、文化传承或价值观管理，并明确其组织为或旨在成为“高瞻远瞩公司”时。 |
| [evolutionary-trial-and-error-in-visionary-companies](evolutionary-trial-and-error-in-visionary-companies/SKILL.md) | 解释高瞻远瞩公司实际成功机制——通过实验、错误尝试与机会主义行为进行进化式筛选。 | 创新管理团队构建容错文化与快速迭代机制时（不适用于核电、航空等零容错行业）。 |
| [post-bhag-risk-management](post-bhag-risk-management/SKILL.md) | 制定下一阶段目标及配套激励机制，防止组织陷入“我们已经到达了”综合症。 | 组织已成功实现BHAG并出现动力下降、创新停滞或自满迹象时。 |
| [high-order-change-mechanism-evaluation](high-order-change-mechanism-evaluation/SKILL.md) | 判断一家公司是否具备系统性、高阶的变革促进机制（超越“可行的自主权”）。 | 需要对公司历史实践进行回溯性组织发展能力评估，并具备可比标杆和历史文档证据时。 |
| [visionary-company-investment-pattern-analysis](visionary-company-investment-pattern-analysis/SKILL.md) | 评估企业是否具备高瞻远瞩公司的资本与研发投资特征。 | 希望判断某公司是否采取长期主义资源配置策略，或需比较高瞻远瞩公司与其对照组在资本支出、研发强度等方面的差异时。 |
| [startup-survival-strategy-for-visionary-companies](startup-survival-strategy-for-visionary-companies/SKILL.md) | 制定并执行生存与转型策略，适用于主营业务失败但仍有资金或战略支持的初创企业。 | 科技或制造类初创企业（如3M、索尼、摩托罗拉、惠普）在早期遭遇重大业务挫折时。 |
| [wartime-catalysis-for-tech-enterprises](wartime-catalysis-for-tech-enterprises/SKILL.md) | 识别战时机、承接军用订单并规划战后转型。 | 科技制造企业具备可应用于军事需求的技术能力，且处于战争或军事需求高涨时期时。 |
| [1920s-animation-business-model-analysis](1920s-animation-business-model-analysis/SKILL.md) | 分析1920年代手绘动画时代的独立制片业务模式及其从短片到长片的商业演进路径。 | 需要理解早期动画工作室（如迪士尼）如何通过短片试水、长片盈利验证商业模式时。 |
| [build-enduring-organizations-belief](build-enduring-organizations-belief/SKILL.md) | 确立“卓越组织可由普通人通过系统性实践构建”的核心信念，并激发立即行动与知识传递。 | 各级经理人、企业家、组织领导者和团队负责人希望打造高瞻远瞩、基业长青的组织时。 |
| [visionary-company-screening-method](visionary-company-screening-method/SKILL.md) | 从历史企业样本中识别具有长期卓越表现的“高瞻远瞩公司”。 | 研究目标是筛选1950年前创立、经CEO广泛认可且具备跨行业代表性的老牌成功企业时。 |
| [gaoceng-duizhao-zu-xuanze](gaoceng-duizhao-zu-xuanze/SKILL.md) | 为高瞻远瞩公司系统性地匹配合适的对照公司，以识别驱动长期卓越的独特机制。 | 研究目标是揭示高瞻远瞩公司与普通优秀企业的本质差异时。 |
| [research-practice-feedback-loop](research-practice-feedback-loop/SKILL.md) | 在真实企业环境中验证、迭代并优化研究框架或管理工具。 | 研究成果需通过实际商业应用进行检验，并依赖高层管理者及高级经理团队的持续反馈时。 |
| [社会科学实证研究的批判性评估](社会科学实证研究的批判性评估/SKILL.md) | 对基于历史案例的社会科学研究成果进行以证据为基础的独立批判性评估。 | 面对无法通过受控实验验证的社会科学主张时。 |
| [chuang-ye-zao-qi-sheng-cun-ce-lue](chuang-ye-zao-qi-sheng-cun-ce-lue/SKILL.md) | 指导资源有限、产品方向不明的初创企业采取机会主义导向，通过多样化尝试确保公司存续。 | 创业项目处于草创阶段、缺乏明确产品方向、资本紧张且需支付基本运营成本时。 |
| [shideman-organizational-building-practice](shideman-organizational-building-practice/SKILL.md) | 指导银行等大型金融机构或处于转型期的地方性企业，系统性构建可持续的现代化组织架构与领导传承机制。 | 企业目标是从地方性机构转型为全国性现代化公司，且已具备初步业务基础、领导者拥有长期愿景时。 |
| [founder-charisma-organizational-vulnerability-assessment](founder-charisma-organizational-vulnerability-assessment/SKILL.md) | 识别并评估过度依赖创始人个人魅力、缺乏制度化治理与传承机制的组织所面临的领导真空、创新停滞与长期竞争力衰退风险。 | 企业表现出决策高度集中、创始人被神化、无明确接班计划等特征时。 |
| [文化使命驱动型企业的并购防御决策](文化使命驱动型企业的并购防御决策/SKILL.md) | 在企业面临并购或资产出售决策时，优先保护其文化独立性而非短期股东利润。 | 企业具有明确的非财务文化使命并深度融入社会文化（如被视为国家文化象征）时。 |
| [early-stage-core-ideology-establishment](early-stage-core-ideology-establishment/SKILL.md) | 指导初创企业在资源匮乏、业务未稳的早期阶段，主动制定并公开核心理念文档。 | 企业处于生存压力大但希望构建长期愿景时，而非等待财务安全或业务成功后再确立理念。 |
| [idealism-pragmatism-dialectical-unification](idealism-pragmatism-dialectical-unification/SKILL.md) | 融合理想主义愿景与实用主义手段，以实现战略韧性与可持续发展。 | 企业已确立基本理念但遭遇资源约束、竞争压力或执行困境时。 |
| [profit-mission-integration-framework](profit-mission-integration-framework/SKILL.md) | 指导企业将利润定位为实现使命的手段而非终极目标，并据此调整治理机制、绩效评估与人才标准。 | 企业在平衡财务目标与社会使命时出现张力（例如管理层争论资源应优先用于盈利还是社会价值）时。 |
| [johnson-johnson-belief-based-crisis-response](johnson-johnson-belief-based-crisis-response/SKILL.md) | 指导依据五层责任优先级做出符合长期价值观的行动决策。 | 企业面临重大决策或危机事件，且已建立成文的企业信念体系（如Johnson & Johnson《我们的信念》）时。 |
| [profit-over-purpose-trap-detection](profit-over-purpose-trap-detection/SKILL.md) | 检测创始人离任后企业是否陷入“利润至上”陷阱，即仅聚焦财务指标而缺乏制度化使命与价值观。 | 企业属于传统企业、创始人依赖型组织或缺乏制度化文化的公司，且在创始人退出后决策仅围绕利润和市场占有率展开时。 |
| [marriott-core-values-and-succession-mechanism](marriott-core-values-and-succession-mechanism/SKILL.md) | 指导服务型、家族企业或酒店餐饮行业建立以价值观驱动的长期文化传承体系。 | 企业希望建立可持续的跨代文化、确保创始人价值观在组织中延续时。 |
| [family-business-ideological-succession-failure-pattern](family-business-ideological-succession-failure-pattern/SKILL.md) | 识别并警示因创始人未将核心价值观制度化、且第二代接班人缺乏理念传承而导致的服务型企业衰败风险。 | 分析家族企业（尤其是服务行业）在代际交接后出现服务质量下滑、财务导向偏激、品牌价值贬损等现象时。 |
| [profit-only-operating-model-identification](profit-only-operating-model-identification/SKILL.md) | 识别企业是否采用纯利润导向的运营模式（即完全将产品视为赚钱工具，缺乏情感或理念认同）。 | 企业高层公开表示“若无法通过产品盈利则可放弃该产品”且无情感投入时。 |
| [evaluate-core-ideology-effectiveness](evaluate-core-ideology-effectiveness/SKILL.md) | 判断一家公司的核心理念是否真正有效，关键在于其真实性与行为一贯性。 | 企业管理者、企业文化建设者或组织变革推动者需要评估或构建公司核心理念时。 |
| [formulate-purpose-statement](formulate-purpose-statement/SKILL.md) | 指导制定或评估组织的目的宣言。 | 组织正在起草、修订或审查其存在根本原因的正式或非正式表述时。 |
| [qi-ye-zi-wo-ge-xin-ji-zhi](qi-ye-zi-wo-ge-xin-ji-zhi/SKILL.md) | 指导技术型或产品导向型企业，在现有核心产品仍具商业价值时主动启动替代性创新项目。 | 企业满足“在产品衰退前即启动替代研发”的触发条件、具备前瞻性技术判断能力、容忍失败的文化及清晰的产品生命周期认知时。 |
| [颠覆性技术转折点的战略响应决策](颠覆性技术转折点的战略响应决策/SKILL.md) | 评估是否应采取“胆大包天”激进策略或保守观望路径。 | 行业出现颠覆性技术范式转移（如螺旋桨→喷气式）、市场信号模糊或负面、且竞争对手已启动高风险项目时。 |
| [bold-vision-implementation-mechanism](bold-vision-implementation-mechanism/SKILL.md) | 指导基于对目标正确性的坚定信念，分阶段推进高风险高回报的战略举措。 | 决策者确信某项大胆行动在道德或战略上“正确”且已通过小范围试点验证可行性时。 |
| [visionary-company-employee-fit-binary-rule](visionary-company-employee-fit-binary-rule/SKILL.md) | 判断潜在或在职员工是否适合高瞻远瞩公司的核心文化与理念。 | 组织拥有强烈且明确的核心理念（如惠普风范、迪斯尼魔法信仰等），且需评估员工对文化的真诚信念与行为适配度时。 |
| [elite-identity-driven-organizational-excellence](elite-identity-driven-organizational-excellence/SKILL.md) | 通过强化精英主义自我认知来维持内部凝聚力、激发创新动力并提升组织韧性。 | 高科技企业、知识密集型组织或追求长期领先的企业面临剧烈外部变化时。 |
| [disney-employee-screening-and-grooming-standards](disney-employee-screening-and-grooming-standards/SKILL.md) | 执行或评估迪斯尼乐园职位应聘者的标准化筛选流程与仪容规范。 | 需要了解、实施或分析迪斯尼特有的员工筛选机制、文化契合度评估及外在形象要求时。 |
| [disney-university-onboarding-and-role-socialization](disney-university-onboarding-and-role-socialization/SKILL.md) | 为新入职迪士尼员工设计或执行标准化入职培训流程，将其转化为内化迪士尼核心理念的“演员”。 | 需要为新入职迪士尼员工（包括实习生和总部岗位）设计或执行标准化入职培训流程时。 |
| [pg-employee-equity-and-dividend-incentive-mechanism](pg-employee-equity-and-dividend-incentive-mechanism/SKILL.md) | 解析和应用宝洁公司历史上建立的员工股权与分红激励机制。 | 需要分析或设计类似“将经济激励与员工行为、忠诚度及保密义务绑定”的薪酬体系时。 |
| [jiao-pai-shi-wen-hua-rong-he-duo-yuan-hua-yu-chuang-xin](jiao-pai-shi-wen-hua-rong-he-duo-yuan-hua-yu-chuang-xin/SKILL.md) | 将多元化重新定义为与核心信念一致的进步形式，在坚守根本价值观的前提下实现包容性与文化凝聚力的统一。 | 组织希望建立强文化（如教派式）的同时促进多元化或创新时。 |
| [darwinian-business-evolution-selection](darwinian-business-evolution-selection/SKILL.md) | 依据市场适应性自动筛选存续项目并淘汰失败选项。 | 组织同时推进多个实验性项目（如产品、业务单元或创新项目）时。 |
| [nuo-shi-quan-shi-yuan-gong-shou-quan-shi-jian](nuo-shi-quan-shi-yuan-gong-shou-quan-shi-jian/SKILL.md) | 授权一线员工基于价值观和专业判断自主决定处理方式，而非依赖预设规则。 | 一线员工已内化公司价值观并面临需即时决策的客户服务情境（如退货）时。 |
| [customer-problem-driven-gradual-business-expansion](customer-problem-driven-gradual-business-expansion/SKILL.md) | 基于真实顾客痛点，通过渐进式创新和低姿态实验，在未获高层明确授权的情况下逐步拓展至全新业务领域。 | 服务型企业、金融或旅游相关机构等拥有广泛客户触点的组织，当高层或顾客在使用现有产品时遭遇普遍性显著不便时。 |
| [3m-style-failure-driven-strategic-pivot](3m-style-failure-driven-strategic-pivot/SKILL.md) | 指导组织在核心业务遭遇近乎致命失败时，进行应急性战略重构。 | 初创企业、陷入困境的公司或资源受限组织，在生存危机下通过全员协作与资源再利用实现业务方向的战略转移时。 |
| [mcknight-driven-open-innovation-mechanism](mcknight-driven-open-innovation-mechanism/SKILL.md) | 主动探究外部请求的潜在突破性应用，并将外部发明者整合进组织，以建立持续创新能力。 | 技术型或研发导向组织收到看似无关但可能隐含新技术机会的外部请求时。 |
| [3m-systematic-innovation-incentive-mechanism](3m-systematic-innovation-incentive-mechanism/SKILL.md) | 为科技人员、产品部门、研发团队和内部创业者设计或激活一套相互协同的创新激励机制。 | 员工提出创新构想、参与新产品开发，或组织需建立可持续创新能力时。 |
| [assess-long-term-competitiveness-from-early-financial-advantage](assess-long-term-competitiveness-from-early-financial-advantage/SKILL.md) | 判断一家企业在早期表现出色是否能维持长期竞争优势。 | 分析初创企业、成熟企业或行业领导者在缺乏持续创新机制下的潜在衰退风险时。 |
| [ceo-office-succession-mechanism](ceo-office-succession-mechanism/SKILL.md) | 建立由多名高管组成的集体领导机构（CEO办公室），配套长期人才梯队建设。 | 组织希望避免因关键领导者突然离任导致管理断层、且具备多层级管理结构和制度化继任意愿时。 |
| [系统性人才梯队建设](系统性人才梯队建设/SKILL.md) | 制定并执行覆盖全层级的继任者培养计划，确保每个关键岗位均有2-3名经核心理念训练的后备人选。 | 企业需确保跨代际管理连续性、维持核心理念稳定性，且已确立清晰的核心价值观和高层推动意愿时。 |
| [detect-authoritarian-leadership-succession-risk](detect-authoritarian-leadership-succession-risk/SKILL.md) | 识别并评估长期任职、强控制欲的CEO对组织继任机制造成的系统性破坏风险。 | 企业存在压制潜在继任者、回避继任讨论或形成“独角戏”式管理文化等行为时。 |
| [ge-style-ceo-succession-planning](ge-style-ceo-succession-planning/SKILL.md) | 为大型多元化企业设计并执行一套系统化、多阶段的CEO继任规划程序。 | 公司需要为未来7–10年选定CEO，且强调从内部培养高潜力人才时。 |
| [ge-ceo-financial-performance-historical-evaluation](ge-ceo-financial-performance-historical-evaluation/SKILL.md) | 结合多维度回报率指标进行跨时代比较，客观评价通用电气（GE）某位CEO的历史地位。 | 分析GE或类似长期稳定企业的CEO绩效，尤其在有完整财务数据（1915年起）及可比对手数据的场景下。 |
| [yong-bu-man-zu-ji-zhi-shi-shi](yong-bu-man-zu-ji-zhi-shi-shi/SKILL.md) | 提供七种经过验证的“永不满足”组织机制模板，用于建立持续创新与自我挑战的文化。 | 组织具备一定规模、管理层有长期战略视野，并希望将“永不满足”理念转化为具体管理实践时。 |
| [危机时期逆周期人才战略](危机时期逆周期人才战略/SKILL.md) | 制定并执行优先保留核心人才、逆势招聘顶尖技术人才的战略。 | 企业因外部环境剧变导致营收骤降40%以上，同时市场上出现高素质技术人才集中释放窗口时。 |
| [uncompromising-long-term-principles-discipline](uncompromising-long-term-principles-discipline/SKILL.md) | 当员工为提升短期利润而违反公司既定道德原则时，必须立即执行零容忍处理。 | 已建立清晰价值观体系的企业管理者、部门负责人及决策层，在面临短期绩效压力与长期伦理冲突时。 |
| [持续精进成就哲学](持续精进成就哲学/SKILL.md) | 将奖项、头衔或阶段性成功视为持续奋斗的起点而非终点。 | 个体或组织表现出“将某项成就视为终点”的思维倾向（如满足于黑带、业绩高峰或市场领先地位）时。 |
| [coordinated-transformation-paradigm](coordinated-transformation-paradigm/SKILL.md) | 系统性地将理念转化为跨职能、多层次、可持续的日常行动体系。 | 企业已发布使命/价值观宣言并希望实现真正组织转型时。 |
| [merck-breakthrough-innovation-rd-mechanism](merck-breakthrough-innovation-rd-mechanism/SKILL.md) | 构建抗市场短视的制药研发体系，通过完全独立的基础研究治理实现突破性药物创新。 | 企业致力于基础科学突破、希望避免短期市场回报压力干扰研发决策，并具备顶尖科学家团队及管理层长期承诺时。 |
| [detect-corporate-short-termism-traps](detect-corporate-short-termism-traps/SKILL.md) | 识别企业因短期主义行为（如削减研发、过度降本、管理层奢侈消费或回避创新）而陷入失败陷阱的风险。 | 分析一家曾具市场地位但面临增长或转型压力的公司，并观察到上述任一警示信号时。 |
| [hewlett-packard-employee-respect-practices](hewlett-packard-employee-respect-practices/SKILL.md) | 参考惠普公司建立高忠诚度、低对抗性员工关系的核心实践。 | 企业需要制定或调整人力资源政策、员工福利体系或组织沟通机制时。 |
| [hp-technology-driven-innovation-screening](hp-technology-driven-innovation-screening/SKILL.md) | 评估新产品或新业务提案是否符合惠普式技术驱动创新标准。 | 新产品开发、研发资源配置和市场进入决策场景，前提是存在潜在产品概念且具备工程团队评估能力。 |
| [构建高瞻远瞩公司的普遍可及性信念](构建高瞻远瞩公司的普遍可及性信念/SKILL.md) | 破除“只有非凡领袖才能成功”的迷思，并激发普通管理者、基层员工或非魅力型领导者立即承担组织建设责任。 | 个体认为自己缺乏特殊天赋、创意或魅力，因而怀疑能否参与打造高瞻远瞩公司时。 |
| [组织协调一致机制实施](组织协调一致机制实施/SKILL.md) | 制定并执行一套至少包含6项具体措施的行动计划，以同步强化“保存核心”与“刺激进步”。 | 组织已明确核心理念（核心价值与目的）并规划进步方向（如胆大包天目标）时。 |
| [gaolan-yuanzhu-gongsi-fuxing-zhenduan](gaolan-yuanzhu-gongsi-fuxing-zhenduan/SKILL.md) | 诊断具有长期高瞻远瞩历史但当前趋于保守、保护既有利益或遗忘初心的龙头企业是否真正衰退，并指导其制定复兴路径。 | 企业历史上曾是高瞻远瞩典范，但近年出现“热衷保护而非冒险”“忘却根本信念”等行为时。 |
| [visionary-company-principles-universality](visionary-company-principles-universality/SKILL.md) | 澄清高瞻远瞩公司理念的普适适用范围，并识别其与其他组织理论的关键异同。 | 组织（包括营利企业、非营利机构、大学、医院、宗教组织或国家治理实体）试图应用高瞻远瞩公司理念时。 |
| [distinguish-visionary-companies-from-financial-success](distinguish-visionary-companies-from-financial-success/SKILL.md) | 判断一家公司在1978–1988年间是否因真正具备高瞻远瞩特质而非仅短期财务回报优异而被归类为“高瞻远瞩公司”。 | 分析《财富》500强公司、评估CEO评价体系或澄清“高瞻远瞩”与“财务成功”的概念混淆时。 |
| [ceo-survey-methodology-for-visionary-company-identification](ceo-survey-methodology-for-visionary-company-identification/SKILL.md) | 指导研究者在缺乏先验定义的情况下，如何合理使用CEO调查作为识别高瞻远瞩公司的初始筛选机制。 | 需要从大型公众持股公司中初步筛选潜在高瞻远瞩企业、且调查对象为一流CEO时。 |
| [visionary-company-research-source-system](visionary-company-research-source-system/SKILL.md) | 构建高瞻远瞩公司历史研究的八类信息来源体系，用于开展企业长期发展轨迹的定性与定量综合分析。 | 需要对具有充分历史记录的企业进行深度历史比较研究、企业档案分析或整合多源数据以验证研究结论时。 |
| [feasible-autonomy-historical-evidence-grading](feasible-autonomy-historical-evidence-grading/SKILL.md) | 评估公司在历史上使用“可行的自主权”作为促进发展手段的程度，输出高、中、低三档评级。 | 需要对公司历史实践进行回溯性组织发展能力评估，并具备可比标杆（如‘H’类公司）和历史文档证据时。 |
| [bian-ge-cu-jin-ji-zhi-zheng-ju-fen-ji](bian-ge-cu-jin-ji-zhi-zheng-ju-fen-ji/SKILL.md) | 对公司或组织评估框架中关于变革促进机制的历史使用证据进行强度分级，并判断其与‘H’级标准的差距。 | 需诊断组织变革能力、且已初步审查历史机制使用但证据不充分、明显弱于‘H’级标准或几乎不存在时。 |
| [early-stage-startup-success-pattern-analysis](early-stage-startup-success-pattern-analysis/SKILL.md) | 分析和验证创业企业在早期阶段是否符合历史上成功企业的典型增长模式。 | 需要评估初创企业是否具备快速市场契合、早期盈利、资本扩张和行业地位确立等特征时。 |
| [founder-background-entrepreneurship-correlation](founder-background-entrepreneurship-correlation/SKILL.md) | 分析创始人在创业前的职业或技术背景如何驱动其创业方向和资源整合策略。 | 需要评估企业创立逻辑、解释早期战略选择，或判断创始人经验对业务起点的影响时。 |
| [bingou-zhenghe-xing-chuangye-moshi](bingou-zhenghe-xing-chuangye-moshi/SKILL.md) | 通过并购方式创建规模化企业。 | 市场高度分散、存在多个小型竞争企业且具备资本或整合能力时。 |
| [技术路线竞争影响评估](技术路线竞争影响评估/SKILL.md) | 评估企业在存在相互竞争技术标准的环境中，因押注特定技术路线而对其长期命运产生的影响。 | 分析技术驱动型行业中的企业战略成败、标准竞争结果或创新采纳后果时。 |
| [product-innovation-driven-early-growth](product-innovation-driven-early-growth/SKILL.md) | 评估和实施以产品创新驱动的早期企业增长策略。 | 企业具备研发或产品设计能力，且市场存在未满足需求时。 |
| [retail-regional-expansion-strategy](retail-regional-expansion-strategy/SKILL.md) | 指导聚焦小城镇或特定区域市场的零售与服务企业制定渐进式门店扩张计划。 | 企业具备可复制的商业模式、明确的地理市场定位，且不属于全国性或线上优先类型时。 |
| [disney-founding-team-age-lookup](disney-founding-team-age-lookup/SKILL.md) | 返回迪士尼公司创始团队成员的姓名及对应年龄信息。 | 用户明确查询“迪士尼创始人”“迪士尼早期团队”或类似历史事实时。 |
| [disney-founding-location-identification](disney-founding-location-identification/SKILL.md) | 准确识别华特·迪士尼公司初创时期的地理位置及具体场所。 | 用户需要确认迪士尼公司创立时所在的城市和初始办公地点（而非后续总部变迁）时。 |
| [disney-inspired-entrepreneurial-pivot-under-resource-constraints](disney-inspired-entrepreneurial-pivot-under-resource-constraints/SKILL.md) | 提供在目标行业求职失败但仍有强烈进入意愿时，如何利用有限资源启动创业的具体行动步骤。 | 个人创业者在资源受限情境下将失业困境转化为自主创业机会时。 |
| [应对入行时机焦虑](应对入行时机焦虑/SKILL.md) | 评估创业者因进入已有数年发展历史的成熟行业较晚而产生的自我怀疑心理状态并采取行动。 | 不适用于全新蓝海市场。 |
| [disney-visionary-company-study-classification](disney-visionary-company-study-classification/SKILL.md) | 返回迪士尼在《高瞻远瞩的公司》成对比较研究中的角色、分类或与哥伦比亚电影公司的对比结果。 | 用户查询迪士尼在该特定研究框架下的定位时。 |
| [初创企业非传统空间利用策略](初创企业非传统空间利用策略/SKILL.md) | 提供在缺乏正式办公或生产空间时，如何安全、高效地利用亲属提供的闲置空间启动创意类业务的操作指南。 | 资源受限的创业者，特别是创意产业初创者，在满足“有亲属支持”和“可获取闲置空间”前提下，且不涉及重资产或高监管行业时。 |
| [great-idea-vs-company-success-analysis](great-idea-vs-company-success-analysis/SKILL.md) | 提供基于18对公司样本的实证结论，评估“创业初期是否必须拥有伟大构想才能取得长期成功”。 | 创业理论探讨、企业成功因素分析或纠正“伟大构想迷思”的场景。 |
| [talent-investment-company-coding-mapping](talent-investment-company-coding-mapping/SKILL.md) | 定义人才能力投资数据表中公司代号与列位置的映射规则。 | 需要引用或解析以大写英文字母（A-Z循环）标识的公司数据列时。 |
| [zhongxin-kindle-hot-books-display](zhongxin-kindle-hot-books-display/SKILL.md) | 按指定顺序和格式展示中信Kindle热书榜热门电子书列表。 | 中信出版社在Kindle平台的电子书营销场景。 |
| [zhongxin-ebook-platform-user-redirect](zhongxin-ebook-platform-user-redirect/SKILL.md) | 在中信Kindle热书榜页面末尾，自动插入导流提示以引导移动端用户跳转至中信飞书App。 | 在线阅读场景，且设备支持外部链接跳转时。 |

## Quick Navigation

### 核心理念构建
- **构建高瞻远瞩公司的核心理念体系**: 识别、验证并确立组织的核心价值观与根本目的。
- **define-core-ideology**: 界定由不可妥协的核心价值与超越利润的根本目的共同构成的完整核心理念。
- **zheng-hei-he-xin-jia-zhi-shi-bie-yu-zhi-ding**: 甄别并制定真实、不可妥协的核心价值观。
- **formulate-purpose-statement**: 制定或评估组织的存在根本原因的正式表述。

### 胆大包天目标（BHAG）
- **设定胆大包天目标**: 制定并公开一个看似几乎不可能实现但方向明确的长期目标。
- **define-bhag-goals**: 评估目标是否具备明确性、动人性、易懂性和集中性四大核心特征。
- **bhag-core-alignment-check**: 检验BHAG是否植根于公司已定义的自我定位并强化其不变的核心理念。
- **bhag-completion-risk-management**: 识别“我们完成了”病症风险，并制定继任BHAG。

### 文化与组织机制
- **cult-like-culture-building-for-core-ideology**: 建立对核心理念有宗教般虔信的组织环境。
- **institutionalizing-never-satisfied-mechanisms**: 设计制度化的持续改善机制，防止自满。
- **系统性人才梯队建设**: 确保每个关键岗位均有2-3名经核心理念训练的后备人选。
- **leadership-succession-and-core-ideology-preservation**: 确保新领导者与公司核心理念高度一致。

### 造钟 vs 报时
- **zao-zhong-yu-bao-shi-ce-lue-qu-fen**: 区分“造钟”与“报时”两类根本性组织战略。
- **from-telling-time-to-clock-building-mindset-shift**: 将思维模式从依赖个人魅力转向构建可持续组织系统。
- **非魅力型领导力建设高瞻远瞩公司**: 聚焦于构建可持续组织机制而非模仿外向型领导形象。

### 实验与进化
- **evolutionary-progress-through-purposeful-experimentation**: 启动小步实验、快速验证并制度化成功变异。
- **darwinian-business-evolution-selection**: 依据市场适应性自动筛选存续项目并淘汰失败选项。
- **3m-style-failure-driven-strategic-pivot**: 在核心业务遭遇近乎致命失败时，进行应急性战略重构。

### 战略与决策
- **高瞻远瞩公司的战略决策与自我一致性原则**: 以“是否契合自身理念”而非“外部评价”为决策依据。
- **保存核心与刺激进步的辩证原则**: 正确区分并坚守不变的核心理念，同时持续革新所有非核心做法。
- **er-yuan-jian-rong-yuan-ze**: 拒绝非此即彼思维，追求两极同时极致化。

### 创始人与传承
- **企业传承与长期主义接班人机制**: 设计基于价值观一致性和长期主义文化的接班人机制。
- **founder-leadership-impact-on-organizational-sustainability**: 评估创始人行为对组织长期存续与创新能力的影响。
- **detect-authoritarian-leadership-succession-risk**: 识别强控制欲CEO对组织继任机制造成的系统性破坏风险。

### 误区与迷思破除
- **debunk-great-idea-myth-in-company-founding**: 证伪“高瞻远瞩公司源于初始伟大构想”的迷思。
- **reject-charismatic-leader-theory-in-visionary-companies**: 排除“魅力型伟大领袖”作为成功解释变量。
- **构建高瞻远瞩公司的普遍可及性信念**: 破除“只有非凡领袖才能成功”的迷思。

## How to Use
当您面临与高瞻远瞩公司构建相关的任务时，请根据上述“Use When”列或“Quick Navigation”中的分类，选择最匹配的技能。在与Claude交互时，可直接提及技能名称（如“使用‘设定胆大包天目标’技能”），Claude将自动加载对应技能文档并提供针对性指导。建议优先使用中文技能名称以获得最佳体验。
```