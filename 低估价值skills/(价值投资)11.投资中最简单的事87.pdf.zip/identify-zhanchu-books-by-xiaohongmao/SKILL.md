---
name: Identify Zhanchu Books by "Xiaohongmao" Mark
description: Use this skill when a user needs to quickly identify whether a physical book is an official publication from Zhanchu Culture based on its standardized visual identifiers. Apply this skill only to books that appear to follow Zhanchu’s standard binding and design.
---

# Identify Zhanchu Books by "Xiaohongmao" Mark

## When to Use
Use this skill **only** when:
- The user is examining a physical book and wants to confirm if it is an official Zhanchu Culture publication.
- The book appears to follow standard commercial printing (not custom editions, proofs, or non-Zhanchu imprints).

## How to Execute
Follow these steps in order:

1. **Check the cover**: Look for a red mark named “小红帽” (Xiaohongmao) in the **top-left corner** of the front cover.
2. **Check the spine**: Confirm the same red “小红帽” mark appears on the **spine**, precisely **47mm from the top**.
3. **Verify slogan**: Ensure the cover’s top-left corner also includes the **“湛庐文化 Slogan”** text alongside the mark.
4. **Inspect spine details**: Below the “小红帽” on the spine, confirm the presence of:
   - The **Zhanchu Culture logo**
   - The **imprint brand name** (e.g., “财富汇” or “心视界”)
5. **Confirm match**: If **all** elements above are present and correctly positioned, the book is a verified Zhanchu Culture standard publication.

> **Note**: The “小红帽” mark’s **color (red)** and **positions (cover top-left, spine 47mm from top)** are fixed and non-negotiable. Any deviation indicates a non-standard or non-Zhanchu book.