---
name: Investment Philosophy and Risk Principles
description: Establishes foundational investment principles covering style selection, risk management, and strategy suitability. Use when defining your investment approach or evaluating whether value investing fits current conditions.
---

# 投资哲学与风险原则

## 何时使用
- 需选择投资风格（价值/成长/GARP）
- 考虑采用价值投资策略
- 评估成长股可持续性
- 应用古典风险管理智慧

## 执行步骤
1. **明确投资风格**：
   - **价值投资**：依赖现有资产、利润、现金流（P₀ << V₀）
   - **成长投资**：押注未来增长（P₀ < V₀ << Vₙ）
   - **GARP**：兼顾成长与合理估值

2. **验证价值投资四大条件**：
   - 内在价值可确定（如消费品，非矿业）
   - 内在价值独立于股价（无反身性）
   - 合适市场阶段（牛市上半段最佳）
   - 合适投资期限（≥10年）

3. **应用管子四不可原则**：
   - 不为不可成（可行性）
   - 不求不可得（可得性）
   - 不处不可久（可持续性）
   - 不行不可复（可逆性）

4. **判断成长可持续性**：
   - 高增长必须有高门槛支撑（品牌、渠道、规模、资源、资质、专利）
   - 无门槛的高增长属“成长陷阱”（如团购、手游）
   - 警惕“金玉之堂，莫之能守”

> 核心信念：对大多数人，价值投资是真正可学、可用、可掌握的方法。