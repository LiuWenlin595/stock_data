---
name: Company Quality Assessment Framework
description: Evaluates whether a company qualifies as a "good business" based on competitive advantages, industry structure, and pricing power. Use this when analyzing long-term investment candidates to distinguish sustainable winners from temporary performers.
---

# 公司品质评估框架

## 何时使用
- 需判断企业是否具备长期护城河
- 比较“高门槛低增长”与“低门槛高增长”企业
- 评估行业是否属于“好生意”
- 面对股价剧烈波动时回归实业视角

## 执行步骤
1. **检验双重标准**：
   - 是否“别人做不了”（门槛/壁垒）
   - 是否“自己可重复做”（成长可复制性）
   - 若只能满足其一，优先选择“有门槛的低增长”

2. **分析行业三大特征**：
   - **有门槛**：需牌照、品牌、专利或稀缺资源
   - **有积累**：经验、客户关系可复利增长（非快迭代行业）
   - **有定价权**：能自主提价而不显著失客

3. **评估定价权来源**：
   - 寡头垄断格局（如白色家电、工程机械）
   - 强势品牌（如茅台）
   - 下游客户分散 + 产品差异化

4. **应用实业眼光**：问“这是不是一门好生意？”而非“股价会不会涨？”
5. **警惕烂生意**：即使短期热门（如手游），若竞争无序、生命周期短、议价权弱，则应回避。

> 核心原则：门槛是既成事实、易把握；成长是未来预期、难预测。真正的护城河应能长期阻止竞争。