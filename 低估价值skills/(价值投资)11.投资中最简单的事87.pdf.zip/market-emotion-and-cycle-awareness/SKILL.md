---
name: Market Emotion and Cycle Awareness
description: Diagnoses market sentiment stages and investor behavioral biases to time contrarian entries. Use when observing extreme pessimism/optimism or widespread right-side trading behavior in A-share markets.
---

# 市场情绪与周期认知

## 何时使用
- 市场连续下跌，投资者表现出担忧、恐惧或绝望
- 指数长期横盘（如十年未涨）但估值已处低位
- 普遍等待“右侧信号”而忽视安全边际
- 持仓下跌引发焦虑，需检验认知深度

## 执行步骤
1. **定位情绪阶段**（八阶段模型）：
   - 第1–3阶段：担忧→抵赖→害怕（早期）
   - 第4–6阶段：绝望→恐慌→放弃（接近底部）
   - 第7–8阶段：麻木→沮丧（潜在极值点）

2. **识别右侧偏差**：
   - 当“好公司没人要，便宜股票买入后变得更便宜”
   - 投资者偏好“涨潮时游泳”，回避“退潮最低点”
   - 提醒：“缺的不是价值，而是坚守价值的心”

3. **检验持仓心理稳定性**：
   - 自问：“如果买入后下跌，我是否敢于加仓？”
   - 若“心里一点也不慌，甚至希望多跌一点” → 研究充分
   - 若“肝肠寸断” → 未真正理解，不应持有

4. **行动指导**：
   - 在第6–8情绪阶段，结合低估值，考虑逆向布局
   - 克服“害怕成为最后傻瓜”的心理障碍
   - 接受无法预测拐点，但坚持不接最后一棒

> 核心洞察：情绪演进不可跳跃，底部区域往往伴随“有钱的没胆，有胆的没钱”。