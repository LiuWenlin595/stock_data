```markdown
# 克劳德投资技能库（基于《7Ddabeb1-C58F-4740-Bf83-1Accebbdd866》）

本技能库源自专业投资著作，涵盖价值投资、行业分析、市场周期判断、行为金融、资产配置及对冲基金评估等核心领域。用户可借助这些技能系统化地识别投资机会、规避常见认知偏差、构建安全边际，并在A股、港股、美股等市场中做出更理性的长期决策。

## Available Skills

| Skill | Description | Use When |
|-------|-------------|----------|
| [contrarian-investment-core-principles](contrarian-investment-core-principles/SKILL.md) | 在市场情绪极端悲观或乐观、资产因情绪过激而错定价时识别逆向机会 | 市场出现“众人回避”但基本面尚可的资产 |
| [company-quality-assessment-framework](company-quality-assessment-framework/SKILL.md) | 评估企业是否具备护城河、行业结构优势与定价权 | 分析长期投资标的是否为“好生意” |
| [industry-structure-and-leadership-strategy](industry-structure-and-leadership-strategy/SKILL.md) | 识别寡头化、集中度提升的行业，优先投资龙头 | 筛选具备长期竞争优势的行业与公司 |
| [valuation-and-safety-margin-analysis](valuation-and-safety-margin-analysis/SKILL.md) | 判断资产是否真正“便宜”，评估内在价值与下行保护 | 考虑买入长期持仓，尤其在A股市场 |
| [contrarian-investment-risk-screening](contrarian-investment-risk-screening/SKILL.md) | 多层风险过滤，避免价值陷阱与反射性崩盘 | 考虑抄底因危机、丑闻或市场恐慌暴跌的股票 |
| [investment-decision-three-pillars](investment-decision-three-pillars/SKILL.md) | 通过估值、品质、时机三维度结构化评估股票 | 任何长期股权投资前的系统性检查 |
| [market-emotion-and-cycle-awareness](market-emotion-and-cycle-awareness/SKILL.md) | 诊断市场情绪阶段与行为偏差，把握逆向时点 | A股出现极端悲观/乐观或右侧交易盛行 |
| [investment-philosophy-and-risk-principles](investment-philosophy-and-risk-principles/SKILL.md) | 建立投资风格选择、风险管理与策略适配原则 | 定义个人投资方法论或评估价值投资适用性 |
| [historical-analogy-in-investment](historical-analogy-in-investment/SKILL.md) | 通过历史相似情境（泡沫、危机、政策转折）预判当前市场路径 | 面对“前所未有”的市场叙事时寻求参照 |
| [contrarian-opportunity-identification](contrarian-opportunity-identification/SKILL.md) | 识别“共识性恐惧”与“显性价值”共存的逆向机会 | 市场情绪极端且优质资产被错杀 |
| [industry-allocation-framework](industry-allocation-framework/SKILL.md) | 从行业层面评估估值、品质与时机，指导资产配置 | 基金经理或大资金进行行业配置决策 |
| [cockroach-theory-risk-assessment](cockroach-theory-risk-assessment/SKILL.md) | 高估值成长股首次暴露问题时，评估是否暗示系统性缺陷 | 持有或关注高预期成长股出现负面信号 |
| [timing-prediction-limitation-awareness](timing-prediction-limitation-awareness/SKILL.md) | 提醒避免过度依赖事件发生时间预测 | 分析师试图精确判断并购、利率变动等时点 |
| [new-normal-investment-framework](new-normal-investment-framework/SKILL.md) | 在“低实际增长、高通胀、高名义GDP”新常态下指导投资 | 经济进入结构性新阶段，需调整资产偏好 |
| [macro-logic-chain-forecasting](macro-logic-chain-forecasting/SKILL.md) | 构建宏观逻辑链，映射至行业配置并设定动态调整机制 | 制定年度策略且处于重大经济转折点 |
| [industry-inflection-and-leader-selection](industry-inflection-and-leader-selection/SKILL.md) | 行业集中度拐点临近时，识别并买入定价权龙头 | 行业从分散走向集中，竞争格局改善 |
| [价值投资纪律坚守与卖出决策](价值投资纪律坚守与卖出决策/SKILL.md) | 帮助价值投资者坚守估值纪律，基于客观标准卖出 | 面临风格分化或持仓基本面变化时避免情绪化操作 |
| [avoid-market-timing-and-hindsight-bias](avoid-market-timing-and-hindsight-bias/SKILL.md) | 规避短期择时无效性与“后视镜效应” | 用户依赖技术指标或仅凭历史表现外推未来 |
| [assess-chinese-hedge-fund-limitations](assess-chinese-hedge-fund-limitations/SKILL.md) | 评估中国对冲基金的真实风控与业绩可持续性 | QFII尽调、私募自评或判断基金是否依赖择时 |
| [identify-zhanchu-books-by-xiaohongmao](identify-zhanchu-books-by-xiaohongmao/SKILL.md) | 通过视觉标识识别战储文化官方出版物 | 用户提供实体书图片或描述需验证来源 |
| [verify-zhanchu-award-books-2008-2013](verify-zhanchu-award-books-2008-2013/SKILL.md) | 验证2008–2013年战储图书是否为获奖作品 | 已知书名与出版年份需确认奖项身份 |
| [investment-philosophy-articulation](investment-philosophy-articulation/SKILL.md) | 生成简洁、反直觉、行动导向的投资信条 | 需向他人清晰传达核心投资理念 |
| [investment-simplicity-principle](investment-simplicity-principle/SKILL.md) | 指导正确应用“简洁”原则，避免形式主义简化 | 用户试图简化策略但担心丢失关键信息 |
| [investment-method-simplification-prerequisites](investment-method-simplification-prerequisites/SKILL.md) | 明确简化投资方法前必须完成的系统性前提 | 计划精简模型或流程前的风险预防 |
| [contrarian-sector-allocation-in-zero-sum-markets](contrarian-sector-allocation-in-zero-sum-markets/SKILL.md) | 在存量博弈市场中基于公募配置数据逆向调仓 | 市场无增量资金且行业配置极端分化 |
| [analyze-internet-finance-vs-traditional-banking-disruption](analyze-internet-finance-vs-traditional-banking-disruption/SKILL.md) | 判断互联网金融能否颠覆传统银行 | 用户提出“颠覆性”命题需本质对比 |
| [survivorship-bias-risk-in-emerging-industry-investing](survivorship-bias-risk-in-emerging-industry-investing/SKILL.md) | 缓解追逐“下一个腾讯”带来的幸存者偏差风险 | 投资高市梦率新兴行业股票时 |
| [liu-gou-theory-value-price-model](liu-gou-theory-value-price-model/SKILL.md) | 运用遛狗理论判断价格偏离与回归耐心 | 股价显著偏离内在价值且具长期视角 |
| [industrial-investment-cash-flow-evaluation](industrial-investment-cash-flow-evaluation/SKILL.md) | 评估实业项目真实现金流回报与抗风险能力 | 分析电影、制造等前期投入大、回款慢项目 |
| [assess-unsustainable-high-growth-industries](assess-unsustainable-high-growth-industries/SKILL.md) | 判断新兴行业是否因低壁垒、高预期而增长不可持续 | 分析被热炒但缺乏实质护城河的行业 |
| [asset-pricing-as-monetary-phenomenon](asset-pricing-as-monetary-phenomenon/SKILL.md) | 判断多类资产同步波动是否由货币流动性驱动 | 无基本面原因但资产价格同涨同跌 |
| [evaluate-high-valuation-growth-stocks](evaluate-high-valuation-growth-stocks/SKILL.md) | 评估高估值成长股投资可行性与能力匹配度 | 考虑买入PE>50的成长股 |
| [xin-xing-yu-chuan-tong-hang-ye-tou-zi-fen-xi](xin-xing-yu-chuan-tong-hang-ye-tou-zi-fen-xi/SKILL.md) | 区分新兴与传统行业，确定应聚焦需求侧或供给侧 | 对新能源车、家电等行业进行投资评估 |
| [pharmaceutical-investment-structural-analysis](pharmaceutical-investment-structural-analysis/SKILL.md) | 分析中国医药行业结构性特征与医改影响 | 评估普药风险或医保控费下的个股机会 |
| [small-large-cap-relative-valuation-safety-margin](small-large-cap-relative-valuation-safety-margin/SKILL.md) | 小盘股相对大盘股估值溢价达历史极值时警示风险 | 市场弥漫“小盘成长神话”叙事 |
| [great-company-scarcity-and-valuation-discipline](great-company-scarcity-and-valuation-discipline/SKILL.md) | 评估A股“伟大公司”稀缺性并强制估值纪律 | 考虑高估值买入被标榜为“伟大公司”的股票 |
| [simplified-three-factor-stock-selection](simplified-three-factor-stock-selection/SKILL.md) | 系统筛选“便宜的好公司” | 基本面驱动的中长期选股 |
| [ordinary-company-valuation-discipline](ordinary-company-valuation-discipline/SKILL.md) | 对普通公司严格执行估值纪律 | 标的缺乏持久竞争优势或定价权 |
| [value-vs-growth-stock-earnings-season-effect](value-vs-growth-stock-earnings-season-effect/SKILL.md) | 季报期评估价值股与成长股短期相对表现 | 处于财报公布窗口期需交易决策 |
| [enterprise-valuation-multiples-ev-ebit-ev-ebitda](enterprise-valuation-multiples-ev-ebit-ev-ebitda/SKILL.md) | 使用EV/EBIT或EV/EBITDA评估制造业或高杠杆企业 | 市盈率失效但需聚焦真实盈利 |
| [自由现金流指标的跨国制造业适用性评估](自由现金流指标的跨国制造业适用性评估/SKILL.md) | 评估自由现金流在不同国家制造业中的适用性 | 分析资本开支高峰期的制造企业负FCF |
| [stock-market-bottom-signals-detection](stock-market-bottom-signals-detection/SKILL.md) | 识别市场可能见底的综合信号 | 判断是否处于历史底部区域 |
| [investment-analysis-three-pillars](investment-analysis-three-pillars/SKILL.md) | 用估值、品质、时机三要素跨市场分析股票 | 评估A股、港股、美股等长期投资价值 |
| [content-industry-investment-risk-and-valuation](content-industry-investment-risk-and-valuation/SKILL.md) | 评估内容型公司（电影、手游）依赖爆款的风险 | 收入高度集中于单部作品或短期爆款 |
| [government-intervention-competitive-dynamics](government-intervention-competitive-dynamics/SKILL.md) | 分析产业政策如何意外改变行业竞争格局 | 观察到补贴、准入限制等明确政策干预 |
| [differentiated-competition-six-signs-pricing-power](differentiated-competition-six-signs-pricing-power/SKILL.md) | 六维标志评估企业差异化与真实定价权 | 判断消费品、制造或服务企业护城河深度 |
| [investment-philosophy-and-knowledge-balance](investment-philosophy-and-knowledge-balance/SKILL.md) | 平衡投资理念（“线”）与具体知识（“珠子”） | 研究员或基金经理评估自身知识结构 |
| [identify-industry-competition-essence](identify-industry-competition-essence/SKILL.md) | 用“得_者得天下”框架提炼行业竞争本质 | 投资分析初期建立简洁行业认知 |
| [quality-enterprise-sourcing-and-sector-selection](quality-enterprise-sourcing-and-sector-selection/SKILL.md) | 优先评估行业赛道质量而非仅看管理层或政策 | 判断某行业是否具备孕育优质企业的土壤 |
| [stock-as-bond-inverse-thinking-model](stock-as-bond-inverse-thinking-model/SKILL.md) | 将股票视为无到期日债券，类比收益率评估回报 | 市场大幅波动、情绪极端化时逆向思考 |
| [value-investing-safety-margin-assessment](value-investing-safety-margin-assessment/SKILL.md) | 系统评估企业是否具备强安全边际 | 判断股票是否值得长期持有或具抗风险能力 |
| [value-investing-dual-definition-context](value-investing-dual-definition-context/SKILL.md) | 区分价值投资的广义（哲学）与狭义（风格）定义 | 出现概念混淆导致策略误判或归因错误 |
| [growth-trap-identification-and-classification](growth-trap-identification-and-classification/SKILL.md) | 识别高估值成长股九大成长陷阱类型 | 考虑买入高增长预期但估值过高的股票 |
| [mangger-career-choice-principles](mangger-career-choice-principles/SKILL.md) | 应用芒格三条择业原则评估职业选择 | 职场新人或转型者权衡理想与现实 |
| [区分先天投资能力与可学投资经验](区分先天投资能力与可学投资经验/SKILL.md) | 判断自身是否具备核心投资直觉与可习得技能 | 评估是否适合从事专业投资 |
| [主动权益持仓集中化优化](主动权益持仓集中化优化/SKILL.md) | 下跌市中收缩持股至10~15只高置信度标的 | 已持有多股且具备深度研究能力 |
| [识别高风险会计欺诈信号](识别高风险会计欺诈信号/SKILL.md) | CFO在泡沫期获财经媒体高度荣誉时预警欺诈风险 | 对高增长、高估值复杂业务公司做风控筛查 |
| [assess-fund-manager-commitment-using-just-right-wealth-rule](assess-fund-manager-commitment-using-just-right-wealth-rule/SKILL.md) | 用“刚刚好”身家法则评估基金经理投入度 | 筛选依赖个人明星制的对冲基金经理 |
| [a-share-policy-market-investment-strategy](a-share-policy-market-investment-strategy/SKILL.md) | 在A股识别政策底并制定相应策略 | 经济恶化但政策终将加码的预期阶段 |
| [价值与趋势投资者下跌市应对策略](价值与趋势投资者下跌市应对策略/SKILL.md) | 针对价值型或趋势型投资者提供下跌市操作建议 | 用户明确自身风格且市场处于调整期 |
| [识别被迫抛售型市场底部](识别被迫抛售型市场底部/SKILL.md) | 识别由清盘、赎回等非基本面因素引发的急抛底部 | 观察到多重被迫卖出信号同时出现 |
| [comparative-advantage-based-long-term-stock-selection](comparative-advantage-based-long-term-stock-selection/SKILL.md) | 基于国家比较优势识别长期牛股行业 | 分析某国哪些行业具备长期投资价值 |
| [investment-predictability-hierarchy](investment-predictability-hierarchy/SKILL.md) | 区分“会发生什么”与“何时发生”，优先聚焦内容 | 不确定应关注事件本身还是其发生时点 |
| [识别对冲基金核心特征](识别对冲基金核心特征/SKILL.md) | 判断产品是否具备业绩提成与高净值准入两大特征 | 验证另类产品是否属于对冲基金范畴 |
| [对冲基金策略与市场环境适配分析](对冲基金策略与市场环境适配分析/SKILL.md) | 分析各类对冲策略在不同市场环境下的有效性 | 评估对冲基金行业结构或主导策略 |
| [industry-allocation-deviation-alignment](industry-allocation-deviation-alignment/SKILL.md) | 根据行业研究把握程度决定配置偏离幅度 | 投资经理制定行业超配/低配决策 |
| [hedge-fund-essence-and-classification](hedge-fund-essence-and-classification/SKILL.md) | 避免将对冲基金视为统一类别，强调个体化判断 | 开展尽职调查或理解基金独特属性 |
| [analyze-china-hedge-fund-growth-drivers](analyze-china-hedge-fund-growth-drivers/SKILL.md) | 评估中国对冲基金三大增长驱动力 | 制定产品设计、募资或监管沟通策略 |
| [deleveraging-strategy-balancing](deleveraging-strategy-balancing/SKILL.md) | 协调三种去杠杆方式以实现温和复苏 | 经济体面临高杠杆需平衡通胀与通缩 |
| [industry-holding-strategy-and-valuation-timing](industry-holding-strategy-and-valuation-timing/SKILL.md) | 基于行业特性制定长期持有或波段操作策略 | 为成熟行业制定系统性投资策略 |
| [four-cycle-leading-lagging-relationship](four-cycle-leading-lagging-relationship/SKILL.md) | 利用政策、市场、经济、盈利四周期领先滞后关系判断拐点 | 熊市末期或牛市初期判断市场转折 |
| [three-leverage-sector-rotation](three-leverage-sector-rotation/SKILL.md) | 牛市初期按财务、运营、估值杠杆三阶段轮动板块 | 市场转向牛市且有明确复苏信号 |
| [brand-intrinsic-value-assessment](brand-intrinsic-value-assessment/SKILL.md) | 评估消费品牌美誉度、客户生命周期与社会展示性 | 筛选服装、啤酒等品类中具定价权的品牌 |
| [assess-urbanization-investment-sustainability](assess-urbanization-investment-sustainability/SKILL.md) | 评估中国城镇化剩余空间对基建与地产的支撑力 | 判断相关投资是否具备长期可持续性 |
| [gongmu-jijin-rencai-ji-zhi-gai-ge](gongmu-jijin-rencai-ji-zhi-gai-ge/SKILL.md) | 公募基金人才激励机制改革方案 | 基金公司面临人才流失需提升团队稳定性 |
| [商业图书高效阅读四原则](商业图书高效阅读四原则/SKILL.md) | 应用二八原则等四大原则高效阅读商业书籍 | 用户希望提升商业阅读效率与核心价值提取 |
| [商业阅读习惯四步训练法](商业阅读习惯四步训练法/SKILL.md) | 四步训练法将阅读能力转化为稳定思辨习惯 | 用户愿投入6个月以上持续训练 |
| [porter-national-competitive-advantage-four-stage-model](porter-national-competitive-advantage-four-stage-model/SKILL.md) | 用波特四阶段模型判断国家发展阶段 | 分析主权国家或省级区域经济定位 |
| [national-competitiveness-industry-selection-and-oligarch-cultivation](national-competitiveness-industry-selection-and-oligarch-cultivation/SKILL.md) | 在投资导向向创新驱动转型期培育本土寡头 | 政策制定者或投资者制定产业战略 |
| [reading-cost-composition-analysis](reading-cost-composition-analysis/SKILL.md) | 量化读者阅读特定图书的总时间成本 | 评估阅读ROI或优化出版选题策略 |
| [internet-emerging-industry-valuation](internet-emerging-industry-valuation/SKILL.md) | 判断未盈利互联网/高新企业是否值得高估值 | 投资标的属创业板新兴企业且无稳定盈利 |
| [hedge-strategy-risk-identification-and-application](hedge-strategy-risk-identification-and-application/SKILL.md) | 识别对冲策略风险，设计多维中性组合 | 需分离选股Alpha与市场Beta |
| [识别与克服锚固偏见](识别与克服锚固偏见/SKILL.md) | 帮助用户摆脱以历史价格为锚的决策偏差 | 投资或消费中以买入价/近期高低点为依据 |
| [仓位思维与确认偏误识别](仓位思维与确认偏误识别/SKILL.md) | 纠正因重仓而产生的确认偏误 | 用户重仓某股且选择性接受利好/利空信息 |
| [lukhui-coupon-usage-rules](lukhui-coupon-usage-rules/SKILL.md) | 验证庐客汇150元优惠券使用条件 | 用户提交入汇订单并尝试使用该券 |
| [luke-hui-membership-onboarding-and-benefits](luke-hui-membership-onboarding-and-benefits/SKILL.md) | 指导完成庐客汇会员入会与权益激活 | 用户表达“希望成为正式会员”或询问加入方式 |
| [evaluate-extended-reading-book-authority](evaluate-extended-reading-book-authority/SKILL.md) | 判定“延伸阅读”图书是否具专业权威性 | 评估《当音乐停止之后》等书是否适合作政策参考 |

## Quick Navigation

### 价值投资核心框架
- **investment-decision-three-pillars**: 用估值、品质、时机三支柱系统评估股票
- **value-investing-safety-margin-assessment**: 系统评估安全边际强度
- **ordinary-company-valuation-discipline**: 对普通公司严格执行估值纪律

### 逆向投资与市场周期
- **contrarian-opportunity-identification**: 识别共识恐惧与显性价值共存的机会
- **market-emotion-and-cycle-awareness**: 诊断市场情绪阶段以把握逆向时点
- **stock-market-bottom-signals-detection**: 综合识别市场可能见底信号

### 行业与公司分析
- **company-quality-assessment-framework**: 判断企业是否为“好生意”
- **industry-structure-and-leadership-strategy**: 聚焦寡头化行业的龙头企业
- **differentiated-competition-six-signs-pricing-power**: 六维度评估企业定价权

### 行为偏差与决策纠偏
- **识别与克服锚固偏见**: 摆脱历史价格锚定影响
- **仓位思维与确认偏误识别**: 纠正重仓导致的选择性信息接受
- **avoid-market-timing-and-hindsight-bias**: 规避择时无效性与后视镜效应

### 对冲基金与另类投资
- **assess-chinese-hedge-fund-limitations**: 评估中国对冲基金真实能力
- **识别对冲基金核心特征**: 验证产品是否符合对冲基金本质
- **hedge-strategy-risk-identification-and-application**: 设计有效对冲组合

### 阅读与学习方法
- **商业图书高效阅读四原则**: 提升商业阅读效率的核心原则
- **商业阅读习惯四步训练法**: 将阅读转化为思辨能力的训练体系

## How to Use
当您提出具体投资、分析或决策问题时，我会自动匹配最相关的技能。您也可直接引用技能名称（如“请使用 contrarian-investment-core-principles”）来触发特定分析框架。所有技能均基于《7Ddabeb1-C58F-4740-Bf83-1Accebbdd866》一书的专业方法论，适用于长期、理性、基本面驱动的投资实践。
```