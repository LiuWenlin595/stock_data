---
name: Industry Structure and Leadership Strategy
description: Identifies industries with favorable competitive dynamics (oligopoly, rising concentration) and guides investment toward established leaders. Use when screening sectors for long-term equity exposure, especially in manufacturing and consumer goods.
---

# 行业结构与龙头策略

## 何时使用
- 分析制造业子行业（如家电、汽配、工程机械）
- 观察到行业集中度持续提升（CR3/CR5上升）
- 行业处于“百舸争流”向“战国七雄”演化阶段
- 需区分“数月亮”（寡头清晰）与“数星星”（参与者众多）行业

## 执行步骤
1. **判断行业集中度**：
   - 高集中度（CR3 > 50%）且利润持续超预期 → 优先配置
   - 低集中度、恶性竞争 → 回避

2. **识别格局演化阶段**：
   - “高小新”混战期：暂缓下注
   - “战国七雄”稳定期：买入最强龙头（如腾讯、格力）

3. **聚焦“月亮型”行业**：
   - 最佳：月朗星稀（一家独大）
   - 次优：一超多强、两分天下、三足鼎立
   - 最差：百花齐放（充分竞争）

4. **验证龙头优势**：
   - 在细分子行业或区域市场形成局部寡头（如高端白酒、区域啤酒）
   - 利润率显著高于同行（如优势省份啤酒净利率 >15% vs <1.5%）

5. **执行“胜而后求战”**：只投资已击败对手、优势明显的公司，不猜测未来赢家。

> 历史验证：空调行业2006年后格局优化，龙头利润翻10–15倍，股价涨十倍以上。