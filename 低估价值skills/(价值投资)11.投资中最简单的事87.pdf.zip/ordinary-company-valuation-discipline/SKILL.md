---
name: Ordinary Company Valuation Discipline
description: Apply strict valuation discipline when evaluating ordinary (non-great) listed companies in the A-share market. Use this skill when a stock is identified as lacking durable competitive advantages, has unproven growth, and its current price implies overly optimistic future expectations—especially during concept-driven market phases.
---

# Ordinary Company Valuation Discipline

## When to Use
Use this skill **only** when all of the following conditions are met:
- The company has been classified as “ordinary” (i.e., not great): lacks persistent competitive advantage, holds average industry position, and shows unverified or inconsistent growth.
- Reliable current financial data exists (e.g., verified earnings, cash flow, or asset values).
- The current stock price implies high growth expectations that are unlikely to materialize.
- You are operating in the A-share market context, where “pseudo-growth” stocks and concept-driven speculation are common.

Do **not** use this skill for:
- Companies with proven long-term high growth and economic moats (“great companies”).
- Pure speculative concepts with no fundamental backing.

## How to Execute

1. **Confirm company quality**: Verify the company is ordinary—most A-share “growth” stocks eventually reveal themselves as pseudo-growth.

2. **Anchor to tangible fundamentals**: Ignore management’s optimistic forecasts. Base your valuation solely on observable metrics: current earnings, free cash flow, or net assets.

3. **Demand a significant margin of safety**: Only consider buying if the price is substantially below intrinsic value—ideally at or below 50% of conservatively estimated intrinsic value.

4. **Assess implied growth expectations**: Reverse-engineer the market’s growth assumption from the current valuation (e.g., via P/E or P/B). If actual achievable growth is likely lower than this implied rate, avoid the stock regardless of nominal growth.

5. **Exploit market inefficiencies in A-shares**: During periods when cheap, fundamentally sound ordinary stocks are neglected (e.g., 2013-style concept bubbles), treat this as an opportunity to deploy capital selectively.

## Output
Decide whether to **buy**, **hold**, or **avoid** the stock based strictly on valuation relative to current fundamentals—not future promises.