---
name: Contrarian Investment Core Principles
description: Applies when market sentiment is extremely pessimistic or optimistic and assets are mispriced due to emotional overreaction. Use this skill to identify opportunities where "others avoid" but fundamentals remain sound, especially in A-share markets.
---

# 逆向投资核心原则

## 何时使用
- 市场普遍回避某类资产且价格处于历史低位
- 主流观点高度一致（极度看多或看空）
- 出现“人弃我取”或“抱团取暖”的极端情绪信号
- 资产被错杀但基本面未发生根本恶化

## 执行步骤
1. **识别被忽视或抛售的资产**：关注成交量萎缩、媒体负面密集、机构低配至历史极值的板块。
2. **验证基本面稳健性**：确认下跌原因源于情绪而非实质问题（如商业模式崩溃、行业消亡）。
3. **判断市场阶段**：仅在趋势初期（悲观但有改善迹象）或末期（狂热但风险积聚）适用，中期趋势不宜盲目逆向。
4. **评估一致性预期风险**：若基金超配/低配达十年之最，警惕错误定价。
5. **执行买入操作**：在“没人买的时候”布局，接受无法精准捕捉底点，理解底部是“区域”而非“点位”。
6. **坚守心理素质**：能承受短期浮亏，坚持到趋势反转。

> 核心逻辑：市场过度反应常导致优质资产被错误定价，此时介入可获得长期超额回报。