---
name: Contrarian Investment Risk Screening
description: Screens potential contrarian investments using multi-layered risk filters to avoid value traps and reflexive collapse. Use when considering buying into sharp declines caused by crises, scandals, or market panic.
---

# 逆向投资风险筛查

## 何时使用
- 股票因突发事件（如食品安全）大幅下跌
- 市场情绪极度悲观，出现“放弃”“麻木”等底部信号
- 考虑“越跌越买”策略
- 需区分价格波动风险与本金永久性丧失风险

## 执行步骤
1. **应用三重判断准则**：
   - 估值是否足够低（已计入最悲观情景）？
   - 问题是否短期、可解决（非结构性衰退）？
   - 是否存在反身性风险（股价下跌→基本面恶化）？

2. **执行六维危机评估**（针对突发事件）：
   - 有无替代品？
   - 是个股还是行业问题？
   - 违规是主动添加还是被动中枪？
   - 问题是否容易解决？
   - 企业根基是否扎实？
   - 是否有突出受害者个案？

3. **识别价值陷阱类型**：
   - 技术淘汰（如柯达）
   - 赢家通吃中的小公司
   - 分散重资产夕阳行业
   - 景气顶点周期股
   - 会计欺诈

4. **验证反身性**：
   - 金融股（如投行）通常具反身性，不可越跌越买
   - 实业股（如可口可乐）无反身性，可越跌越买

5. **区分两类风险**：
   - 价格波动风险：短期下跌，但基本面完好 → 可承担
   - 本金永久性丧失风险：基本面恶化 → 必须规避

> 决策规则：仅当所有风险筛查通过，方可实施逆向投资。