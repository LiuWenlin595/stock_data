---
name: Verify Zhanchu Award-Winning Books (2008–2013)
description: Use this skill when a user asks whether a Zhanchu Culture book published between 2008 and 2013 is part of the official award-winning catalog. Only apply if the book title and publication year are known, and the user seeks validation against recognized awards or media lists.
---

# Verify Zhanchu Award-Winning Books (2008–2013)

## When to Use
Apply this skill **only** when:
- The book was **published by Zhanchu Culture between 2008 and 2013**.
- The user wants to know if it received **official recognition** from authoritative institutions or media during that period.
- The book’s **exact title and edition** are specified (e.g., distinguish between classic and textbook versions).

## How to Execute
Follow this decision process:

1. **Confirm publication window**: Verify the book was published by Zhanchu Culture **between 2008 and 2013**.
2. **Check award eligibility**: Determine if the book received recognition from **at least one** of the following:
   - **National Library “Wenjin Award”** (4th or 9th edition, top 10)
   - **CCTV “China Good Book”** annual winner
   - Annual lists from major media: *Guangming Daily*, *China Press and Publishing Journal*, *The Beijing News*, *China Education Newspaper*
   - Industry media: *Yicai Daily*, *Business Value*, *Chuangyejia*, *China Entrepreneur*
   - E-commerce/platform rankings: Amazon, JD.com, Baodao Network, Lantai·Tencent Literature (annual bestsellers or category leaders)
   - **International awards**: Pulitzer Biography Prize, U.S. National Book Award, *Financial Times*/Goldman Sachs Best Business Book
   - **Specialized awards**: Sina “Parenting Wisdom” Annual Forum, *Psychology Monthly* Book of the Year
3. **Validate edition specificity**: Treat different editions (e.g., *Influence*: classic vs. textbook) as **separate entries**—awards apply only to the specific version listed.
4. **Return result**: If **any** qualifying recognition is confirmed, classify the book as part of the **“Zhanchu Culture 2008–2013 Award-Winning Catalog.”**

> **Note**: Books not explicitly listed in any of the above sources—even if popular—are **not** considered award-winning under this rule.