---
name: Investment Decision Three Pillars
description: Provides a structured framework to evaluate any stock through valuation, quality, and timing lenses. Use before making any long-term equity purchase to ensure disciplined, repeatable analysis.
---

# 投资决策三大支柱

## 何时使用
- 准备买入一只股票前
- 需系统筛选A股长期标的
- 面临方法论选择（价值vs成长vs GARP）
- 被个别成功案例诱惑时需回归统计规律

## 执行步骤
1. **回答三个基本问题**：
   - **估值**：为什么认为便宜？（PE/PB/PS/EV-EBITDA）
   - **品质**：为什么认为好？（护城河、商业模式、管理层）
   - **时机**：为什么要现在买？（情绪、周期、政策）

2. **应用三板斧分析**：
   - **波特五力**：判断是否“好行业”（议价权、进入壁垒、竞争格局）
   - **杜邦分析**：判断是否“好公司”（高利润/高周转/高杠杆模式）
   - **估值三维比较**：同业横比、历史纵比、市值vs成长空间

3. **执行层级过滤**：
   - 排除“看不懂的公司”
   - 排除“估不准的股票”
   - 排除“被高估的”
   - 排除“烂公司”
   - 排除“合理价位的平庸公司”

4. **坚持方法论纪律**：
   - 正确方法不需要每年都有效
   - 警惕“以短期结果倒推过程正确”
   - 区分“规律”（可重复）与“个例”（不可复制）

> 输出要求：仅当三大支柱均有合理答案，且通过层级过滤，方可执行买入。