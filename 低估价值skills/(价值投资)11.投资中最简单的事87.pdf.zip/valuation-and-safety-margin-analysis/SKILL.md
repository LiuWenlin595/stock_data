---
name: Valuation and Safety Margin Analysis
description: Determines whether an asset is truly "cheap" by comparing price to intrinsic value and assessing downside protection. Use when evaluating entry points for long-term holdings, especially in A-share markets with volatile valuations.
---

# 估值与安全边际分析

## 何时使用
- 市场整体或个股估值显著低于历史均值（如PE从50倍降至10倍）
- 需区分价值投资（P₀ << V₀）与成长投资（P₀ < V₀ << Vₙ）
- 面临“便宜的好公司”vs“昂贵的好公司”选择困境
- 股价长期横盘但估值已处低位

## 执行步骤
1. **计算核心估值指标**：
   - PE（市盈率）、E/P（盈利收益率 = 1/PE）
   - 股息率 vs 无风险利率（如银行存款）

2. **判断安全边际等级**：
   - 高：PE ≤10 且股息率 ≥ 存款利率
   - 中：PE 10–20
   - 低：PE >30

3. **应用四象限框架**：
   - 优先选择“便宜的好公司”
   - 警惕“昂贵的烂公司”（高估值+基本面差）
   - 若判断力有限，宁可错过“昂贵的好公司”

4. **理解“便宜是硬道理”**：
   - 即使普通公司，只要足够便宜，长期回报仍可观
   - 但必须结合品质，避免价值陷阱

5. **承认估值局限性**：在成长行业（医药、科技），传统指标可能失真，需重新定义“便宜”。

> 核心信念：“你只要买得便宜，就可以卖得便宜”——低价买入降低对“接盘傻瓜”的依赖。