```markdown
# 价值投资技能集 (Value Investing Skills)

本技能集源自专业投资著作，涵盖价值投资的核心方法论与实战工具。从资产估值、盈利能力分析到护城河评估，帮助用户系统性地识别低估标的、评估企业内在价值，并建立长期稳健的投资决策框架。

## Available Skills

| Skill | Description | Use When |
|-------|-------------|----------|
| [value-investing-core-principles](value-investing-core-principles/SKILL.md) | 建立价值投资框架，区分价值投资与成长投资、指数投资、技术分析的差异，应用安全边际、市场先生、能力圈等核心原则 | 需要建立投资哲学、评估策略有效性、识别市场错误定价或区分投资与投机时 |
| [value-investment-core-framework](value-investment-core-framework/SKILL.md) | 提供价值投资的核心原则、风险评估方法和资产分类框架 | 执行投资决策、评估投资风险和进行资产配置时 |
| [circle-of-competence-principle](circle-of-competence-principle/SKILL.md) | 帮助投资者识别并坚守自身能力圈，避免盲目追逐市场热点 | 面对投资机会（特别是热点领域）时进行自我约束和风险控制 |
| [long-term-investment-philosophy](long-term-investment-philosophy/SKILL.md) | 建立长期投资思维、识别基业长青企业并决定持有策略 | 制定长期投资策略、选择标的或面对市场波动时 |
| [quality-business-investment-principle](quality-business-investment-principle/SKILL.md) | 在极低价格收购平庸企业与合理价格收购优质企业之间做出正确选择 | 需要区分"烟屁股"投资法与优质企业投资原则时 |
| [asset-based-valuation](asset-based-valuation/SKILL.md) | 通过资产负债表评估企业价值，提供账面价值、净营运资本和再生产成本三种方法 | 盈利不可靠、企业处于困境、需要计算安全边际底线或评估进入壁垒时 |
| [earnings-power-valuation](earnings-power-valuation/SKILL.md) | 基于当前可持续盈利能力计算企业价值（EPV），将调整后的盈利资本化为永续年金价值 | 资产基础估值过于保守、企业具备稳定盈利但低资产价值、需要避免增长预测或评估周期性企业时 |
| [earnings-power-value-valuation](earnings-power-value-valuation/SKILL.md) | 基于可持续盈利评估公司价值，将未来盈利流量转换为现值存量 | 企业估值、盈利能力价值评估和格雷厄姆-多德估值方法应用 |
| [greenwald-comprehensive-valuation](greenwald-comprehensive-valuation/SKILL.md) | 执行格林沃尔德三要素估值法（资产价值+盈利能力价值+成长价值） | 需要全面评估且区分价值来源、分析竞争优势对价值的影响、判断成长是否创造价值时 |
| [dcf-valuation-methods](dcf-valuation-methods/SKILL.md) | 使用现金流折现法评估资产内在价值，涵盖基础现值计算到复杂终值模型 | 成长型企业估值、资产/盈利法不足、计算未来现金流现值、评估投资项目可行性时 |
| [growth-stock-dcf-valuation](growth-stock-dcf-valuation/SKILL.md) | 对成长股进行简化DCF估值并进行敏感性分析，评估增长率不确定性对估值的影响 | 评估成长股内在价值、面临增长率不确定性的场景 |
| [franchise-growth-stock-valuation](franchise-growth-stock-valuation/SKILL.md) | 评估具有经济特许权的成长股投资价值的估值方法体系 | 市场价值显著高于内在价值的成长股、面临技术变革与竞争威胁的行业龙头、对增长率和资本成本变化敏感的企业 |
| [economic-moat-assessment](economic-moat-assessment/SKILL.md) | 评估企业经济护城河强度和可持续性的综合框架 | 服务业企业、软件公司、科技公司、技术硬件企业以及需要识别伟大企业的投资决策 |
| [competitive-advantage-sustainability](competitive-advantage-sustainability/SKILL.md) | 评估规模优势的防御机制和可持续性条件 | 已建立规模优势的在位企业、市场领导者进行竞争优势分析 |
| [high-tech-industry-competition](high-tech-industry-competition/SKILL.md) | 分析高科技行业竞争演化规律、护城河侵蚀机制以及不同业务模式的本质差异 | 高科技产业、新兴产业、半导体行业、存储芯片市场、微处理器业务 |
| [liquidation-valuation-cases](liquidation-valuation-cases/SKILL.md) | 计算企业清算价值，涵盖有序清算、立即清算、房地产合资企业和控股母公司场景 | "关掉公司比维持经营更划算"、盈利能力价值低于零或评估待清算资产时 |
| [intangible-asset-valuation](intangible-asset-valuation/SKILL.md) | 调整服务业和无形资产密集型企业的估值，将研发、广告等支出重新分类为投资 | 服务业企业、拥有大量无形资产的企业、研发密集型企业 |
| [reproduction-cost-adjustments](reproduction-cost-adjustments/SKILL.md) | 调整会计报表以反映资产真实再生产成本 | 使用再生产成本法估值、需要资本化无形资产、评估进入壁垒或计算知识资产价值时 |
| [capital-cost-estimation](capital-cost-estimation/SKILL.md) | 估算加权平均资本成本(WACC)，包括高杠杆企业的保守债务比例方法 | 高杠杆企业、资本结构分析、WACC计算及非高杠杆成熟企业 |
| [return-rate-adjustment](return-rate-adjustment/SKILL.md) | 基于内在价值比率调整回报率估算，验证估值合理性并做出投资判断 | 股票估值、价值投资标的，当估算回报率低于资本成本或需要验证估值合理性时 |
| [enterprise-value-assessment](enterprise-value-assessment/SKILL.md) | 通过比较总回报率与资本成本评估企业估值状态 | 综合现金回报、有机增长和资本成本进行最终投资决策、计算安全边际或评估特许权衰减风险时 |
| [cash-return-valuation](cash-return-valuation/SKILL.md) | 使用现金回报率评估股票估值水平，与历史数据进行比较分析 | 股票估值、投资回报率分析、价值投资决策 |
| [growth-value-analysis](growth-value-analysis/SKILL.md) | 评估增长是否创造股东价值，判断再投资质量、评估收购价值创造或计算成长净现值 | ROIC与资本成本关系不明确、需要判断再投资质量、评估收购价值创造时 |
| [value-creation-reinvestment](value-creation-reinvestment/SKILL.md) | 估算价值创造因子，应用再投资理论模型评估积极再投资的回报 | 企业投资、资本配置、再投资回报分析 |
| [value-creation-factor-assessment](value-creation-factor-assessment/SKILL.md) | 评估积极投资是否创造价值、计算并购或再投资的价值创造因子(v) | 企业整体并购、独立项目开业、资本预算项目以及核心经济特许权业务利润再投资评估 |
| [economic-franchise-reinvestment-return-analysis](economic-franchise-reinvestment-return-analysis/SKILL.md) | 分析核心经济特许权再投资回报的三组成部分（现金回报、有机增长价值、二次再投资价值） | 评估源于核心经济特许权的积极再投资项目，传统现金流折现法因远期权重过高而不精确时 |
| [corporate-active-investment-evaluation](corporate-active-investment-evaluation/SKILL.md) | 评估企业留存收益用于积极投资（如非核心业务收购）对股东价值创造的影响 | 企业并购投资决策、非核心业务扩张评估和资本配置策略分析 |
| [acquisition-and-investment-returns](acquisition-and-investment-returns/SKILL.md) | 评估具体投资项目和收购的回报率，估算有机增长贡献或分析积极再投资效果 | 评估管理层资本配置决策、收购项目ROI、估算有机增长贡献时 |
| [retained-earnings-value-test](retained-earnings-value-test/SKILL.md) | 执行一美元留存收益测试，评估管理层留存收益资本配置能力 | 企业产生盈利并面临是否分红决策，或需要评估管理层资本配置质量时 |
| [organic-growth-profit-allocation](organic-growth-profit-allocation/SKILL.md) | 计算支持有机增长所需的营运资本投资，分析盈利分配模式，评估股东总回报 | 轻资产运营企业、外包制造和分销业务的公司、低资本密集度企业 |
| [capital-structure-policy](capital-structure-policy/SKILL.md) | 优化资本结构和财务资源配置，制定分红政策、融资决策或现金分配 | 企业持有闲置资金、需要决定债务vs股权融资、评估财务困境风险或处理收购融资时 |
| [strategic-business-exit-and-resource-reallocation](strategic-business-exit-and-resource-reallocation/SKILL.md) | 指导企业进行战略性业务退出决策和资源重新配置 | 多元化企业、业务组合管理、战略转型场景，当主业遭遇不可逆竞争劣势且存在高增长替代业务时 |
| [centralized-risk-management](centralized-risk-management/SKILL.md) | 为多经理投资结构提供集中式风险管理框架，包括净指令执行、整体对冲和仓位限制 | 家族办公室、财富管理机构、多经理投资组合的风险管理 |
| [portfolio-diversification-strategy](portfolio-diversification-strategy/SKILL.md) | 提供投资组合分散化的具体规则和实施方法，旨在降低非系统性风险 | 投资组合构建、证券选择时使用 |
| [concentrated-investment-methodologies](concentrated-investment-methodologies/SKILL.md) | 提供多种集中投资策略的具体实施方法，包括格林伯格、扬·胡梅尔和迈克尔·普赖斯的选股流程和仓位管理 | 投资组合管理、价值投资策略执行时使用 |
| [deep-value-trading-management](deep-value-trading-management/SKILL.md) | 执行施洛斯式价值投资持仓管理，包括横向比较换仓、分批建仓和获利了结 | 管理廉价股投资组合、执行横向比较换仓、在股价下跌中分批建仓或决定获利了结时 |
| [quantitative-value-strategies](quantitative-value-strategies/SKILL.md) | 基于估值指标的量化选股策略，快速识别低估股票、执行格雷厄姆式分散投资 | 构建系统性投资组合或机械式筛选、结合估值与成长指标或实施长期反转策略时 |
| [private-market-value-strategy](private-market-value-strategy/SKILL.md) | 基于非公开市场价值(PMV)和催化剂事件的投资策略，寻找价值收敛机会 | 具有可拆分业务单元或资产的上市公司、存在活跃产业交易先例的行业 |
| [institutional-market-cap-constraints](institutional-market-cap-constraints/SKILL.md) | 分析机构投资者因市值规模限制导致的小盘股系统性折价现象，识别投资机会 | 评估小市值公司股票（市值低于10亿美元）、分拆上市新公司、市值低于机构阈值的公司的投资价值 |
| [active-intervention-investment](active-intervention-investment/SKILL.md) | 指导积极干预型投资者通过参与公司治理和运营管理创造价值 | 积极干预型投资者、投资机构、目标公司董事会 |
| [investment-signal-analysis](investment-signal-analysis/SKILL.md) | 分析股东身份、交易行为以及企业融资决策所传递的投资信号 | 验证投资判断、识别管理层动机、评估股权融资的负面信号强度，以及通过内部人交易和著名投资者持仓获取增量信息 |
| [behavioral-finance-biases](behavioral-finance-biases/SKILL.md) | 识别和分析损失厌恶、过度自信等认知偏差对市场定价的影响 | 所有投资决策、存在不确定性的估值场景、周期性市场波动分析 |
| [behavioral-value-anomaly-analysis](behavioral-value-anomaly-analysis/SKILL.md) | 分析价值溢价来源、理解魅力股高估机制或评估机构行为对定价的影响 | 分析彩票偏好导致的魅力股高估、机构橱窗装饰行为和职业风险对价值异象的强化 |
| [investment-research-methodology](investment-research-methodology/SKILL.md) | 构建聚焦关键假设的研究策略，验证估值假设、收集间接信息 | 初步估值后的深度尽职调查、验证估值假设、避免无效研究或设计针对特定投资机会的研究计划时 |
| [berkshire-intrinsic-value](berkshire-intrinsic-value/SKILL.md) | 评估伯克希尔式企业的内在价值，包括投资组合价值、非保险业务盈利和留存收益使用效率 | 企业估值、投资组合分析 |
| [tax-impact-adjustment](tax-impact-adjustment/SKILL.md) | 调整一次性税务影响，剔除税改、资产出售等非经常性项目对财务预测的扭曲 | 税务会计、财务预测、企业估值 |
| [translator-credibility-evaluation](translator-credibility-evaluation/SKILL.md) | 评估投资类书籍译者的专业背景、学术资质和翻译经验，以判断译文的权威性和可靠性 | 需要验证翻译质量、了解译者专业领域或评估投资文献可信度的场景 |
| [image-loss-handling](image-loss-handling/SKILL.md) | 当图片文件丢失、损坏或文档中的图片引用失效时提供完整处理流程 | 图片文件丢失、损坏或文档中的图片引用失效时 |

## Quick Navigation

### 投资哲学与原则
- **[value-investing-core-principles]**: 建立价值投资核心框架，应用安全边际、市场先生、能力圈等原则
- **[value-investment-core-framework]**: 提供价值投资核心原则、风险评估方法和资产分类框架
- **[circle-of-competence-principle]**: 识别并坚守能力圈，避免盲目追逐市场热点
- **[long-term-investment-philosophy]**: 建立长期投资思维，识别基业长青企业
- **[quality-business-investment-principle]**: 在廉价平庸企业与合理价格优质企业间做出正确选择

### 估值方法论
- **[asset-based-valuation]**: 基于资产负债表的资产估值法（账面价值/净营运资本/再生产成本）
- **[earnings-power-valuation]**: 基于可持续盈利能力的EPV估值法
- **[earnings-power-value-valuation]**: 将未来盈利流量转换为现值存量的EPV计算
- **[greenwald-comprehensive-valuation]**: 格林沃尔德三要素估值法（AV+EPV+成长价值）
- **[dcf-valuation-methods]**: 现金流折现法，涵盖基础现值到复杂终值模型
- **[growth-stock-dcf-valuation]**: 成长股简化DCF估值与敏感性分析
- **[franchise-growth-stock-valuation]**: 经济特许权成长股的估值方法体系

### 竞争优势分析
- **[economic-moat-assessment]**: 评估企业经济护城河强度和可持续性
- **[competitive-advantage-sustainability]**: 评估规模优势的防御机制和可持续性条件
- **[high-tech-industry-competition]**: 高科技行业竞争演化规律与护城河侵蚀机制

### 特殊场景估值
- **[liquidation-valuation-cases]**: 企业清算价值计算（有序/立即/合资/控股场景）
- **[intangible-asset-valuation]**: 服务业和无形资产密集型企业估值调整
- **[reproduction-cost-adjustments]**: 资产真实再生产成本调整与资本化
- **[capital-cost-estimation]**: WACC估算，含高杠杆企业保守方法

### 投资回报分析
- **[return-rate-adjustment]**: 基于内在价值比率调整回报率估算
- **[enterprise-value-assessment]**: 比较总回报率与资本成本评估估值状态
- **[growth-value-analysis]**: 评估增长是否创造股东价值
- **[value-creation-reinvestment]**: 估算价值创造因子，评估积极再投资回报
- **[value-creation-factor-assessment]**: 计算并购或再投资的价值创造因子(v)
- **[economic-franchise-reinvestment-return-analysis]**: 核心特许权再投资回报三要素分析
- **[cash-return-valuation]**: 现金回报率评估与历史比较分析

### 资本配置与战略
- **[corporate-active-investment-evaluation]**: 评估积极投资对股东价值创造的影响
- **[acquisition-and-investment-returns]**: 具体投资项目和收购的回报率评估
- **[retained-earnings-value-test]**: 一美元留存收益测试，评估资本配置能力
- **[organic-growth-profit-allocation]**: 有机增长所需营运资本投资与盈利分配分析
- **[capital-structure-policy]**: 优化资本结构和财务资源配置
- **[strategic-business-exit-and-resource-reallocation]**: 战略性业务退出与资源重新配置

### 投资组合管理
- **[centralized-risk-management]**: 多经理投资结构的集中式风险管理框架
- **[portfolio-diversification-strategy]**: 投资组合分散化规则与实施方法
- **[concentrated-investment-methodologies]**: 格林伯格、胡梅尔、普赖斯等集中投资策略
- **[deep-value-trading-management]**: 施洛斯式廉价股投资组合持仓管理
- **[quantitative-value-strategies]**: 基于估值指标的量化选股策略

### 特殊投资策略
- **[private-market-value-strategy]**: 基于非公开市场价值(PMV)和催化剂事件的投资策略
- **[institutional-market-cap-constraints]**: 小盘股系统性折价现象分析与投资机会识别
- **[active-intervention-investment]**: 积极干预型投资者通过公司治理创造价值

### 市场信号与行为金融
- **[investment-signal-analysis]**: 股东身份、交易行为及融资决策的投资信号分析
- **[behavioral-finance-biases]**: 认知偏差对市场定价影响的识别与分析
- **[behavioral-value-anomaly-analysis]**: 价值溢价来源与魅力股高估机制分析

### 研究方法与工具
- **[investment-research-methodology]**: 聚焦关键假设的研究策略构建
- **[berkshire-intrinsic-value]**: 伯克希尔式企业内在价值评估
- **[tax-impact-adjustment]**: 一次性税务影响的调整与剔除
- **[translator-credibility-evaluation]**: 投资类书籍译者可信度评估
- **[image-loss-handling]**: 图片丢失/损坏的处理流程

## How to Use

1. **确定任务类型**: 首先明确您需要解决的投资问题属于哪个领域（估值、竞争优势、投资组合管理等）

2. **查阅技能列表**: 在"Available Skills"表格中查找相关技能，或直接在"Quick Navigation"中按类别浏览

3. **匹配使用场景**: 参考"Use When"列确定该技能是否适用于您的具体场景

4. **调用技能**: 通过引用技能路径 `[skill-name](skill-name/SKILL.md)` 访问完整技能文档，按照步骤执行分析

5. **组合使用**: 复杂分析可能需要多个技能配合，例如先使用 `economic-moat-assessment` 评估护城河，再使用 `greenwald-comprehensive-valuation` 进行全面估值
```