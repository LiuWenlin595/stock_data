---
name: True Achievement Evaluation
description: 评估个人或他人人生成就是否具有持久社会价值的核心标准。当用户反思自身或他人的学术、思想或事业贡献是否真正“有意义”时使用，尤其适用于学者、企业家、公共人物等在进行人生意义深层思考的情境。不适用于纯技术性、短期功利目标或未影响他人生活的私人行为。
---

# True Achievement Evaluation

## When to Use
Use this skill when:
- Evaluating whether a body of work (e.g., books, theories, ventures) constitutes “real achievement” beyond fame or output.
- Reflecting on life purpose or legacy in contexts involving social influence.
- Questioning if success is superficial versus transformative.

## How to Execute

1. **Invoke the Schumpeter-Drucker Criterion**: Recall Joseph Schumpeter’s insight to Peter Drucker: “Unless you change people’s lives, your work has no major significance.”

2. **Assess Two Key Dimensions**:
   - **Theoretical Influence**: How widely your ideas or works are known or cited.
   - **Life Change Degree**: Whether and how your work tangibly altered people’s daily choices, well-being, or worldview.

3. **Apply the Core Test**: Ask: “Did this work *actually change how people live*?” If yes, it qualifies as true achievement; if not, it remains surface-level success.

4. **Expand Beyond Output**: Consider non-utilitarian qualities—moral character, vision, generosity, and intellectual humility—that contribute to enduring respect across generations.

5. **Avoid Common Pitfalls**:
   - Do not equate publications, titles, or awards with meaningful impact.
   - Do not apply this standard to purely personal or technical accomplishments lacking social ripple effects.

6. **Use for Self-Calibration**: Regularly revisit this standard to align ongoing efforts with deeper purpose.