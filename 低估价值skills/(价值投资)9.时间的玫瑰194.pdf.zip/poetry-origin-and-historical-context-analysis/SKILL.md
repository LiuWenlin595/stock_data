---
name: Poetry Origin and Historical Context Analysis
description: 分析诗歌创作的来源类型（天赋或命运）及其与时代背景的关联，适用于解读具有个人回忆性质、反映社会变迁的中文诗歌。当用户提供的文本回顾过往诗歌并将其与个人命运及中国社会历史进程相联系时，使用本技能。
---

# Poetry Origin and Historical Context Analysis

## When to Use
Use this skill when:
- The text reflects on poetry written during the author's youth
- The poem is tied to personal experiences within major social or historical changes (e.g., China’s developmental trajectory)
- The user seeks to interpret a poem not just as art but as a witness to collective memory
- The writing explicitly connects emotional recollection with historical context (e.g., phrases like “感慨万千” about “青春岁月留下的诗行”)

Do **not** use for:
- Technical, functional, or purely aesthetic texts without historical or emotional grounding
- Poems lacking any reference to societal change or personal fate

## How to Execute

1. **Identify the poem’s origin type**: Determine whether it stems from:
   - **Talent**: innate artistic ability, often detached from lived hardship
   - **Fate**: shaped by life events, historical turbulence, and social transformation

2. **Assess the author’s self-perception**: If the author describes themselves as “平凡” (ordinary), prioritize the “fate” origin interpretation.

3. **Locate the historical context**: Look for markers of Chinese socio-historical change (e.g., reform era, collective struggles, national progress amid chaos).

4. **Evaluate emotional anchoring**: Confirm if the poem’s value lies in its connection to youth memory and shared generational experience.

5. **Apply judgment**: If the poem reflects personal emotion intertwined with national or societal transformation, classify it as a product of “命运赐予的” (granted by fate) and emphasize its role as historical testimony.

> Output should frame the poem as “特定历史条件下个人命运与集体记忆的交汇产物”， highlighting its testimonial over purely aesthetic value.