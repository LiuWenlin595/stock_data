---
name: convertible-sliding-conversion-analysis
description: Evaluate time-based sliding conversion price schedules in convertible securities to determine optimal conversion timing. Use when analyzing convertible bonds with escalating conversion prices, assessing forced conversion risks, or evaluating privileges with time-decay mechanisms.
---

# 可转换证券滑动转换比率分析

## 适用场景
- 分析合同规定不同时期转换价格阶梯的可转换证券时
- 需要评估特权有效期逐步缩短的证券时
- 确定最优转换时机以避免条件恶化时
- 评估强制转换风险及时间压力时

## 核心工作流程

### 第一步：识别机制结构
1. 确认合同规定的连续时期递增转换价格
2. 绘制转换价格时间表：
   - 第一阶段：转换价格 X
   - 第二阶段：转换价格 X+Δ（更高，更不利）
   - 后续阶段：持续递增

### 第二步：分析经济目的
- **机制目的**：逐步降低特权价值，促进转换权实施
- **发行方意图**：缩短特权有效期限，降低选择权真实价值
- **投资者影响**：被迫在特定时间窗口做出决策

### 第三步：评估转换时机
1. **当前阶段分析**
   - 记录当前转换价格
   - 计算当前转换价值（股票市价 vs 转换价格）

2. **未来阶段对比**
   - 确认下一阶段的转换价格（更高）
   - 计算延误转换的潜在利润损失
   - 评估时间衰减成本

3. **决策节点**
   - 在特定日期前评估是否转换
   - 避免条件恶化导致的不利转换比率

### 第四步：风险警示
- **不合时宜转换风险**：如波多黎各—美国烟草公司案例（1928年转换后1929年股价大跌）
- **延误转换风险**：潜在利润减少，转换条件恶化
- **强制转换压力**：时间推移导致转换条件越来越不利

## 典型案例
**AT&T 1929年债券**：
- 1930年：转换价格 180
- 1931-1932年：转换价格 190  
- 1933-1937年：转换价格 200

## 关键决策原则
- 在转换价格上调前评估股价趋势
- 权衡立即转换的溢价成本 vs 延误的比率损失
- 监控标的股票波动性