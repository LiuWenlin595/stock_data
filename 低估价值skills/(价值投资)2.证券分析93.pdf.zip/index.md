```markdown
# 证券分析技能集 (Security Analysis Skills)

本技能集源自经典投资著作《证券分析》(Security Analysis)，由本杰明·格雷厄姆与戴维·多德撰写。这些技能涵盖价值投资、固定收益证券分析、财务报表审查、公司治理评估等核心领域，帮助用户应用严谨的证券分析方法进行投资决策。

## 可用技能

| 技能 | 描述 | 使用场景 |
|------|------|----------|
| [accounting-red-flags-avoidance](accounting-red-flags-avoidance/SKILL.md) | 识别会计操纵红旗信号并执行回避决策 | 发现账目窜改、可疑会计政策或公司治理问题时 |
| [adjustment-vs-income-bond-comparison](adjustment-vs-income-bond-comparison/SKILL.md) | 比较调整债券与收入债券的条款差异 | 铁路公司重组后次级债券比较 |
| [bankruptcy-priority-analysis](bankruptcy-priority-analysis/SKILL.md) | 分析破产重组中的绝对优先权原则 | 评估违约债券、破产情景回收前景 |
| [bond-contract-structure-analysis](bond-contract-structure-analysis/SKILL.md) | 分析债券契约中的非标准本金偿还条款 | 审查债券契约、识别偿债基金机制 |
| [bond-credit-assessment-standards](bond-credit-assessment-standards/SKILL.md) | 应用利息与股息支付记录的信用评估原则 | 评估债券信用等级、比较不同行业投资标准 |
| [bond-credit-historical-analysis](bond-credit-historical-analysis/SKILL.md) | 通过历史案例研究方法评估企业债券信用质量 | 评估企业债券历史表现、识别信用风险信号 |
| [bond-default-recovery-guarantee-analysis](bond-default-recovery-guarantee-analysis/SKILL.md) | 分析债券违约后的回收率与担保条款效力 | 违约债券估值、外国债券信用风险分析 |
| [bond-financial-ratio-calculation](bond-financial-ratio-calculation/SKILL.md) | 计算债券的收益覆盖率、固定费用和营运资金比率 | 评估债券安全性、计算利息保障倍数 |
| [bond-prospectus-depreciation-disclosure](bond-prospectus-depreciation-disclosure/SKILL.md) | 审查债券募集公告中的折旧披露质量 | 工业证券募集说明书分析、信息披露质量评估 |
| [bond-risk-failure-diagnosis](bond-risk-failure-diagnosis/SKILL.md) | 诊断债券投资风险和失败原因 | 评估证券安全性、分析历史债券失败案例 |
| [bond-safety-assessment](bond-safety-assessment/SKILL.md) | 评估债券安全性，识别利息率对表面安全性的误导 | 债券投资决策、合同条款分析 |
| [bond-safety-coverage-analysis](bond-safety-coverage-analysis/SKILL.md) | 使用资产覆盖率、利息覆盖率等指标进行债券安全性分析 | 评估债券信用质量、比较债券替代方案 |
| [bond-safety-dual-basis-evaluation](bond-safety-dual-basis-evaluation/SKILL.md) | 分析安全性的两个根本来源（行业性质与保护程度） | 评估债券安全性、分析行业对经济萧条的免疫力 |
| [bond-safety-standards-assessment](bond-safety-standards-assessment/SKILL.md) | 评估债券投资安全性的核心原则和量化标准 | 债券投资者、投资组合管理者进行债券投资决策 |
| [bond-security-clauses-analysis](bond-security-clauses-analysis/SKILL.md) | 分析债券担保条款，包括平等证券条款、置产抵押例外 | 审查债券双联合同、评估抵押品保护 |
| [bond-terms-and-default-handling](bond-terms-and-default-handling/SKILL.md) | 识别非标准债券利息条款、处理违约事件与加速条款 | 分析债券利息支付条款差异、发生违约事件时 |
| [bond-trading-strategies](bond-trading-strategies/SKILL.md) | 评估债券交换策略和高级债券周期性交易的局限性 | 考虑债券互换、分析市场时机机会 |
| [book-loss-vs-liquidation-value](book-loss-vs-liquidation-value/SKILL.md) | 分析账面亏损与清算价值的差异 | 损益账户显示亏损但资产负债表显示资产变现能力增强 |
| [book-value-calculation](book-value-calculation/SKILL.md) | 计算普通股每股账面价值 | 证券分析、财务报告和估值场景 |
| [book-value-market-price-analysis](book-value-market-price-analysis/SKILL.md) | 当股票市场价格与帐面价值显著背离时进行企业整体价值评估 | 普通股投资分析、市场估值极端案例 |
| [bull-market-participating-security-anomaly](bull-market-participating-security-anomaly/SKILL.md) | 识别强劲牛市中参与证券因流动性劣势导致的定价异常 | 市场投机性上涨、参与证券价格相对滞后时 |
| [capital-structure-adjustment](capital-structure-adjustment/SKILL.md) | 对历史每股收益和每股资产价值进行调整以反映资本结构变化 | 考察期内发生股票股息、拆股、增发新股等情况 |
| [capital-structure-leverage-analysis](capital-structure-leverage-analysis/SKILL.md) | 评估资本结构杠杆效应、债务权益比 | 评估公司财务风险、分析杠杆对盈利的影响 |
| [capital-structure-optimization](capital-structure-optimization/SKILL.md) | 评估企业资本结构合理性，应用三分法分类体系 | 企业融资决策、资本结构评估、证券投资分析 |
| [cheap-stock-analysis](cheap-stock-analysis/SKILL.md) | 识别、分析和筛选售价低于清算价值的廉价股票 | 价值投资和证券分析场景 |
| [class-a-preferred-redemption-analysis](class-a-preferred-redemption-analysis/SKILL.md) | 评估具有优先证券实质的A类股票的赎回特征和偿债基金条款 | 分析可赎回优先证券、评估提前赎回风险 |
| [class-i-railroad-maintenance-benchmark](class-i-railroad-maintenance-benchmark/SKILL.md) | 使用1926-1930年美国I级铁路维护费用基准数据 | 分析铁路运营成本、识别异常低费用情况 |
| [common-stock-analysis-validity](common-stock-analysis-validity/SKILL.md) | 识别普通股分析有效性受损的双重因素 | 普通股分析得出不可靠结论、对比1920年前后投资环境 |
| [common-stock-investment-criteria](common-stock-investment-criteria/SKILL.md) | 评估普通股是否符合投资定义，应用战前三重标准 | 判断普通股投资性质、验证成组购买的投资资格 |
| [common-stock-investment-hypothesis-validation](common-stock-investment-hypothesis-validation/SKILL.md) | 验证普通股分散投资策略的三个基本假设 | 评估长期持有普通股组合是否为正确策略 |
| [common-stock-investment-principles](common-stock-investment-principles/SKILL.md) | 应用普通股投资的三大核心原则：组合性操作、定性和定量检验、价格合理性验证 | 建立或评估普通股投资策略和投资组合 |
| [common-stock-investment-valuation-standards](common-stock-investment-valuation-standards/SKILL.md) | 区分普通股投资与投机的严格标准，确定投资性购买的最高价格上限 | 评估普通股是否具备投资性购买资格、计算合理买入价格阈值 |
| [common-stock-speculative-classification](common-stock-speculative-classification/SKILL.md) | 将普通股按投机性来源分为三类，识别真正适合投资性购买的证券 | 筛选普通股投资组合、评估个股投资属性、区分投资与投机 |
| [comparative-analysis-decision](comparative-analysis-decision/SKILL.md) | 解读比较分析结果并制定投资决策框架 | 基于统计数据得出比较结论或建议证券掉换时 |
| [complex-capital-structure-valuation](complex-capital-structure-valuation/SKILL.md) | 分析具有复杂资本结构的公司，调整标准估值模型 | 限制性股票、参与权证券、可转换债券、高杠杆资本结构 |
| [conservative-investment-valuation](conservative-investment-valuation/SKILL.md) | 评估投资级普通股的内在价值以确定购买价格 | 具有5-10年稳定收益历史、财务结构稳健的成熟公司 |
| [consolidated-statement-analysis](consolidated-statement-analysis/SKILL.md) | 分析拥有子公司的母公司真实经营业绩 | 分析控股公司结构、评估母公司真实收益质量 |
| [consolidated-vs-parent-financial-analysis](consolidated-vs-parent-financial-analysis/SKILL.md) | 分析控股公司债券安全性时识别并使用合并报表 | 公共事业控股公司、母公司债券分析 |
| [contract-constraint-value-trap-identification](contract-constraint-value-trap-identification/SKILL.md) | 识别合同约束导致的收益上限和价值陷阱 | 受监管公用事业、合同约束型基础设施企业 |
| [convertible-bond-anti-dilution](convertible-bond-anti-dilution/SKILL.md) | 分析可转换债券的反稀释条款和价格调整机制 | 评估可转换债券的转换价格调整、计算稀释效应 |
| [convertible-bond-hedging-strategy](convertible-bond-hedging-strategy/SKILL.md) | 执行可转换债券的中间对冲操作策略 | 债券价格坚挺、股票价格存在波动性的场景 |
| [convertible-bond-merger-adjustments](convertible-bond-merger-adjustments/SKILL.md) | 可转换债券面临公司合并或兼并事件时计算转换价格调整 | 并购中的债券条款分析、反稀释保护计算 |
| [convertible-bond-relative-value-analysis](convertible-bond-relative-value-analysis/SKILL.md) | 分析可转换担保短期债券与长期债券的相对价值 | 比较同一公司不同期限债券且短期债券具有担保和转换条款 |
| [convertible-bond-valuation](convertible-bond-valuation/SKILL.md) | 评估可转换债券的投资价值和风险特征 | 初始发行价远高于平价的可转换债券 |
| [convertible-securities-analysis](convertible-securities-analysis/SKILL.md) | 分析可转换证券的转换价格调整机制 | 评估可转换债券或优先股，计算转换价格 |
| [convertible-securities-provision-analysis](convertible-securities-provision-analysis/SKILL.md) | 分析可转换证券的特殊条款及其对市场价格的影响 | 评估具有特殊转换条款的可转换债券、识别套利机会 |
| [convertible-securities-switching](convertible-securities-switching/SKILL.md) | 执行普通股向可转换优先股或债券的调换 | 持有普通股且可转换高级证券接近平价交易时 |
| [convertible-security-evaluation](convertible-security-evaluation/SKILL.md) | 可转换债券与附认股权证证券特权条款的三要素评估法 | 比较不同附权证券条款优劣、评估转换特权接近实现程度 |
| [convertible-security-valuation](convertible-security-valuation/SKILL.md) | 计算可转换证券的转换平价，判断溢价/折价状态 | 评估可转换债券/优先股与普通股的相对价值 |
| [convertible-sliding-conversion-analysis](convertible-sliding-conversion-analysis/SKILL.md) | 评估可转换证券中基于时间的滑动转换价格时间表 | 分析具有递增转换价格的可转换债券 |
| [corporate-debt-policy](corporate-debt-policy/SKILL.md) | 企业发债筹资的正确财务政策理论 | 分析企业融资方式选择、评估股东与债券持有人利益平衡 |
| [corporate-governance-conflict-resolution](corporate-governance-conflict-resolution/SKILL.md) | 识别和解决股东与经营者之间的利益冲突 | 上市公司治理评估、代理问题分析和董事会决策 |
| [corporate-governance-shareholder-rights](corporate-governance-shareholder-rights/SKILL.md) | 分析公司治理结构、股东权利与管理层关系 | 股票市价低于清算价值、存在管理层滥用职权 |
| [corporate-securities-accounting](corporate-securities-accounting/SKILL.md) | 处理公司自身证券交易的会计原则与收益质量分析 | 识别企业将债券购回利润错误计入当期收益的做法 |
| [coverage-ratio-calculation](coverage-ratio-calculation/SKILL.md) | 正确计算债券利息保障比率，避免预先扣除法的误导性 | 评估债券安全性、计算固定费用保障倍数 |
| [current-asset-value-calculation](current-asset-value-calculation/SKILL.md) | 计算普通股或优先股的流动资产价值 | 需要评估清算价值的证券、分析公司流动资产净值 |
| [cyclical-market-timing-strategy](cyclical-market-timing-strategy/SKILL.md) | 应用罗杰·巴布莱的周期性股票操作策略 | 在周期性波动市场中对龙头普通股进行"贱买贵卖" |
| [declining-company-valuation](declining-company-valuation/SKILL.md) | 分析收益下滑的衰退企业，判断其低价位是否构成价值投资机会 | 避免草率假设前途无望或必然回升，通过定性研究评估 |
| [defensive-stock-valuation](defensive-stock-valuation/SKILL.md) | 评估防御性股票的多维度估值逻辑 | 评估碧翠丝乳品公司等防御性股票、分析稳定消费品行业 |
| [deficit-data-handling](deficit-data-handling/SKILL.md) | 正确处理包含亏损年份的财务数据 | 分析周期性行业、评估债券安全性、计算长期平均收益 |
| [deficit-qualitative-analysis](deficit-qualitative-analysis/SKILL.md) | 分析包含亏损年度的收益记录，将赤字视为定性因素 | 比较不同公司的赤字情况、计算跨越经济周期的平均收益 |
| [depreciation-analysis-and-adjustment](depreciation-analysis-and-adjustment/SKILL.md) | 分析折旧会计方法，评估报告折旧是否充分或过度 | 分析资本密集型公司、比较不同折旧政策的公司 |
| [depreciation-analysis-framework](depreciation-analysis-framework/SKILL.md) | 分析财务报表中的折旧与摊销处理 | 评估折旧是否被正确核算、评估公用事业债券合规性 |
| [depreciation-analysis-framework-2](depreciation-analysis-framework-2/SKILL.md) | 分析企业折旧费用的合理性和真实性 | 折旧费用占收益比重较大、需要评估固定资产密集型企业 |
| [depreciation-expense-analysis](depreciation-expense-analysis/SKILL.md) | 评估公司财务报告中折旧费用处理的合理性 | 审查公司财务报告、公司以资产增值为由省略折旧 |
| [depreciation-red-flags-detection](depreciation-red-flags-detection/SKILL.md) | 识别企业折旧政策中的危险信号 | 财务分析、投资尽职调查、审计风险评估 |
| [dividend-analysis-signals](dividend-analysis-signals/SKILL.md) | 分析股息政策信号和股息稳定性对股价的影响 | 识别特别股票股息作为现金股息增加的前兆信号 |
| [dividend-declaration-procedures](dividend-declaration-procedures/SKILL.md) | 根据公司注册地选择适用的股息宣告程序 | 欧陆国家上市公司、英国上市公司宣告年度股息分配方案 |
| [dividend-paradox-shareholder-return-analysis](dividend-paradox-shareholder-return-analysis/SKILL.md) | 分析股息悖论现象，比较不同股息政策下的股东总回报 | 长期股息政策评估和股东总回报分析 |
| [dividend-policy-critical-analysis](dividend-policy-critical-analysis/SKILL.md) | 批判性分析公司的股息政策，识别低股息支付率的潜在问题 | 分析实施低股息支付率的公司、累积大量盈余的公司 |
| [dividend-policy-framework](dividend-policy-framework/SKILL.md) | 设计或评估上市公司股票股息政策 | 收益再投资型公司、公共事业控股公司、董事会股息决策 |
| [document-structure-identification](document-structure-identification/SKILL.md) | 识别文档的结构元素，包括部分主题、章节标题 | 需要解析文档组织结构或定位特定章节时 |
| [earnings-analysis](earnings-analysis/SKILL.md) | 分析企业盈利能力，包括盈利能力概念定义、平均收益有效性判断 | 基本面分析和估值场景 |
| [earnings-financial-condition-divergence](earnings-financial-condition-divergence/SKILL.md) | 识别公司盈利能力与财务状况背离的警示信号 | 报告每股收益高企但营运资本恶化时 |
| [earnings-manipulation-detection](earnings-manipulation-detection/SKILL.md) | 识别公司通过资产减计、递延费用不当处理等手段"炮制收益" | 审计财务报告、评估收益质量、投资风险分析 |
| [earnings-manipulation-detection-2](earnings-manipulation-detection-2/SKILL.md) | 识别公司通过费用资本化、盈余冲抵等手段操纵利润 | 审计财务报表发现异常会计处理、分析公司收益质量 |
| [earnings-manipulation-detection-3](earnings-manipulation-detection-3/SKILL.md) | 检测财务报表中的收益操纵和会计欺诈行为 | 分析财务报表的收益质量、识别报告利润中的危险信号 |
| [earnings-quality-and-sustainability-assessment](earnings-quality-and-sustainability-assessment/SKILL.md) | 评估报告收益的质量和可持续性，识别非经常性项目 | 评估拥有异常利润来源的公司、评估收益持续性 |
| [earnings-quality-verification](earnings-quality-verification/SKILL.md) | 验证公司报告收益的真实性，识别偶生项目、子公司收益调整 | 评估收益质量、发现报告收益与财务状况不匹配 |
| [earnings-valuation-principles](earnings-valuation-principles/SKILL.md) | 应用基于收益的估值原则，对比前景与内在价值 | 评估普通股投资价值、确定买卖时机 |
| [earning-power-valuation-framework](earning-power-valuation-framework/SKILL.md) | 通过区分正常平均值与简单算术平均评估公司盈利能力 | 拥有7-10年收益历史的成熟公司，未来可持续性是核心问题 |
| [empty-chapter-detection](empty-chapter-detection/SKILL.md) | 检测和处理文档中的空章节或占位符章节 | 遇到仅包含标题而无实际内容的章节时 |
| [equity-bond-safety-comparison](equity-bond-safety-comparison/SKILL.md) | 普通股与债券安全性的比较原理及动态安全边际调整 | 评估以股票形式持有资产是否优于债券形式 |
| [financial-data-unit-conversion](financial-data-unit-conversion/SKILL.md) | 处理以百万美元为单位的财务报表数据转换 | 读取表格数值、统一大规模财务数据的计量单位 |
| [financial-distress-timeline-analysis](financial-distress-timeline-analysis/SKILL.md) | 跟踪财务困境从累积亏损到破产清算的进展过程 | 分析困境公司债券、评估保护委员会行动 |
| [financial-institution-risk-analysis](financial-institution-risk-analysis/SKILL.md) | 分析投资信托公司、银行和保险公司的证券投资收益特殊处理 | 评估金融机构股票的真实盈利能力 |
| [financial-market-structure-risks](financial-market-structure-risks/SKILL.md) | 评估投资银行行为合规性，识别"蓝天"促销术和金字塔式控股结构 | 分析新发行证券的投资银行背景、评估控股公司投资风险 |
| [financial-position-validation](financial-position-validation/SKILL.md) | 通过分析营运资本、现金流和资产负债表变动交叉验证报告收益 | 报告收益与资产负债表变化不一致、评估亏损期间的真正财务健康 |
| [financial-reserve-audit-adjustment](financial-reserve-audit-adjustment/SKILL.md) | 审查和调整财务报表中的储备项目，识别管理层通过储备操纵收益 | 评估报告收益质量、识别收益高估或低估 |
| [financial-table-structure-parsing](financial-table-structure-parsing/SKILL.md) | 解析多维度财务数据表格结构，提取项目×年度的矩阵数据 | 处理财务报表、历史数据汇总表、多期对比分析表 |
| [fixed-charge-calculation-method](fixed-charge-calculation-method/SKILL.md) | 选择并应用固定费用计算方法，确保与标准统计公司结果一致 | 计算公司固定费用保障倍数、比较不同来源的固定费用数据 |
| [fixed-income-coverage-ratio-analysis](fixed-income-coverage-ratio-analysis/SKILL.md) | 评估债券和优先股投资安全性的核心定量工具 | 计算或验证利息保障比率、股票-债券比率 |
| [fixed-income-coverage-safety-analysis](fixed-income-coverage-safety-analysis/SKILL.md) | 评估工业债券、控股公司债券及优先股的安全边际 | 固定收益证券安全性评级、信用风险监测 |
| [fixed-income-investment-selection](fixed-income-investment-selection/SKILL.md) | 固定价值类投资工具的选择原则与安全性评估框架 | 排除劣质证券、建立债券投资组合、评估发行人偿付能力 |
| [fixed-income-portfolio-surveillance](fixed-income-portfolio-surveillance/SKILL.md) | 管理固定收益投资组合，执行定期证券分析 | 投资性证券组合管理、1929年后投资范式、风险管理 |
| [foreign-bond-risk-assessment](foreign-bond-risk-assessment/SKILL.md) | 评估外国政府债券和公司债券投资风险的专项工具 | 考虑购买非本国发行人债券、分析主权信用风险 |
| [fundamental-analysis-reasoning-framework](fundamental-analysis-reasoning-framework/SKILL.md) | 整合历史记录分析、定性验证与逻辑推理进行普通股基本面分析 | 评估企业稳定性或预测未来前景时 |
| [grain-processing-historical-analysis](grain-processing-historical-analysis/SKILL.md) | 使用1906-1932年分析框架对谷物制品加工公司进行历史财务绩效分析 | 评估谷物加工行业历史数据、分析长期资本结构演变 |
| [grain-products-financial-evaluation](grain-products-financial-evaluation/SKILL.md) | 评估谷物制品加工公司1906-1932年间的财务健康状况 | 分析历史财务数据、评估长期盈利能力变化 |
| [guaranteed-securities-valuation](guaranteed-securities-valuation/SKILL.md) | 担保证券的评级原则与价值评估方法 | 评估租赁契约支持的证券、比较担保债券与担保人自身证券定价 |
| [guarantee-evaluation-and-legal-analysis](guarantee-evaluation-and-legal-analysis/SKILL.md) | 评估担保安排的有效性、分析担保条款细节 | 验证不动产抵押贷款担保条件、评估担保条款价值 |
| [hidden-losses-detection-via-surplus-manipulation](hidden-losses-detection-via-surplus-manipulation/SKILL.md) | 识别通过资本盈余和储备账户掩盖经营亏损的会计操纵 | 分析存在资本盈余账户、设立意外储备的企业 |
| [high-quick-asset-coverage-opportunities](high-quick-asset-coverage-opportunities/SKILL.md) | 识别具有高净速动资产覆盖率的低价工业债券投资机会 | 价值投资者寻找特别投资机会、评估低价工业债券 |
| [historical-financial-data-timeframe](historical-financial-data-timeframe/SKILL.md) | 识别和规范历史财务数据的时间跨度 | 分析历史趋势表、年度对比报表或长期财务统计 |
| [historical-overcapitalization-analysis](historical-overcapitalization-analysis/SKILL.md) | 分析20世纪初工业公司股息政策、研究留存收益历史用途 | 识别公司是否因早期过度资本化而被迫将收益用于冲销无形资产 |
| [historical-railroad-utility-data-sources](historical-railroad-utility-data-sources/SKILL.md) | 追溯1922-1933年美国铁路与公共事业行业的历史财务数据来源 | 学术研究、历史金融分析、固定收益证券的历史比较研究 |
| [historical-report-scope-definition](historical-report-scope-definition/SKILL.md) | 确认1922年4月铁路公司比较分析报告的适用范围 | 金融史研究、历史比较分析或验证特定历史文献 |
| [holding-company-expansion-analysis](holding-company-expansion-analysis/SKILL.md) | 分析控股公司的扩张方法和结构性质 | 控股公司、收购方、铁路集团等需要扩张控制权的企业 |
| [holding-company-fixed-charge-priority](holding-company-fixed-charge-priority/SKILL.md) | 分析控股公司系统中固定费用的构成和优先级 | 评估公共事业控股公司、母公司债券和经营中子公司的固定费用结构 |
| [holding-company-manipulation-detection](holding-company-manipulation-detection/SKILL.md) | 识别控股公司的财务操纵技术 | 分析控股公司财务报表、损益表，评估收益质量 |
| [hybrid-securities-convertible-analysis](hybrid-securities-convertible-analysis/SKILL.md) | 分析附权高级证券的投资价值与套利策略 | 评估利润分享特征的条款价值、执行投机性证券的对冲调换 |
| [immature-securities-investment-criteria](immature-securities-investment-criteria/SKILL.md) | 评估新工业债券和优先股的投资价值 | 不成熟工业证券的投资评估 |
| [income-bond-interest-projection](income-bond-interest-projection/SKILL.md) | 基于可用收益和最低分配政策预测收入债券或调整债券的利息支付可能性 | 评估或有利息债券、评估支付前景 |
| [income-tax-adjustment](income-tax-adjustment/SKILL.md) | 基于所得税差异对报告收益进行保守调整 | 怀疑收益质量、需要验证收益真实性 |
| [industrial-bond-investment-screening](industrial-bond-investment-screening/SKILL.md) | 应用工业债券投资的双重筛选标准、营运资金检验标准 | 评估工业企业债券的投资安全性、分析无担保子公司债券 |
| [industry-specific-bond-analysis](industry-specific-bond-analysis/SKILL.md) | 针对不同行业债券的专项分析标准 | 评估市政债券、公共事业债券、铁路债券和工业债券 |
| [interest-coverage-ratio-analysis](interest-coverage-ratio-analysis/SKILL.md) | 计算并分析债券利息保障倍数 | 债券投资安全性评估、年度财务审计和信用风险分析 |
| [intrinsic-value-estimation](intrinsic-value-estimation/SKILL.md) | 基于企业家视角进行企业内在价值评估 | 评估企业内在价值而非市场投机价格、分析收益持续性 |
| [inventory-analysis-and-valuation](inventory-analysis-and-valuation/SKILL.md) | 分析存货会计政策、价格波动及其对财务报表和估值的影响 | 评估存货占比较高的公司、分析存货减值 |
| [investment-advisory-sources-evaluation](investment-advisory-sources-evaluation/SKILL.md) | 评估和比较六类投资咨询来源 | 需要证券管理咨询或持有证券需要管理的投资者 |
| [investment-analysis-methodology-evaluation](investment-analysis-methodology-evaluation/SKILL.md) | 评估不同投资分析方法的有效性和局限性 | 证券价格预测方法有效性评估、投资策略制定 |
| [investment-holding-company-valuation](investment-holding-company-valuation/SKILL.md) | 对持有大量固定收益资产或投资性资产的公司进行估值 | 管道公司、证券控股公司、租赁公司等以被动收益为主的企业 |
| [investment-ideology-critique](investment-ideology-critique/SKILL.md) | 批判性分析投资领域的错误意识形态和流行谬误 | 识别投资中的逻辑谬误、批判"新时代理论" |
| [investment-philosophy-security-analysis](investment-philosophy-security-analysis/SKILL.md) | 区分投资与投机行为，并应用证券分析而非市场分析 | 判断某项证券购买属于投资还是投机 |
| [investment-speculation-distinction](investment-speculation-distinction/SKILL.md) | 区分普通股投资与投机的本质差异 | 市场出现大幅波动或需要明确投资行为性质 |
| [investment-trust-financing-analysis](investment-trust-financing-analysis/SKILL.md) | 分析投资信托公司融资结构，计算认股权证稀释效应 | 评估1929年代投资信托融资方案、附带认股权证的证券发行 |
| [investment-trust-valuation](investment-trust-valuation/SKILL.md) | 分析投资信托股票发行定价中的管理成本溢价 | 投资信托类公司的发行定价分析和隐性成本识别 |
| [lease-backed-security-credit-assessment](lease-backed-security-credit-assessment/SKILL.md) | 分析租赁支持债券或租赁抵押债券的信用风险和披露合规性 | 审查租赁债券募集说明书、计算真实利息保障 |
| [leasehold-improvement-amortization](leasehold-improvement-amortization/SKILL.md) | 处理租入财产改良支出的摊销与会计确认 | 分析租赁物业投资、评估报告收益质量 |
| [leverage-earnings-sensitivity](leverage-earnings-sensitivity/SKILL.md) | 计算债务融资对EPS的放大效应，评估风险-收益权衡 | 比较杠杆企业与无杠杆企业、分析固定利息费用对EPS波动性的影响 |
| [liquidation-value-assessment](liquidation-value-assessment/SKILL.md) | 评估企业流动资产价值和清算价值 | 判断普通股是否被严重低估、评估企业资产变现能力 |
| [long-term-capital-efficiency-diagnosis](long-term-capital-efficiency-diagnosis/SKILL.md) | 使用三十年财务数据诊断产能过剩和结构性盈利能力问题 | 资本密集型行业长期投资大幅增加但收益率下降时 |
| [long-term-performance-trend-analysis](long-term-performance-trend-analysis/SKILL.md) | 解读长期财务数据背后的经营状况，识别周期性波动 | 周期性行业分析、长期投资策略制定 |
| [low-priced-stocks-analysis](low-priced-stocks-analysis/SKILL.md) | 分析低价股的定义、算术优势及收益来源 | 股票价格低于$10或在$10-$20范围内且具备投机特征 |
| [managerial-stock-price-fiduciary-duty](managerial-stock-price-fiduciary-duty/SKILL.md) | 分析管理者对股票价格的受托责任 | 公司管理者、董事会评估股价管理责任 |
| [market-anomaly-structure-analysis](market-anomaly-structure-analysis/SKILL.md) | 识别市场异常现象和复杂资本结构 | 分析优先股价格异常、识别投机炒作、评估多层控股杠杆风险 |
| [market-behavior-analysis](market-behavior-analysis/SKILL.md) | 分析标准证券与非标准证券的市场行为差异 | 评估证券价格对基本面变化的反应程度或调整投资调换策略 |
| [market-overreaction-opportunity-analysis](market-overreaction-opportunity-analysis/SKILL.md) | 识别市场对非收益因素的非理性夸大反应 | 涉及诉讼、公司事件导致的价格异常波动 |
| [market-timing-standards-management](market-timing-standards-management/SKILL.md) | 拒绝根据市场周期调整投资标准 | 考虑使用杠杆交易、试图预测市场反转时 |
| [market-value-anomaly-detection](market-value-anomaly-detection/SKILL.md) | 评估公司证券定价合理性，检测市场价值与资产流动性的异常关系 | 评估公司证券定价合理性或识别潜在投资机会 |
| [mature-security-market-behavior-analysis](mature-security-market-behavior-analysis/SKILL.md) | 区分成熟证券与不成熟证券的市场行为特征 | 分析高级证券价格异常稳定或过度波动、评估老牌公司证券投资价值 |
| [mna-depreciation-policy-conflict](mna-depreciation-policy-conflict/SKILL.md) | 识别并购交易中因折旧政策差异导致的潜在不公平性 | 评估企业合并或收购方案，合并双方折旧政策存在显著差异 |
| [mining-company-analysis](mining-company-analysis/SKILL.md) | 分析采矿企业盈利能力和未来经营风险时必须系统考察的四大决定性因素 | 评估矿业公司投资价值、分析矿产开采企业的可持续盈利能力 |
| [mining-depletion-investor-calculation](mining-depletion-investor-calculation/SKILL.md) | 从投资者/收购者视角计算采矿企业的真实矿储耗损摊销成本 | 评估采矿企业真实收益质量、判断股息分配可持续性 |
| [mining-grade-misleading-profit-analysis](mining-grade-misleading-profit-analysis/SKILL.md) | 识别矿体品质临时提升导致的误导性高盈利 | 分析金矿、铜矿等品位敏感型矿企 |
| [minority-interest-coverage-calculation](minority-interest-coverage-calculation/SKILL.md) | 计算包含子公司少数股东权益的控股公司利息保障比率 | 控股公司债券分析、合并报表分析 |
| [mortgage-bond-investment-analysis](mortgage-bond-investment-analysis/SKILL.md) | 分析抵押债券投资，评估担保机制、发行人稳健性 | 抵押债券、抵押参与证书或不动产债券投资决策 |
| [mortgage-trust-bond-evaluation](mortgage-trust-bond-evaluation/SKILL.md) | 评估抵押-信托债券和投资信托公司信用债券的安全性 | 评估以股票或其他债券为抵押的债务形式 |
| [multi-class-stock-voting-rights-analysis](multi-class-stock-voting-rights-analysis/SKILL.md) | 分析多类别普通股结构中的表决权差异化配置 | 存在A类、B类或普通股区分的公司 |
| [new-era-theory-valuation](new-era-theory-valuation/SKILL.md) | 应用新时代理论进行估值 | 理解1920年代后的估值理念转变 |
| [new-issue-hidden-cost-analysis](new-issue-hidden-cost-analysis/SKILL.md) | 分析新企业股票发行或首次公开发行 | 招股说明书包含多重选择权条款、承销商激励结构复杂 |
| [non-standard-securities-identification](non-standard-securities-identification/SKILL.md) | 识别和分类不符合标准定义的证券 | 遇到管理者/员工股票、收入债券、信用股票等特殊结构 |
| [oil-gas-amortization-analysis](oil-gas-amortization-analysis/SKILL.md) | 分析石油天然气公司的摊销费用构成 | 分析石油公司损益表、评估成本结构合理性 |
| [patent-amortization-analysis](patent-amortization-analysis/SKILL.md) | 正确处理专利摊销费用，识别公司通过专利账面操纵虚增收益 | 评估制造业企业真实盈利能力、进行同行业公司对比分析 |
| [peer-comparison-depreciation-assessment](peer-comparison-depreciation-assessment/SKILL.md) | 通过同业比较法评估企业折旧政策的充足性 | 证券分析、并购评估、验证特定企业折旧合理性 |
| [preferred-stock-analysis](preferred-stock-analysis/SKILL.md) | 分析优先股股息保障倍数和验证投资性质 | 评估优先股股息支付安全性、计算保障倍数 |
| [preferred-stock-asset-rights-classification](preferred-stock-asset-rights-classification/SKILL.md) | 根据资产权益特征将优先股分类为9个类别 | 分析优先股条款、评估清算优先权 |
| [preferred-stock-book-value-calculation](preferred-stock-book-value-calculation/SKILL.md) | 计算存在多级优先资本结构公司的各级优先股账面价值 | 具有第一优先股、第二优先股等多层级优先资本结构 |
| [preferred-stock-coverage-analysis](preferred-stock-coverage-analysis/SKILL.md) | 正确计算优先股股息收益覆盖率 | 存在债券和优先股的公司证券分析 |
| [preferred-stock-income-classification](preferred-stock-income-classification/SKILL.md) | 识别和分类优先股收入利益变体 | 证券条款分析、投资工具比较 |
| [preferred-stock-investment-analysis](preferred-stock-investment-analysis/SKILL.md) | 全面分析优先股的投资品质 | 评估优先股投资价值、识别风险、计算保护程度 |
| [preferred-stock-investment-standards](preferred-stock-investment-standards/SKILL.md) | 评估优先股是否适合作为固定价值投资标的 | 筛选投资级优先股、评估股息安全性 |
| [preferred-stock-protective-provisions](preferred-stock-protective-provisions/SKILL.md) | 分析优先股合同保护条款 | 工业/公用事业/铁路优先股投资分析、合同条款审查 |
| [preferred-stock-risk-analysis](preferred-stock-risk-analysis/SKILL.md) | 分析优先股投资风险，特别是中等企业的股息自主权风险 | 评估优先股股息支付安全性、识别董事会自由裁量权风险 |
| [preferred-stock-senior-debt-analysis](preferred-stock-senior-debt-analysis/SKILL.md) | 评估存在在先债券的优先股投资资格 | 分析优先股时需要正确计算收益覆盖率 |
| [preferred-stock-voting-rights](preferred-stock-voting-rights/SKILL.md) | 分析优先股表决权安排 | 评估优先股治理保护条款、分析股息滞付后的控制权变化 |
| [privileged-securities-analysis](privileged-securities-analysis/SKILL.md) | 识别和分析附权证券的类型、特征和投资价值 | 评估债券、优先股、A类股票等高级证券的特权配置 |
| [privileged-securities-call-risk-analysis](privileged-securities-call-risk-analysis/SKILL.md) | 分析提前赎回条款对参与证券、可转换证券和附认股权证证券的不同影响 | 评估包含提前赎回条款的特权证券 |
| [profit-sustainability-assessment](profit-sustainability-assessment/SKILL.md) | 评估快速增长型企业或高利润企业的当前业绩可持续性 | 工业股票、热门股及新兴行业分析 |
| [pyramid-holding-structure-analysis](pyramid-holding-structure-analysis/SKILL.md) | 分析金字塔式控股结构的运作机制、杠杆效应 | 评估控股公司或投资信托公司的多层资本结构 |
| [railroad-bond-credit-analysis](railroad-bond-credit-analysis/SKILL.md) | 分析铁路行业债券信用质量 | 铁路债券投资分析、一揽子抵押结构评估 |
| [railroad-bond-maintenance-adjusted-valuation](railroad-bond-maintenance-adjusted-valuation/SKILL.md) | 通过标准化维护费用差异比较铁路公司优先留置权债券 | 分析具有不同维护会计政策的铁路债券 |
| [railroad-bond-safety-evaluation](railroad-bond-safety-evaluation/SKILL.md) | 评估铁路公司债券安全性的综合分析方法 | 分析铁路债券投资价值、筛查固定收益证券安全性 |
| [railroad-comparative-analysis](railroad-comparative-analysis/SKILL.md) | 使用标准表格框架对铁路公司进行行业内的统计比较 | 铁路公司横向对比分析、行业投资组合配置 |
| [railroad-equity-capital-structure-analysis](railroad-equity-capital-structure-analysis/SKILL.md) | 通过资本结构分析比较铁路公司普通股投资价值 | 股价相近但历史盈利能力发生变化的铁路公司比较 |
| [railroad-equity-analysis](railroad-equity-analysis/SKILL.md) | 评估铁路行业普通股和优先股 | 比较同类铁路公司的相对优势、评估设备租赁效率差异 |
| [railroad-fixed-charge-inflation-analysis](railroad-fixed-charge-inflation-analysis/SKILL.md) | 分析铁路运输公司固定费用膨胀程度 | 分析1913-1922年美国铁路业财务负担 |
| [railroad-operating-expense-analysis](railroad-operating-expense-analysis/SKILL.md) | 分析铁路公司营业费用结构 | 评估铁路公司或比较运输行业的运营效率 |
| [railroad-securities-comprehensive-analysis](railroad-securities-comprehensive-analysis/SKILL.md) | 铁路企业证券分析的标准计算项目体系 | 铁路公司债券、优先股、普通股的投资分析和比较决策 |
| [railway-equipment-trust-evaluation](railway-equipment-trust-evaluation/SKILL.md) | 评估铁路设备信托凭证投资价值的双重保护框架 | 以机车车辆为抵押的固定收益证券分析 |
| [railway-financial-health-assessment](railway-financial-health-assessment/SKILL.md) | 综合评估铁路公司的财务健康状况、盈利能力和债务可持续性 | 评估铁路债券投资、比较受管制的铁路公用事业 |
| [railway-operational-efficiency-analysis](railway-operational-efficiency-analysis/SKILL.md) | 分析铁路公司运营效率，比较装载量与运送距离指标 | 评估1920年代美国铁路公司的运营表现 |
| [railway-operational-efficiency-analysis-2](railway-operational-efficiency-analysis-2/SKILL.md) | 分析铁路公司的运营效率、运输密度和货运经济性 | 评估铁路增长潜力、比较铁路运营商之间的货运效率 |
| [rational-prediction-boundaries](rational-prediction-boundaries/SKILL.md) | 区分理性推断与直觉预测的界限 | 基于过去记录预测未来时需要区分合理推断与凭空猜测 |
| [real-estate-bond-risk-analysis](real-estate-bond-risk-analysis/SKILL.md) | 评估房地产债券和特种建筑物债券的风险 | 评估不动产债券、不动产抵押贷款以及特定目的建筑物抵押债券 |
| [real-estate-guarantee-historical-analysis](real-estate-guarantee-historical-analysis/SKILL.md) | 分析不动产抵押贷款担保公司的运营模式 | 房地产金融历史研究、担保公司风险评估 |
| [rights-bearing-security-purchase-decision](rights-bearing-security-purchase-decision/SKILL.md) | 对附权证券执行严格的二分法购买决策 | 考虑购买售价≥面值的附权高级证券、评估可转换债券投资价值 |
| [security-analysis-book-citation](security-analysis-book-citation/SKILL.md) | 提供《证券分析》1999年海南出版社中文简体版的完整出版元数据 | 学术引用、版本识别或参考文献格式生成 |
| [security-arbitrage](security-arbitrage/SKILL.md) | 执行证券套利操作，包括识别机会、执行步骤、评估结果 | 可转换高级证券、重组、合并、拆股和新股购买权 |
| [securities-classification-concepts](securities-classification-concepts/SKILL.md) | 理解证券传统分类法的局限性，避免分类偏见 | 分析证券分类方法、评估投资工具安全性 |
| [securities-form-value-arbitrage](securities-form-value-arbitrage/SKILL.md) | 识别证券形式转换导致的资产定价非理性偏差 | 分析同一资产权益在不同证券形式下的定价差异 |
| [security-substance-classification](security-substance-classification/SKILL.md) | 根据证券的实际经济特征而非法律名称进行分类 | 需要对证券进行实质性分类以指导投资决策 |
| [senior-fixed-income-securities-investment](senior-fixed-income-securities-investment/SKILL.md) | 评估债券和优先股作为固定价值投资的安全性 | 分析固定收益证券的投资价值、验证历史价格稳定性 |
| [senior-securities-valuation](senior-securities-valuation/SKILL.md) | 应用高级证券最高估价法则确定价值上限 | 评估优先股、投机性债券等高级证券的内在价值 |
| [senior-security-valuation-comparison](senior-security-valuation-comparison/SKILL.md) | 比较高级证券与低级证券的相对价值 | 同一公司或关联实体的高级/低级证券比较、识别证券价格背离 |
| [serial-maturity-sinking-fund-mechanism](serial-maturity-sinking-fund-mechanism/SKILL.md) | 分析和执行债券的顺序到期偿债基金机制 | 债券采用1927-1941年间顺序到期安排 |
| [shareholder-governance-psychology](shareholder-governance-psychology/SKILL.md) | 识别股东认知误区与心理陷阱，分析股东与管理者利益冲突 | 评估被动投资者是否陷入三大误区、审查上市公司治理结构 |
| [shareholder-rights-dividend-policy](shareholder-rights-dividend-policy/SKILL.md) | 设计基于股东权利优先原则的股息政策 | 公司治理改革、股息政策制定和股东积极主义场景 |
| [speculative-analysis-boundaries](speculative-analysis-boundaries/SKILL.md) | 判断证券分析的有效性边界 | 分析典型普通股、面临投机性市场环境、处理异常收益数据 |
| [speculative-capital-structure-investment](speculative-capital-structure-investment/SKILL.md) | 分析和投资具有投机性资本结构的企业 | 评估高成本生产商、头重脚轻资本结构公司的投资机会 |
| [speculative-capital-structure-valuation](speculative-capital-structure-valuation/SKILL.md) | 分析投机性资本结构企业的估值 | 评估高杠杆企业、不景气市场环境下的价值投资 |
| [speculative-securities-analysis](speculative-securities-analysis/SKILL.md) | 分析投机性债券、优先股和次级证券的市场行为特征 | 评估投机性债券、识别投机性优先股价格变化的三个阶段 |
| [speculative-securities-analysis-method](speculative-securities-analysis-method/SKILL.md) | 判断何时对投机性证券采用普通股分析法 | 价格显著低于面值的投机性高级证券、低价债券、低价优先股 |
| [speculative-securities-capital-structure](speculative-securities-capital-structure/SKILL.md) | 分析投机性高级证券和特殊资本结构普通股的投资价值 | 评估价格显著低于面值的证券、分析资本结构杠杆效应 |
| [speculative-senior-securities](speculative-senior-securities/SKILL.md) | 分析投机性高级证券，包括安全性评估、最高估价法则 | 分析对象为投机性高级证券或需要执行对冲操作时 |
| [special-securities-investment-strategies](special-securities-investment-strategies/SKILL.md) | 比较参与证券、可转换证券和附认股权证证券的投资策略 | 长期纯粹投资持有、希望分享超额利润同时保持优先地位 |
| [special-situation-securities-valuation](special-situation-securities-valuation/SKILL.md) | 分析特殊情形下的证券定价 | 识别因特殊权利或情形导致的错误定价机会 |
| [standard-depreciation-policy-framework](standard-depreciation-policy-framework/SKILL.md) | 评估制造业企业标准直线法折旧政策的合理性 | 验证企业折旧率是否保守或激进 |
| [standard-statistics-critique-interpretation](standard-statistics-critique-interpretation/SKILL.md) | 区分特定方法批评与组织评价 | 审查关于标准统计技术的评论以确保平衡解读 |
| [statistical-agency-analysis-protocol](statistical-agency-analysis-protocol/SKILL.md) | 统计机构决定是否省略每股收益计算以避免发布误导性数字 | 编制统计手册、发布证券分析报告、建立数据服务标准 |
| [stock-dividend-and-split-analysis](stock-dividend-and-split-analysis/SKILL.md) | 分析股票股息和拆股，包括记录规范、价格调整机制 | 编制财务报告中的股票股息记录、评估价格调整决策 |
| [stock-dividend-valuation](stock-dividend-valuation/SKILL.md) | 识别股票股息的估值陷阱、恶性循环风险 | 分析按固定比率发放股票股息的公司 |
| [stock-price-correction-measures](stock-price-correction-measures/SKILL.md) | 识别和执行股票市价纠正措施 | 股价显著低于内在价值、拥有超额现金的上市公司 |
| [subsidiary-undistributed-earnings-analysis](subsidiary-undistributed-earnings-analysis/SKILL.md) | 识别子公司未向母公司充分分配的收益 | 母公司持有子公司大量股份、需要调整母公司收益 |
| [tax-based-earnings-verification](tax-based-earnings-verification/SKILL.md) | 使用联邦所得税数据交叉验证美国上市公司报告收益的真实性 | 需要验证报告收益的真实性、识别收益造假 |
| [undervalued-stock-identification](undervalued-stock-identification/SKILL.md) | 识别真正的低价股和Net-Net股票 | 市场低迷时期寻找深度价值投资机会 |
| [undervalued-stock-remedies](undervalued-stock-remedies/SKILL.md) | 当股票市价显著低于清算价值时为董事会设计纠正措施体系 | 公司股价长期低于清算价值、董事会需要履行价值维护责任 |
| [utility-bond-depreciation-analysis](utility-bond-depreciation-analysis/SKILL.md) | 验证公共事业债券收益数字是否已扣除正常折旧费用 | 分析公共事业或控股公司债券的利息保障比率 |
| [utility-railroad-capital-analysis](utility-railroad-capital-analysis/SKILL.md) | 分析公用事业和铁路公司的资本结构与固定费用 | 比较公用事业或铁路公司、计算固定费用保障倍数 |
| [utility-type-industrial-identification](utility-type-industrial-identification/SKILL.md) | 识别采用公共事业型资本结构但实际经营工业业务的企业 | 分析名称包含"公共事业"或"服务"字样的企业 |
| [voluntary-reserves-adjustment](voluntary-reserves-adjustment/SKILL.md) | 识别并调整不代表真实负债的自愿储备 | 分析包含或有损失储备、存货减值准备的资产负债表 |
| [wall-street-stock-valuation-formula](wall-street-stock-valuation-formula/SKILL.md) | 应用华尔街标准公式评估普通股市场价值 | 需要快速评估股票价格时 |
| [warrant-bond-vs-convertible-premium-analysis](warrant-bond-vs-convertible-premium-analysis/SKILL.md) | 比较附认股权证证券与可转换证券在景气市场中的投机溢价差异 | 市场处于上升状态、需要选择杠杆型投资工具时 |
| [warrant-definition-attributes](warrant-definition-attributes/SKILL.md) | 识别、定义和分析认股权证的基本属性 | 遇到金融工具赋予购买股票权利的场景 |
| [warrant-trading-and-valuation](warrant-trading-and-valuation/SKILL.md) | 分析认股权证的交易机制、价格调整、支付方式以及估值 | 评估认股权证价值、计算认购价格、选择支付方式 |
| [warrants-speculative-assessment](warrants-speculative-assessment/SKILL.md) | 评估认股权证的投机吸引力 | 需要判断认股权证是否具有投机价值时 |
| [working-capital-covenant-compliance](working-capital-covenant-compliance/SKILL.md) | 监控营运资金维持契约的合规性 | 审查制造业公司的债券契约 |
| [working-capital-speculative-safety](working-capital-speculative-safety/SKILL.md) | 评估营运资金对投机性高级证券安全性的影响 | 投机性债券、优先股的安全性分析 |

## 快速导航

### 债券分析
- **[bond-safety-standards-assessment]**: 债券安全性核心评估标准
- **[bond-credit-assessment-standards]**: 信用评估原则与行业差异化标准
- **[bond-financial-ratio-calculation]**: 收益覆盖率与固定费用比率计算
- **[bond-risk-failure-diagnosis]**: 债券投资风险与失败原因诊断
- **[railroad-bond-safety-evaluation]**: 铁路债券安全性综合分析
- **[industrial-bond-investment-screening]**: 工业债券双重筛选标准
- **[foreign-bond-risk-assessment]**: 外国债券风险评估
- **[mortgage-bond-investment-analysis]**: 抵押债券投资分析
- **[real-estate-bond-risk-analysis]**: 房地产债券风险分析
- **[high-quick-asset-coverage-opportunities]**: 高净速动资产覆盖率低价债券机会

### 优先股分析
- **[preferred-stock-investment-standards]**: 优先股投资标准与品质评估
- **[preferred-stock-analysis]**: 股息保障倍数计算与投资性质验证
- **[preferred-stock-protective-provisions]**: 合同保护条款分析
- **[preferred-stock-coverage-analysis]**: 正确计算股息收益覆盖率
- **[preferred-stock-asset-rights-classification]**: 资产权益九类分类体系
- **[preferred-stock-risk-analysis]**: 股息自主权风险与流动性保护

### 普通股投资
- **[common-stock-investment-criteria]**: 投资定义与战前三重标准
- **[common-stock-investment-principles]**: 三大核心投资原则
- **[undervalued-stock-identification]**: 低价股与Net-Net股票识别
- **[cheap-stock-analysis]**: 低于清算价值股票分析
- **[conservative-investment-valuation]**: 保守估值方法与价格上限
- **[common-stock-speculative-classification]**: 投机性三分类体系
- **[defensive-stock-valuation]**: 防御性股票多维度估值

### 可转换与附权证券
- **[convertible-securities-analysis]**: 转换价格调整机制分析
- **[convertible-security-valuation]**: 转换平价计算与溢价/折价判断
- **[convertible-bond-valuation]**: 可转换债券投资价值评估
- **[convertible-bond-hedging-strategy]**: 中间对冲操作策略
- **[special-securities-investment-strategies]**: 参与/可转换/附认股权证证券策略比较
- **[privileged-securities-analysis]**: 附权证券类型识别与投资价值
- **[warrant-definition-attributes]**: 认股权证基本属性定义
- **[warrants-speculative-assessment]**: 认股权证投机吸引力评估

### 财务报表分析
- **[earnings-analysis]**: 盈利能力分析框架
- **[earnings-quality-verification]**: 报告收益真实性验证
- **[earnings-manipulation-detection]**: 收益操纵识别（多版本）
- **[financial-position-validation]**: 财务状况交叉验证
- **[depreciation-analysis-and-adjustment]**: 折旧分析与收益调整
- **[depreciation-red-flags-detection]**: 折旧政策危险信号
- **[inventory-analysis-and-valuation]**: 存货分析与估值
- **[consolidated-statement-analysis]**: 合并报表真实收益分析
- **[book-value-calculation]**: 每股账面价值计算

### 铁路与公共事业分析
- **[railway-financial-health-assessment]**: 铁路公司财务健康综合评估
- **[railroad-comparative-analysis]**: 铁路公司统计比较框架
- **[railway-operational-efficiency-analysis]**: 运营效率与运输密度分析
- **[railroad-bond-credit-analysis]**: 铁路债券信用质量分析
- **[utility-railroad-capital-analysis]**: 公用事业与铁路资本结构分析
- **[utility-bond-depreciation-analysis]**: 公用事业债券折旧验证

### 投机性证券与特殊情形
- **[speculative-capital-structure-investment]**: 投机性资本结构企业投资
- **[speculative-securities-analysis]**: 投机性证券市场行为特征
- **[distressed-securities-liquidation-analysis]**: 困境证券清算分析
- **[special-situation-securities-valuation]**: 特殊情形证券定价
- **[market-overreaction-opportunity-analysis]**: 市场过度反应机会识别
- **[market-anomaly-structure-analysis]**: 市场异常与复杂资本结构

### 公司治理与股东权利
- **[corporate-governance-shareholder-rights]**: 治理结构与股东权利分析
- **[shareholder-rights-dividend-policy]**: 基于股东权利的股息政策
- **[managerial-stock-price-fiduciary-duty]**: 管理者股价受托责任
- **[undervalued-stock-remedies]**: 低估股票纠正措施设计
- **[shareholder-governance-psychology]**: 股东认知误区与心理陷阱

### 投资理论与方法
- **[investment-philosophy-security-analysis]**: 投资与投机区分
- **[investment-ideology-critique]**: 投资意识形态批判
- **[security-substance-classification]**: 证券实质分类法
- **[rational-prediction-boundaries]**: 理性预测边界
- **[fundamental-analysis-reasoning-framework]**: 基本面分析推理框架
- **[investment-analysis-methodology-evaluation]**: 分析方法有效性评估

## 使用指南

### 如何调用技能
1. **直接指定技能名称**：当明确知道需要哪个技能时，直接引用技能名称
2. **描述任务场景**：描述当前面临的分析任务，系统将匹配最合适的技能
3. **使用触发关键词**：每个技能都有特定的触发关键词，可在对话中自然提及

### 选择技能的原则
- **固定收益证券** → 优先使用债券分析类技能
- **股权估值** → 根据普通股/优先股选择相应技能
- **财务异常检测** → 使用收益质量验证或操纵检测技能
- **行业特定分析** → 选择铁路、公共事业、采矿等专项技能
- **复杂结构** → 使用控股公司、金字塔结构、合并报表等技能

### 技能组合使用
复杂分析任务通常需要多个技能协同：
- 债券投资分析 = 安全性评估 + 覆盖率计算 + 行业特定标准
- 普通股估值 = 盈利能力分析 + 资产价值评估 + 投资标准验证
- 财务尽职调查 = 收益质量验证 + 折旧分析 + 操纵检测

> **注意**：本技能集基于1934年原版《证券分析》及后续版本，部分历史数据和行业标准具有特定时代背景，实际应用时需结合当前市场环境进行调整。
```