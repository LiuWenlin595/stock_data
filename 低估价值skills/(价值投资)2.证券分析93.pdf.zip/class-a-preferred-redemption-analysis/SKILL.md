---
name: class-a-preferred-redemption-analysis
description: Evaluate redemption features and sinking fund provisions for Class A stocks that have preferred security substance (fixed dividends, priority in liquidation). Use when analyzing callable preferred securities, assessing duration risk, or reviewing mandatory redemption schedules.
---

# A类优先股赎回与偿债基金分析

## 适用场景
- 分析具有优先股实质的A类股票（固定股息、优先清算权）时
- 评估可赎回证券的退出机制风险时
- 需要计算证券久期（Duration）和收益率调整时
- 审查设有偿债基金的证券的信用保护时

## 核心工作流程

### 第一步：确认证券实质
验证A类股票是否具有优先股特征：
- 固定股息率
- 优先清算权
- 累积或非累积股息条款

**约束**：仅适用于具有优先股实质的A类股票，不适用于纯普通股性质的A类。

### 第二步：赎回条款分析
核查发行公司的回购权利：

1. **赎回权识别**
   - 确认是否为任意赎回（Optional Redemption）或强制赎回（Mandatory Redemption）
   - 记录赎回起始日（Call Date）
   - 核实赎回通知期要求

2. **经济影响评估**
   - 确定赎回价格（通常高于面值，含溢价）
   - 评估利率下降环境下的再投资风险
   - 计算赎回收益率（Yield to Call）

3. **典型案例参考**
   - 通用户外广告公司（General Outdoor Advertising）A类股票

### 第三步：偿债基金条款审查
评估本金保障机制：

1. **机制识别**
   - 确认年度偿债比例（如每年赎回面值的5%）
   - 识别执行方式：抽签赎回 vs 公开市场购买 vs 现金拨付信托
   - 检查是否允许加速偿债（Doubling Option）

2. **经济实质分析**
   - 偿债基金降低到期一次性偿付风险
   - 保护优先股股东本金安全
   - 评估与赎回条款的关系（重叠或互斥）

3. **典型案例**
   - 奥斯汀·尼科尔斯公司（Austin Nichols）A类股票

### 第四步：估值模型调整
根据条款调整投资分析：
- **久期调整**：赎回条款缩短预期久期
- **收益率曲线**：分别计算Yield to Maturity和Yield to Call
- **风险指标**：赎回风险对投资者为再投资风险；偿债基金为违约风险降低

## 关键检查点
- 赎回价格及溢价幅度
- 年度偿债基金比例
- 偿债基金与赎回权的交互影响
- 通知期长度