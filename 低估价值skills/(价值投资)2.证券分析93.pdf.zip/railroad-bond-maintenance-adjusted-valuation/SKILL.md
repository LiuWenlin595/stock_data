---
name: railroad-bond-maintenance-adjusted-valuation
description: Compare railroad company senior lien bonds by normalizing maintenance expense differences to identify mispriced securities. Use when analyzing railroad bonds with varying maintenance accounting policies, comparing bonds with different market prices but similar coverage, or assessing true interest coverage after maintenance normalization.
---

# 铁路优先留置权债券维护费用调整估值法

## 适用场景
- 比较两只售价不同的铁路公司优先留置权债券时
- 发现低价债券的维修费用显著高于高价债券时
- 需要透过会计政策差异看真实偿付能力时
- 评估1920年代铁路债券或类似历史/现代案例时

## 核心工作流程

### 第一步：识别比较对象
确定可比债券对（同行业、相似线路条件）：
- 记录债券A市场价格（如密苏里-堪萨斯-德克萨斯铁路公司/MKT）
- 记录债券B市场价格（如圣路易斯-旧金山铁路公司/Frisco）
- 确认两者均为优先留置权债券

### 第二步：量化维护费用差异
1. 提取债券A年度维修费用支出
2. 提取债券B年度维修费用支出
3. 确认差异程度（"多得多"或显著差异）
4. 分析差异来源：会计政策差异或线路实际状况差异

### 第三步：标准化收益调整
对维修费用差异进行"适当的考虑"（proper consideration）：

1. **标准化收益计算**
   - 将两家公司收益调整至标准化维护费用水平
   - 消除会计处理差异对可比性的影响

2. **计算调整后覆盖倍数**
   - 获取支付固定利息前的收益数据（基准年如1921年）
   - 应用标准化维护费用后的收益
   - 计算：`调整后覆盖倍数 = 标准化后收益 / 固定利息`

### 第四步：重新评估安全性
- 比较调整后覆盖倍数
- 识别市场定价错误：低价债券可能实际安全性更高
- 评估优越地位（superior position）是否显著

### 第五步：投资决策
- 若调整后低价债券覆盖倍数更高 → 识别为价值机会
- 记录结论："售价较低但安全性更高"

## 关键变量
- 维修费用差额
- 1921年（或基准年）收益数据
- 固定利息金额
- 调整后覆盖倍数

## 注意事项
- 仅适用于具有可比性的同行业债券比较
- 基于历史收益的推断可能不适用于经济环境剧变时期
- 需考虑线路物理状况差异（非仅会计差异）