---
name: working-capital-covenant-compliance
description: Monitor compliance with working capital maintenance covenants requiring minimum net working capital thresholds and current ratio standards. Use when reviewing bond indentures for manufacturing companies, assessing liquidity-based covenant compliance, or triggering covenant violation alerts.
---

# 营运资金维持与流动性保障条款监控

## 适用场景
- 监控债券存续期间的持续合规要求时
- 评估工业或制造业公司的流动性契约时
- 需要触发净营运资金或流动比率违约警报时
- 分析债券相对流动性覆盖率时

## 核心工作流程

### 第一步：双重阈值检验
必须同时满足以下两个条件：

**条件A：净营运资金底线**
- 计算：`净营运资金 = 流动资产 - 流动负债`
- 阈值：必须持续保持 > $2,000,000
- 若低于此阈值，触发契约违约

**条件B：流动比率要求**
- 计算：`流动比率 = 流动资产 / 流动负债`
- 阈值：必须 ≥ 2.0（即流动资产达到流动负债的两倍以上）
- 若低于2:1，违反契约

### 第二步：数据提取与计算
1. 获取当前流动资产总额
2. 获取当前流动负债总额
3. 计算净营运资金
4. 计算流动比率
5. 对比未清偿债券金额，评估相对覆盖率

### 第三步：合规状态判定
- **完全合规**：净营运资金 > $2M 且 流动比率 ≥ 2.0
- **违约风险**：任一条件不满足
- **充足性评估**：检查净营运资金是否为未清偿债券的2.5倍以上（如1927年案例：$3,698,000净营运资金 vs $1,460,000债券）

## 监控频率
- 持续监控：债券存续期间任何时点均需满足
- 季报/年报审查节点
- 重大资产变动事件后即时复核

## 关键指标
- 净营运资金底线：$2,000,000
- 流动比率底线：2.0:1
- 理想覆盖率：净营运资金 ≥ 2.5×未清偿债券