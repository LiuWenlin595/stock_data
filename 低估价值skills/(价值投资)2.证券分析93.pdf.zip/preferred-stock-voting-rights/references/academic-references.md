# 学术研究参考

## 主要文献

**W. H. S. 史蒂芬斯**
- 文章：《股东的表决权与表决权控制的集中化》（The Voting Rights of Stockholders and the Concentration of Voting Control）
- 期刊：《经济学季刊》（The Quarterly Journal of Economics）
- 卷期：第40卷
- 时间：1926年5月
- 页码：353-392页

**W. Z. 李普利**
- 书籍：《铁路：金融与组织》（Railroads: Finance and Organization）
- 出版地：纽约
- 时间：1915年
- 页码：524-532页

## 历史案例时期
- 典型案例时间跨度：1900-1926年
- 法律机制基础：公司章程特殊条款与州公司法