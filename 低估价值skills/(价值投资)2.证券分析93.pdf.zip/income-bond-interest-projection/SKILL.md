---
name: income-bond-interest-projection
description: Forecast interest payment likelihood for income bonds or adjustment bonds based on available earnings and minimum allocation policies. Use when evaluating contingent interest bonds, assessing payment probabilities for variable rate bonds, or analyzing earnings-based distribution obligations.
---

# 收益债券利息支付预期评估

## 适用场景
- 评估收益债券或调整债券的近期利息支付可能性时
- 分析具有明确收益分配政策（如50%规则）的证券时
- 比较不同收入债券的支付前景时（如5% vs 6%利率）
- 基于历史收益数据预测未来支付时

## 核心工作流程

### 第一步：确定收益基准
1. 获取可用于支付次级债券利息的收益数据（Available for Interest）
2. 使用上一年度实际收益作为计算基础（如1921年数据）
3. 确认收益计算口径与契约一致

### 第二步：应用分配比例规则
确认公司政策或契约规定的最低分配比例：

**标准规则**：至少一半（at least half）可用于支付利息的收益将实际用于利息支付。

计算公式：
```
预期利息支付额 = MIN(契约利息金额, 50% × 可用收益)
预期支付率 = 预期利息支付额 / 契约利息金额 × 100%
```

### 第三步：评估足额支付可能性
- 若 `50% × 可用收益 ≥ 契约利息金额` → 可能收到全额利息
- 若 `50% × 可用收益 < 契约利息金额` → 仅收到部分利息
- 记录结论：如"收入债券持有者今年可能将收到5%的足额利息"

### 第四步：敏感性分析
- **收益下降情景**：支付比例维持50%，但绝对金额减少
- **收益上升情景**：可能支付超过契约利率或建立偿债基金
- **比较分析**：对比不同债券（如5%调整债券 vs 6%收入债券但永不累积）

## 关键变量
- 可用收益金额（基准年）
- 最低分配比例（通常50%）
- 契约利率（如5%）
- 债券面值（计算绝对利息）

## 约束条件
- 仅适用于有明确收益分配政策的收入/调整债券
- 基于历史收益的预测假设未来收益水平相似
- 不适用于固定利息债券（straight bonds）的支付预测