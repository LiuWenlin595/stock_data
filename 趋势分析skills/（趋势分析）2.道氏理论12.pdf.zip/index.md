```markdown
# 金融市场分析与道氏理论技能集

本技能集基于专业金融书籍构建，涵盖了从经典道氏理论到现代市场机制的广泛知识。旨在帮助用户深入理解金融市场运作原理、掌握投机交易的核心纪律、分析经济周期规律，并处理特定的证券法规合规问题。通过这些技能，Claude 能够协助用户进行精准的市场趋势判断、风险控制、交易策略制定以及复杂的证券登记披露工作。

## Available Skills

| Skill | Description | Use When |
|-------|-------------|----------|
| [uk-securities-registration-disclosure](uk-securities-registration-disclosure/SKILL.md) | 处理证券在伦敦股票交易所交易前的登记与披露程序 | 需要在伦敦交易所上市交易，且需要依据1908年《公司法》完成萨默塞特事务所登记核准时 |
| [market-manipulation-fundamentals](market-manipulation-fundamentals/SKILL.md) | 理解为什么主要市场运动无法被操纵、市场定价机制以及股市晴雨表的预测原理 | 质疑市场被操纵、评估市场运动成因或预测未来商业状况时 |
| [speculation-trading-principles](speculation-trading-principles/SKILL.md) | 应用道氏理论进行投机交易的核心原则，包括交易纪律、风险管理、心理陷阱规避和资金管理 | 制定交易策略、管理持仓、控制风险或纠正交易错误时 |
| [dow-theory-data-requirements](dow-theory-data-requirements/SKILL.md) | 理解和应用道氏理论所需的核心数据类型及其用途 | 设置道氏理论分析系统、收集市场数据或验证数据完整性时 |
| [dow-theory-fundamentals](dow-theory-fundamentals/SKILL.md) | 理解道氏理论的核心概念、起源、历史发展及其局限性 | 学习道氏理论基础、解释理论框架或评估理论适用性时 |
| [technical-pattern-reliability](technical-pattern-reliability/SKILL.md) | 理解双顶和双底形态的低可靠性，避免将其作为主要交易信号 | 识别到双顶或双底形态并考虑交易时 |
| [economic-cycle-analysis](economic-cycle-analysis/SKILL.md) | 分析经济周期规律及其与人类本性的关系，预测经济从繁荣到萧条的转折 | 评估当前经济所处周期阶段、分析长期市场变化或预测经济转折点时 |
| [dual-index-confirmation](dual-index-confirmation/SKILL.md) | 应用道氏理论最核心的原则——工业和铁路两个平均股价指数必须相互确认 | 判断市场趋势、确认趋势反转或做出交易决策时必须使用 |
| [line-formation-analysis](line-formation-analysis/SKILL.md) | 识别、分析和交易道氏理论中的线态窄幅盘整形态 | 市场在窄幅区间内波动数周、需要判断收集或派发阶段、或等待突破信号时 |
| [market-distortion-analysis](market-distortion-analysis/SKILL.md) | 识别外部制度性因素（如税收政策）对市场信号的扭曲效应 | 市场出现异常波动且无法由基本商业因素解释时 |
| [market-mechanisms](market-mechanisms/SKILL.md) | 理解专业投机者在金融市场中的功能定位以及股票交易所专家的运作机制 | 学习市场结构、理解交易机制或评估投机者角色时 |
| [wartime-currency-strength-prediction](wartime-currency-strength-prediction/SKILL.md) | 基于国家债务、财政状况及生产率预测战争时期本币相对强势程度 | 分析大规模战争冲突对主权货币汇率影响、评估国债市场时 |

## Quick Navigation

### 道氏理论核心
- **dow-theory-fundamentals**: 理解道氏理论的核心概念、起源、历史发展及其局限性。
- **dow-theory-data-requirements**: 理解和应用道氏理论所需的核心数据类型及其用途。
- **dual-index-confirmation**: 应用工业和铁路双指数确认原则判断市场趋势。
- **line-formation-analysis**: 识别和交易线态窄幅盘整形态，判断收集或派发阶段。
- **speculation-trading-principles**: 应用道氏理论进行投机交易，涵盖纪律、风险与资金管理。

### 市场机制与行为
- **market-manipulation-fundamentals**: 理解主要市场运动不可被操纵的原理及股市晴雨表功能。
- **market-mechanisms**: 理解专业投机者功能及交易所专家运作机制。
- **market-distortion-analysis**: 识别税收等外部制度因素对市场信号的扭曲。
- **technical-pattern-reliability**: 警惕双顶和双底形态的低可靠性，避免误判。

### 宏观经济分析
- **economic-cycle-analysis**: 分析经济周期规律，预测繁荣与萧条的转折点。
- **wartime-currency-strength-prediction**: 预测战争时期基于债务和生产率的主权货币汇率变化。

### 法规与合规
- **uk-securities-registration-disclosure**: 处理伦敦股票交易所上市前的证券登记与全面披露程序。

## How to Use
这些技能旨在作为特定领域的专家助手。当您提出与金融市场分析、交易策略或法规合规相关的问题时，Claude 将自动识别并调用最相关的技能。例如：
- 如果您询问“现在的市场趋势是否反转？”，Claude 将使用 **dual-index-confirmation**。
- 如果您需要制定交易计划，Claude 将结合 **speculation-trading-principles** 和 **line-formation-analysis**。
- 如果您涉及伦敦上市业务，Claude 将调用 **uk-securities-registration-disclosure**。
您可以直接描述您的场景或问题，系统会自动路由至正确的知识库。
```