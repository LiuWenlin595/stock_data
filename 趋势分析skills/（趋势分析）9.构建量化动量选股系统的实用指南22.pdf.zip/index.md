```markdown
# 量化动量投资技能集 (Quantitative Momentum Investment Skills)

本技能集基于专业量化投资著作，系统涵盖动量投资策略的完整知识体系，从基础概念、计算方法到组合构建与风险管理。帮助用户构建基于行为金融学原理的量化选股系统，实现价值与动量因子的有效整合，并掌握机构行为模式与季节性效应等进阶策略。

## Available Skills

| Skill | Description | Use When |
|-------|-------------|----------|
| [momentum-investment-fundamentals](momentum-investment-fundamentals/SKILL.md) | 理解动量投资核心概念、学术起源、与成长投资的本质区别，作为价值投资的补充策略 | 需要区分动量与成长投资、理解动量策略理论基础时 |
| [momentum-calculation-methods](momentum-calculation-methods/SKILL.md) | 计算股票动量值，区分时间序列与横截面动量，构建短期反转与中期动量策略 | 需要量化股票动量、构建动量选股策略、理解不同计算方式时 |
| [momentum-investment-strategy](momentum-investment-strategy/SKILL.md) | 构建并管理基于价格动量的股票投资组合，选择过去12个月表现优异的股票，区分动量质量 | 量化选股、构建中大盘股组合、需要月度/季度再平衡时 |
| [quantitative-momentum-system](quantitative-momentum-system/SKILL.md) | 构建完整量化动量选股系统，包括可投资领域配置、动量质量筛查（FIP算法）、路径平滑度优化 | 需要系统化构建动量选股策略，实施全流程量化管理时 |
| [fundamental-momentum-strategy](fundamental-momentum-strategy/SKILL.md) | 计算并应用基本面动量指标（SUE和CAR3）构建盈余动量投资组合 | 基于盈余公告信息选股，识别基本面驱动的价格动量，结合价格与基本面动量时 |
| [momentum-factor-risk-return-comparison](momentum-factor-risk-return-comparison/SKILL.md) | 比较价格动量与盈余动量（SUE、CAR3）的风险收益特征，评估风险调整后表现 | 需要评估不同动量策略表现、选择最优动量因子、进行风险管理时 |
| [momentum-strategy-evaluation](momentum-strategy-evaluation/SKILL.md) | 评估动量策略的长期稳健性、验证不同市场有效性、识别彩票型股票风险 | 需要验证动量策略可持续性、评估策略表现、识别潜在风险时 |
| [value-momentum-combined-portfolio](value-momentum-combined-portfolio/SKILL.md) | 构建价值与动量等权重综合投资组合，降低单一策略长期表现不佳的频率，提升投资者坚持度 | 需要构建适应各种市场环境的长期股票组合，降低策略单一性风险时 |
| [value-momentum-portfolio-integration](value-momentum-portfolio-integration/SKILL.md) | 基于HML因子载荷分析，构建价值与动量的整合投资组合，评估因子间分散化收益 | 需要结合价值和动量因子，选择最适合与价值策略搭配的动量因子时 |
| [value-momentum-portfolio-optimization](value-momentum-portfolio-optimization/SKILL.md) | 利用均值方差优化扩展效率边界，配置50/50价值动量组合，理解再平衡频率差异 | 需要优化投资组合、构建多元化价值动量策略、进行资产配置时 |
| [concentrated-portfolio-construction](concentrated-portfolio-construction/SKILL.md) | 构建集中高信念组合，避免"多元恶化"和积极管理型指数投资陷阱，获取真正Alpha | 追求高Alpha、愿意承担极端相对表现风险、基金规模可控时 |
| [momentum-risk-management](momentum-risk-management/SKILL.md) | 管理动量投资组合风险，包括止损规则、回撤监控及阈值选择，平衡收益与下行保护 | 需要控制动量策略高回撤风险，实施每日或月度风控机制时 |
| [trend-following-risk-management](trend-following-risk-management/SKILL.md) | 应用趋势跟踪规则（标普500与12个月移动均线比较）决定股债配置，管理组合风险 | 需要降低最大回撤、防范尾部风险、作为每日止损的简化替代方案时 |
| [behavioral-finance-momentum-explanation](behavioral-finance-momentum-explanation/SKILL.md) | 理解动量效应的行为金融学解释机制，包括反应不足与反应过度、套利限制、职业风险 | 需要解释动量为何有效、评估策略可持续性、理解主动投资成功因素时 |
| [behavioral-finance-framework](behavioral-finance-framework/SKILL.md) | 应用行为金融学框架分析市场无效性和错误定价机会，解释价格偏离基本面原因 | 需要解释市场价格偏离、评估套利限制、判断策略理论基础时 |
| [sustainable-active-investing-framework](sustainable-active-investing-framework/SKILL.md) | 基于错误定价和套利成本评估主动投资策略（动量、价值）的长期可持续性 | 判断策略未来有效性、向客户解释异象持续存在原因、设计可持续量化系统时 |
| [long-term-reversal-strategy](long-term-reversal-strategy/SKILL.md) | 执行长期动量反转策略，买入过去5年输家、卖出赢家，利用行为偏差导致的过度反应 | 构建3-5年持有期的逆向投资组合，利用长期过度反应时 |
| [absolute-momentum-strategy](absolute-momentum-strategy/SKILL.md) | 基于绝对动量阈值（历史百分位数）构建多空组合，探索替代性构建方法 | 需要探索动量策略替代构建方法时（注意：存在极端市场集中缺陷） |
| [momentum-seasonality-strategy](momentum-seasonality-strategy/SKILL.md) | 利用动量策略的季节性效应（橱窗装饰和税损卖盘）优化动量策略时机 | 需要提升动量策略收益、把握年末年初季节性机会时 |
| [institutional-behavior-analysis](institutional-behavior-analysis/SKILL.md) | 识别和利用机构行为模式（橱窗装饰、税收激励交易）优化投资策略 | 理解动量季节性来源、避开机构集中交易时段、利用年末年初异象时 |
| [statistical-inference-rigor](statistical-inference-rigor/SKILL.md) | 确保统计推断严谨性，防止从样本数据过度泛化到总体，避免超出数据覆盖范围的断言 | 基于特定数据集（调查样本、特定平台数据）得出结论，需要确保统计严谨性时 |
| [book-publication-metadata](book-publication-metadata/SKILL.md) | 提取和结构化图书出版元数据，包括标题、作者、译者、出版社、ISBN等信息 | 处理图书文档、创建书目记录时 |

## Quick Navigation

### 核心动量策略 (Core Momentum Strategies)
- **[momentum-investment-fundamentals]**: 理解动量投资基础概念与学术起源
- **[momentum-calculation-methods]**: 掌握动量计算方法（时间序列/横截面）
- **[momentum-investment-strategy]**: 构建标准价格动量投资组合（12个月窗口）
- **[quantitative-momentum-system]**: 构建完整量化动量系统（含FIP质量筛查）
- **[fundamental-momentum-strategy]**: 基于SUE/CAR3构建盈余动量策略
- **[momentum-factor-risk-return-comparison]**: 比较价格动量与盈余动量特征
- **[momentum-strategy-evaluation]**: 评估策略稳健性与识别彩票型股票风险

### 组合构建与优化 (Portfolio Construction)
- **[value-momentum-combined-portfolio]**: 构建50/50价值动量等权重组合
- **[value-momentum-portfolio-integration]**: 基于HML因子载荷整合价值与动量
- **[value-momentum-portfolio-optimization]**: 均值方差优化与效率边界扩展
- **[concentrated-portfolio-construction]**: 构建高信念集中组合避免"多元恶化"

### 风险管理 (Risk Management)
- **[momentum-risk-management]**: 动量组合止损规则与回撤监控
- **[trend-following-risk-management]**: 基于12个月移动均线的趋势跟踪风控

### 行为金融学与理论 (Behavioral Finance & Theory)
- **[behavioral-finance-momentum-explanation]**: 理解反应不足、过度反应与套利限制
- **[behavioral-finance-framework]**: 分析市场无效性与错误定价机会
- **[sustainable-active-investing-framework]**: 评估策略长期可持续性（错误定价+套利成本）

### 进阶策略 (Advanced Strategies)
- **[long-term-reversal-strategy]**: 5年期长期反转策略（买入长期输家）
- **[absolute-momentum-strategy]**: 基于历史百分位数的绝对动量多空策略
- **[momentum-seasonality-strategy]**: 利用年末橱窗装饰与税损卖盘的季节性效应
- **[institutional-behavior-analysis]**: 识别机构行为模式优化交易时机

### 数据与方法 (Data & Methods)
- **[statistical-inference-rigor]**: 确保统计推断严谨性，避免过度泛化
- **[book-publication-metadata]**: 提取图书出版元数据信息

## How to Use

在Claude Code中，根据当前任务需求选择合适的技能：

1. **策略构建**：从核心动量策略类别选择，先掌握基础概念（fundamentals），再选择具体计算方法（calculation-methods）或完整系统（quantitative-momentum-system）

2. **组合管理**：如需结合价值因子，使用value-momentum相关技能；如需风险控制，使用风险管理类别技能

3. **理论解释**：当需要向客户解释策略原理或评估策略可持续性时，使用行为金融学类别技能

4. **进阶优化**：考虑季节性效应（seasonality）或机构行为（institutional-behavior）进行时机优化

使用格式：引用技能路径 `skill-name/SKILL.md` 或描述需求让Claude自动选择合适技能。
```