---
name: Historical Stock Issuance Comparison
description: Compare the essential differences between early 20th-century stock issuances (e.g., U.S. Steel vs. Amalgamated Copper) to evaluate issuance difficulty, market conditions, and manipulation strategy complexity. Use this skill when analyzing historical financial cases from the 1900s Wall Street context involving public demand, capital structure integrity, and market creation versus reconstruction.
---

# Historical Stock Issuance Comparison

Use this skill to assess and contrast two types of stock issuance scenarios prevalent in early 1900s Wall Street, particularly exemplified by U.S. Steel and Amalgamated Copper. Apply it only within the historical context before modern securities regulation.

## When to Use
- You are evaluating why certain stock offerings succeeded while others faced extreme difficulty.
- You need to understand how market sentiment, public demand, and perceived capital “water content” influenced issuance strategy.
- The case involves a comparison between creating a new market versus rebuilding a damaged one.

## How to Execute

1. **Identify the stock issuance case** and confirm it falls within the pre-regulation era (circa 1900–1910s).
2. **Assess three core variables**:
   - **Public demand strength**: Is there strong, organic investor interest?
   - **Capital water content**: Is the share capital reasonably valued or inflated with unjustified premiums?
   - **Initial market state**: Does the operation require *creating* a market or *repairing* a ruined one?
3. **Classify the issuance type**:
   - If public demand is high, capital is sound, and the task is market creation → **U.S. Steel-type issuance** (strategic, exemplary).
   - If public trust is broken, capital structure is suspect, and the market must be rebuilt → **Amalgamated Copper-type issuance** (artistic, highly challenging).
4. **Interpret strategic implications**: U.S. Steel operations reflect calculated market orchestration; Amalgamated Copper reflects crisis-level financial artistry.

> ⚠️ Do not apply this framework to modern regulated markets. It is valid only for historical analysis of early Wall Street practices.