---
name: Express Natural Wonders with Authentic Feeling
description: Use this skill when a writer, speaker, or observer needs to vividly and truthfully describe a natural wonder (e.g., the Grand Canyon) based on direct experience and genuine emotional response. Apply it only when the person has personally witnessed the phenomenon and seeks to convey its impact without resorting to clichés like “indescribable.” Do not use for secondhand accounts, exaggerations, or fictionalized portrayals.
---

# Express Natural Wonders with Authentic Feeling

## When to Use
Use this skill when:
- You are describing a real, objectively existing natural phenomenon (e.g., mountains, canyons, auroras).
- You have directly experienced the scene—not through photos, stories, or media alone.
- You feel a genuine emotional or spiritual response and want to articulate it clearly.
- Your goal is to help others feel the same awe through your words.

Do **not** use this skill if:
- Your description relies on hearsay or imagination.
- You default to vague phrases like “beyond words” or “too beautiful to describe.”
- You intentionally embellish or fabricate details.

## How to Execute
1. **Confirm direct observation**: Ensure you have personally witnessed the natural wonder.
2. **Reflect on your inner response**: Identify the specific emotions, thoughts, or revelations the scene evoked—awe, humility, joy, etc.
3. **Avoid clichés**: Replace empty expressions (e.g., “indescribable”) with concrete, sensory-rich language that mirrors your actual experience.
4. **Speak honestly**: Describe what you truly felt, even if it seems simple or unconventional.
5. **Test clarity**: Ask whether your description would allow someone else to grasp the emotional weight of the scene.

> **Core Principle**: Saying something is “indescribable” usually reflects a failure of honesty or expressive effort—not an inherent limit of language.