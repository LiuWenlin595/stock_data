```markdown
# 专业股票交易与市场分析技能集

本技能集源自经典金融著作，涵盖了从市场趋势分析、交易心理建设到复杂的市场操纵与防御策略的完整体系。这些技能旨在帮助用户像专业作手一样思考，识别市场陷阱，管理风险，并制定有效的交易计划。无论您是投机者、投资者还是市场分析师，这些工具都能为您提供深度的市场洞察和实战指导。

## Available Skills

| Skill | Description | Use When |
|-------|-------------|----------|
| [concentrated-ownership-risk-management](concentrated-ownership-risk-management/SKILL.md) | 管理股权过度集中风险、建立联合做市协议、防范背信行为 | 操盘项目、内幕集团控股股票、高集中度股权结构、联合操盘集团 |
| [market-manipulation-and-promotion-strategies](market-manipulation-and-promotion-strategies/SKILL.md) | 市场炒作与操纵策略，包括战略与战术区分、市场激活与流动性吸引 | 股票作手、市场操盘手、需要大量买卖股票而不引起价格剧烈波动的场景 |
| [sector-trend-stock-selection](sector-trend-stock-selection/SKILL.md) | 在牛市中基于板块整体表现进行个股选择和持仓调整的策略 | 已确认处于牛市环境、存在明确板块轮动特征的市场场景 |
| [profit-taking-discipline](profit-taking-discipline/SKILL.md) | 执行"落袋为安"的利润兑现纪律 | 股票操盘项目、认购权变现、巨额账面利润且市场条件有利时 |
| [insider-non-support-bearish-signal](insider-non-support-bearish-sKILL.md) | 识别当股价走势疲软时内部人士未进场买入支撑的利空信号 | 股价下跌或横盘且内部人士没有在市场上买入自己的股票时 |
| [professional-trading-psychology-and-attitude](professional-trading-psychology-and-attitude/SKILL.md) | 专业交易者的习惯性态度，核心是追求正确而非利润 | 长期市场经验、建立系统化交易方法、需要克服人性贪婪和恐惧 |
| [investor-speculator-stratified-positioning](investor-speculator-stratified-positioning/SKILL.md) | 针对不同类型的市场参与者（投资者或投机者）制定差异化销售策略 | 新上市股票、长期低迷股票的市场定位转换，以及操盘手在不同阶段选择目标客群 |
| [market-liquidity-testing](market-liquidity-testing/SKILL.md) | 通过试探性交易订单测试市场流动性和承接力 | 大宗商品交易或大额股票交易时，需要验证市场趋势强度或判断市场能否吸纳大额卖单 |
| [pledged-stock-margin-call-defense](pledged-stock-margin-call-defense/SKILL.md) | 分析维持价格机制的成本效益，制定质押股票接近平仓线时的最优解脱策略 | 质押股票借款人面临银行追加保证金或强制平仓风险 |
| [insider-behavior-analysis-and-defense](insider-behavior-analysis-and-defense/SKILL.md) | 内线行为分析与防御策略，识别内线吸筹/出货、防御市场操纵 | 需要识别内线吸筹/出货、防御市场操纵、判断价格下跌真实原因 |
| [market-direction-flexibility](market-direction-flexibility/SKILL.md) | 保持市场方向无偏见，灵活转换多头和空头仓位 | 职业交易员、日内交易者、趋势跟踪者，市场发出反向信号时 |
| [costless-price-lifting-via-rumors](costless-price-lifting-via-rumors/SKILL.md) | 利用操作者的市场声誉和精心设计的谣言传播，在不投入实际资金的情况下拉升股价 | 操作者拥有极高市场声誉、股票长期低迷且需要创造买盘但不愿直接投入资金 |
| [z-library-access](z-library-access/SKILL.md) | 帮助用户访问 Z-Library 数字图书馆平台获取知识资源 | 需要查找学术文献、图书或遇到 Z-Library 域名无法访问时 |
| [stock-behavior-diagnosis](stock-behavior-diagnosis/SKILL.md) | 股票行为诊断，分析股票行为是否符合历史趋势 | 观察股票波动、需要分析股票行为是否符合历史趋势时 |
| [modern-market-environment-analysis](modern-market-environment-analysis/SKILL.md) | 现代股市投机难度增加的原因分析，对比历史数据与现状 | 投资者进入现代股市、需要认识到投机难度增加的场景 |
| [investment-vs-speculation-distinguishing-criteria](investment-vs-speculation-distinguishing-criteria/SKILL.md) | 投资与投机的本质区分标准，基于基本面确定性、时间跨度和仓位管理 | 长期商品投资者、基本面交易者、套期保值者需要将交易定性为投资或投机 |
| [ipo-market-timing-selection](ipo-market-timing-selection/SKILL.md) | 确定新股发行的最佳时机，通过识别市场饱和信号避免在非理性繁荣期发行 | 新股发行前的市场时机评估、承销策略制定以及发行窗口选择 |
| [trend-following-and-least-resistance](trend-following-and-least-resistance/SKILL.md) | 趋势跟随与最小阻力线原理，判断市场趋势方向 | 需要判断市场趋势方向、确定交易方向时 |
| [call-option-compensation-structuring](call-option-compensation-structuring/SKILL.md) | 将现金佣金转换为绩效挂钩的认购权，实现操盘手与客户利益深度对齐 | 报酬结构设计、认购权、对赌式报酬、股票拉升服务、利益对齐机制 |
| [execution-gap-resolution](execution-gap-resolution/SKILL.md) | 识别并解决市场判断正确但无法执行获利的执行鸿沟 | 对市场趋势判断准确但因外部因素无法自主执行交易时 |
| [family-capital-protection](family-capital-protection/SKILL.md) | 建立不可撤销信托保护家庭资本，隔离交易风险 | 高净值交易者、家庭支柱、经历过破产的交易者还清债务后 |
| [progressive-subscription-rights-agreement](progressive-subscription-rights-agreement/SKILL.md) | 专业操盘手与客户之间建立递进式认购权报酬机制的合作协议 | 聘请操盘手的内部集团或专业操盘手接受委托，设定基于股价表现的阶梯式认购权 |
| [debt-repayment-strategy](debt-repayment-strategy/SKILL.md) | 通过一次性全额清偿所有债务来重建商业信用和声誉 | 负债交易者恢复交易能力、有持续盈利、债权人已豁免部分债务且市场条件允许时 |
| [market-analysis-principles](market-analysis-principles/SKILL.md) | 识别股价下跌的真正原因，避免被"空头打压"的借口误导 | 观察到股价长期下跌、听到"空头打压"的解释、需要判断股票真实价值时 |
| [trading-psychology-and-philosophy](trading-psychology-and-philosophy/SKILL.md) | 交易心理与哲学管理，管理心理状态、避免情绪化决策 | 需要管理心理状态、避免情绪化决策、识别并摆脱人际关系陷阱 |
| [commodity-futures-trading-principles](commodity-futures-trading-principles/SKILL.md) | 商品期货交易的基本规律和市场垄断破解策略 | 商品期货（棉花、小麦、玉米、燕麦等）交易、需要基于供求定律而非猜测 |
| [market-manipulation-techniques](market-manipulation-techniques/SKILL.md) | 市场操纵技术，了解股票炒作原理、轧空机制、市场测试方法 | 股票承销集团、内幕集团、操盘手、职业作手 |
| [field-research-management-behavior-analysis](field-research-management-behavior-analysis/SKILL.md) | 宾夕法尼亚荷兰人实地调查法，通过观察管理层无意识行为细节判断公司价值 | 价值投资者、长期投资者、公司调研人员能够直接接触公司管理层 |
| [indirect-attack-via-related-stocks](indirect-attack-via-related-stocks/SKILL.md) | 通过做空持有大量目标股票的关联公司股票，间接打击目标股价 | 目标股票被内线集团明显操纵拉升，且直接做空风险高或头寸已满 |
| [reverse-insider-trading-strategy](reverse-insider-trading-strategy/SKILL.md) | 逆向买入积累筹码，待内幕抛售停止后立即抛出，利用筹码打压市场配合空头操作 | 空头作手、看空后市的交易者和股票期货投机者获得可靠内幕抛售消息时 |
| [bull-market-position-holding](bull-market-position-holding/SKILL.md) | 牛市持仓坚守策略，避免过早离场 | 市场处于牛市阶段、持有股票仓位、收到获利了结建议或担心短期回调时 |
| [position-management-mistakes](position-management-mistakes/SKILL.md) | 仓位管理错误识别与避免，处理同时持有盈利和亏损头寸的情况 | 同时持有盈利头寸和亏损头寸、面临保证金压力或心理压力 |
| [trading-evolution-from-tape-reading-to-fundamental-analysis](trading-evolution-from-tape-reading-to-fundamental-analysis/SKILL.md) | 从技术分析（读盘）向基本面分析（大势研究）的进阶路径 | 交易者寻求突破技术分析局限、建立可持续盈利体系 |
| [bucket-shop-trading-mechanics-and-counter-strategies](bucket-shop-trading-mechanics-and-counter-strategies/SKILL.md) | 理解对赌行交易机制、识别限制性规则、制定套利和反制策略 | 在对赌行交易、需要规避限制或利用跨市场价差 |
| [panic-covering-strategy](panic-covering-strategy/SKILL.md) | 在突发事件导致市场暴跌时立即回补空头仓位锁定利润 | 持有空头仓位且发生计划外突发事件导致市场暴跌时 |
| [range-breakout-trading-strategy](range-breakout-trading-strategy/SKILL.md) | 等待价格突破关键支撑/压力位来捕捉趋势启动 | 市场处于窄幅震荡区间（横盘整理）且方向不明时 |
| [ipo-underwriting-strategic-allotment](ipo-underwriting-strategic-allotment/SKILL.md) | 在牛市超额认购环境下，实施足额配股策略以建立可持续的市场支撑机制 | 股票发行获得超额认购且处于牛市高潮时 |
| [pyramid-trading-method](pyramid-trading-method/SKILL.md) | 帕特·赫恩金字塔交易法，通过小幅加仓和紧密止损获取稳定利润 | 活跃股票交易、具备严格纪律的场景 |
| [technical-breakout-trading](technical-breakout-trading/SKILL.md) | 识别和交易整数关口突破，利用价格重复性规律进行短期交易 | 股价首次突破100/200/300等整数关口，或观察到历史价格模式重复 |
| [event-driven-market-reaction](event-driven-market-reaction/SKILL.md) | 分析重大突发事件的市场反应滞后性，利用基本面最终主导价格的规律 | 发生重大利空事件且市场初期反应平淡或上涨时 |
| [empire-steel-market-making](empire-steel-market-making/SKILL.md) | 执行帝国钢铁式渐进造市操作，通过信托锁定股本控制流通盘，实现从投机股到投资股的转变 | 流动性差的绩优股、内线集团控股70%的股票、市场关注度低的股票 |
| [market-trend-analysis](market-trend-analysis/SKILL.md) | 分析市场总体趋势和形势，判断牛市或熊市方向 | 需要判断市场大势、评估基本面形势、或决定是否建立长期头寸 |
| [independent-trading-philosophy](independent-trading-philosophy/SKILL.md) | 建立和维护独立交易哲学，识别并抵御内幕消息依赖 | 收到他人合伙提议、接触外部专家信息、发现自己依赖消息来源 |
| [market-crisis-identification](market-crisis-identification/SKILL.md) | 识别市场恐慌、流动性危机和系统性风险信号 | 观察到资金池异常、利率飙升、或出现异常融资信号 |
| [order-execution-risk-management](order-execution-risk-management/SKILL.md) | 管理订单执行、头寸退出和风险控制 | 需要快速离场、持有大额头寸、或发现交易错误 |
| [exit-strategies-and-risk-control](exit-strategies-and-risk-control/SKILL.md) | 离场策略与风险控制 | 必须离场、市场走势与预期不符、出现无法解释的异常信号、流动性枯竭 |
| [risk-management-and-loss-assessment](risk-management-and-loss-assessment/SKILL.md) | 正确理解和管理风险，区分正常风险与不可预见事件 | 发生亏损、评估交易结果、面临不可预见事件、需要更新风险清单 |
| [bear-market-shorting-strategy](bear-market-shorting-strategy/SKILL.md) | 熊市放空策略，建立和管理空头头寸 | 判断市场进入熊市、需要建立空头头寸、管理空头仓位 |
| [insider-message-manipulation-detection](insider-message-manipulation-detection/SKILL.md) | 识别内幕消息陷阱、市场操纵手段和内部集团出货策略 | 收到内幕消息、经纪商强力推荐、或股票拆细时 |
| [contrarian-investment-strategies](contrarian-investment-strategies/SKILL.md) | 识别极端市场共识和弱势股，执行逆向投资策略 | 市场出现极端一致的看空/看多共识，或板块中某只股票滞涨 |
| [trading-psychology-discipline](trading-psychology-discipline/SKILL.md) | 管理交易心理状态，保持纪律，避免情绪化决策 | 经历亏损、破产、连续犯错，或产生特定消费需求 |
| [self-awareness-and-emotional-discipline](self-awareness-and-emotional-discipline/SKILL.md) | 建立自我认知，识别人性弱点（特别是自负），管理情感义务对交易的干扰 | 接受他人资金支持、面临人情与利益冲突、分析失败原因 |
| [trading-fundamentals-success-factors](trading-fundamentals-success-factors/SKILL.md) | 理解投机本质、成功要素和炒作条件，建立正确的交易认知 | 进行长期投机活动、评估炒作可行性、或需要建立交易体系 |
| [timing-and-position-building](timing-and-position-building/SKILL.md) | 管理交易时机、建仓策略和止盈纪律 | 准备进行交易、判断出大趋势、或市场出现明确趋势 |
| [bucket-shop-trading](bucket-shop-trading/SKILL.md) | 理解对赌行交易机制、规则和局限性，识别图表分析陷阱 | 需要了解对赌行运作、使用图表辅助交易、或进行周六收盘行情交易 |
| [market-intuition-recognition](market-intuition-recognition/SKILL.md) | 识别和执行交易预感，理解市场直觉的本质 | 产生强烈的、无法解释的买入/卖出冲动，且排除生理不适 |

## Quick Navigation

### 市场分析与趋势判断
- **market-trend-analysis**: 分析市场总体趋势和形势，判断牛市或熊市方向
- **trend-following-and-least-resistance**: 趋势跟随与最小阻力线原理
- **sector-trend-stock-selection**: 在牛市中基于板块整体表现进行个股选择
- **range-breakout-trading-strategy**: 通过价格突破关键支撑/压力位捕捉趋势启动
- **technical-breakout-trading**: 识别和交易整数关口突破
- **event-driven-market-reaction**: 分析重大突发事件的市场反应滞后性
- **market-crisis-identification**: 识别市场恐慌、流动性危机和系统性风险信号
- **stock-behavior-diagnosis**: 分析股票行为是否符合历史趋势

### 交易心理与纪律
- **professional-trading-psychology-and-attitude**: 核心是追求正确而非利润的专业态度
- **trading-psychology-and-philosophy**: 管理心理状态，避免情绪化决策
- **trading-psychology-discipline**: 保持纪律，避免情绪化决策和外部干扰
- **self-awareness-and-emotional-discipline**: 识别人性弱点，管理情感义务对交易的干扰
- **market-intuition-recognition**: 识别和执行交易预感
- **independent-trading-philosophy**: 建立独立交易哲学，抵御内幕消息依赖

### 风险与仓位管理
- **risk-management-and-loss-assessment**: 正确理解和管理风险，区分正常风险与不可预见事件
- **position-management-mistakes**: 识别与避免同时持有盈利和亏损头寸的错误
- **profit-taking-discipline**: 执行"落袋为安"的利润兑现纪律
- **exit-strategies-and-risk-control**: 制定离场策略与风险控制
- **order-execution-risk-management**: 管理订单执行、头寸退出和风险控制
- **family-capital-protection**: 建立不可撤销信托保护家庭资本
- **debt-repayment-strategy**: 通过一次性全额清偿所有债务重建信用

### 市场操纵与内幕分析
- **market-manipulation-techniques**: 了解股票炒作原理、轧空机制、市场测试方法
- **market-manipulation-and-promotion-strategies**: 市场炒作与操纵策略，包括市场激活与流动性吸引
- **insider-behavior-analysis-and-defense**: 识别内线吸筹/出货、防御市场操纵
- **insider-non-support-bearish-signal**: 识别内部人士未进场买入支撑的利空信号
- **insider-message-manipulation-detection**: 识别内幕消息陷阱和内部集团出货策略
- **costless-price-lifting-via-rumors**: 利用声誉和谣言传播在不投入资金的情况下拉升股价
- **concentrated-ownership-risk-management**: 管理股权过度集中风险、建立联合做市协议
- **indirect-attack-via-related-stocks**: 通过做空关联公司股票间接打击目标股价
- **reverse-insider-trading-strategy**: 逆向操作利用内幕抛售消息配合空头操作

### 具体交易策略与战术
- **bull-market-position-holding**: 牛市持仓坚守策略
- **bear-market-shorting-strategy**: 熊市放空策略
- **pyramid-trading-method**: 帕特·赫恩金字塔交易法
- **panic-covering-strategy**: 突发事件导致暴跌时立即回补空头仓位
- **contrarian-investment-strategies**: 识别极端市场共识，执行逆向投资策略
- **timing-and-position-building**: 管理交易时机、建仓策略和止盈纪律
- **market-liquidity-testing**: 通过试探性交易订单测试市场流动性
- **bucket-shop-trading**: 理解对赌行交易机制、规则和局限性
- **bucket-shop-trading-mechanics-and-counter-strategies**: 制定对赌行套利和反制策略

### IPO与做市策略
- **empire-steel-market-making**: 执行帝国钢铁式渐进造市操作，实现从投机股到投资股的转变
- **ipo-market-timing-selection**: 确定新股发行的最佳时机，避免在非理性繁荣期发行
- **ipo-underwriting-strategic-allotment**: 在牛市超额认购环境下实施足额配股策略
- **investor-speculator-stratified-positioning**: 针对投资者或投机者制定差异化销售策略
- **call-option-compensation-structuring**: 将现金佣金转换为绩效挂钩的认购权
- **progressive-subscription-rights-agreement**: 建立递进式认购权报酬机制

### 进阶交易理念
- **trading-evolution-from-tape-reading-to-fundamental-analysis**: 从技术分析向基本面分析的进阶路径
- **investment-vs-speculation-distinguishing-criteria**: 投资与投机的本质区分标准
- **modern-market-environment-analysis**: 现代股市投机难度增加的原因分析
- **field-research-management-behavior-analysis**: 通过观察管理层无意识行为细节判断公司价值
- **market-direction-flexibility**: 保持市场方向无偏见，灵活转换多头和空头仓位
- **execution-gap-resolution**: 解决市场判断正确但无法执行获利的鸿沟
- **trading-fundamentals-success-factors**: 理解投机本质、成功要素和炒作条件

### 工具与资源
- **z-library-access**: 帮助用户访问 Z-Library 数字图书馆平台获取知识资源

## How to Use

这些技能旨在作为专业交易和市场分析的辅助工具。当您面临特定的市场场景、交易决策或心理挑战时，请参考上述目录，找到对应的技能以获取详细的策略指导。

**使用建议：**
1. **场景匹配**：根据当前的市场状况（如牛市、熊市、震荡市）或具体问题（如内幕消息、风险控制），在"Quick Navigation"中查找相关分类。
2. **深度阅读**：点击技能链接进入详细文档，理解其背后的逻辑和适用条件。
3. **综合应用**：许多技能是相互关联的（例如心理纪律与风险控制），建议结合使用以构建完整的交易体系。
4. **批判性思考**：这些技能源自经典著作，应用时请结合现代市场环境和个人实际情况进行调整。
```