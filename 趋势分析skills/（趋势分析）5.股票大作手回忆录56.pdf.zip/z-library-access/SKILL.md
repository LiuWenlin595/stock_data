---
name: z-library-access
description: 帮助用户访问 Z-Library 数字图书馆平台获取知识资源。当用户需要查找学术文献、图书或遇到 Z-Library 域名无法访问时触发使用。适用于研究人员、学生和图书阅读者寻找免费知识资源。
---

# Z-Library 平台访问

## 何时使用

- 用户需要访问 Z-Library 获取图书或学术资源
- 用户报告 Z-Library 域名无法访问，需要替代入口
- 用户询问如何绕过地区网络限制访问该平台

## 执行步骤

### 1. 确认平台定位
Z-Library 是一个数字图书馆平台，定位为 "Your gateway to knowledge and culture. Accessible for everyone."（通往知识和文化的门户，人人皆可访问）。

### 2. 选择主域名访问
根据当前网络环境，从以下可用域名中选择一个尝试访问：

| 域名 | 说明 |
|------|------|
| `z-library.sk` | 主要域名 |
| `z-lib.gs` | 备用域名 |
| `z-lib.fm` | 备用域名 |
| `go-to-library.sk` | 跳转域名 |

**操作指令**：指导用户直接在浏览器地址栏输入上述域名之一。

### 3. 使用辅助渠道（主域名失效时）

若主域名无法访问，启用以下备选方案：

**方案 A：官方 Telegram 频道**
- 搜索并关注 "Z-Library Official" Telegram 频道
- 获取实时更新的可用域名和访问指南

**方案 B：Z-Access 服务**
- 使用平台提供的 Z-Access 代理/镜像服务
- 具体入口可通过 Telegram 频道获取

### 4. 验证访问状态
- 成功访问后，页面应显示 Z-Library 搜索界面
- 若所有域名均无法访问，提示用户检查本地网络环境或使用 VPN

## 注意事项

- 特定域名可能因地区网络限制而无法访问，需尝试多个入口
- 域名可用性随时间变化，优先尝试列表中的第一个域名
- 平台背景信息可参考：[Wikipedia - Z-Library](https://wikipedia.org/wiki/Z-Library)