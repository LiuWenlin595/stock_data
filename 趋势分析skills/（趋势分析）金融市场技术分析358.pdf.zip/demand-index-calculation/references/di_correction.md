由于价格变化百分比 P 通常小于 1，直接使用会导致 SP 或 BP 数值异常放大。因此需对 P 进行修正，常见方法包括：

1. 设定最小变动阈值（如 P_min = 0.001），当 |P| < P_min 时，用 P_min 替代
2. 使用对数收益率替代百分比变动：P = ln(Price_today / Price_yesterday)
3. 引入平滑因子 α：P_corrected = α × P + (1 - α) × P_prev

这些修正确保 DI 值稳定且具有跨资产可比性。