---
name: 涨跌股数线背离预警
description: 计算涨跌股数线（ADL）并检测其与主流指数（如道琼斯工业平均指数）的走势背离，当两者出现分道扬镳时发出趋势可能反转的早期预警信号。在分析市场广度是否验证价格趋势、判断趋势动能强弱或识别潜在反转点时使用本技能。
---

# 涨跌股数线背离预警

## 何时使用
- 当需要评估股票市场广度对主流指数趋势的支持程度时
- 当观察到指数创新高或新低，但不确定趋势是否可持续时
- 当寻找趋势反转的早期技术信号时

## 执行步骤
1. 获取当日上涨股票数量（advancing_stocks）和下跌股票数量（declining_stocks）。
2. 计算净值：net_advances = advancing_stocks - declining_stocks。
3. 基于前一日涨跌股数线累计值（adl_previous），更新当日累计值（adl_current）：
   - 若 net_advances ≥ 0，则 adl_current = adl_previous + net_advances；
   - 若 net_advances < 0，则 adl_current = adl_previous - |net_advances|。
4. 将 adl_current 绘制成连续曲线，形成涨跌股数线（ADL）。
5. 将 ADL 曲线与主流指数（如道琼斯工业平均指数）同步对比。
6. 判断是否出现背离：
   - **看涨背离**：指数下跌创新低，但 ADL 未创新低；
   - **看跌背离**：指数上涨创新高，但 ADL 未创新高。
7. 若确认背离，立即发出“趋势可能反转”的早期预警信号，提示用户警惕当前趋势的持续性风险。

> 注意：仅适用于具有明确涨跌分类且具备连续交易日数据的股票市场。