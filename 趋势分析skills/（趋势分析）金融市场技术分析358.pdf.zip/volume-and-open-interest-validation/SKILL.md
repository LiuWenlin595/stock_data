---
name: Volume and Open Interest Validation
description: 验证价格趋势的有效性，通过分析交易量和持仓量是否与价格走势一致。当用户在日线图或周线图上评估技术分析中的趋势强度时使用此技能。
---

# Volume and Open Interest Validation

## When to Use
Use this skill when:
- Analyzing price trends on daily or weekly technical charts
- Seeking confirmation of trend strength or early warning of potential reversals
- Transaction volume or open interest data is available

Do NOT use this skill for:
- Monthly charts (typically lack reliable volume data)
- Markets that do not report volume or open interest
- Situations where price data is unavailable

## Core Procedure
1. **Prioritize price**: Treat price as the primary indicator; all other signals are secondary.
2. **Assess volume first**: Compare current volume to recent averages:
   - If price rises with significantly increased volume → bullish confirmation
   - If price falls with significantly increased volume → bearish confirmation
3. **Evaluate open interest secondarily** (only if applicable):
   - Rising open interest during a price decline → bearish signal
   - Falling open interest during a price rally → potential weakness
4. **Check for divergence**:
   - Price up + volume down → weak rally, possible reversal
   - Price down + volume down → weak selling pressure, possible exhaustion
5. **Issue alert**:
   - If price aligns with volume/open interest → high trend reliability
   - If divergence exists → issue potential reversal warning

> Note: Volume carries more weight than open interest in validation logic.