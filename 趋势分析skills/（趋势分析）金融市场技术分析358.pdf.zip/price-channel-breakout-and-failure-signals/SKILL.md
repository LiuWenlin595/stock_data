---
name: Price Channel Breakout and Failure Signals
description: Analyze price action relative to established trend channels to detect breakout (acceleration) or failure-to-reach (weakening) signals, and apply appropriate trend adjustments or trade actions. Use this skill when a confirmed ascending or descending price channel exists and price either breaks through a channel boundary or fails to reach it.
---

# Price Channel Breakout and Failure Signals

## When to Use
Use this skill **only after** a valid price channel (ascending or descending) has been confirmed. Apply it when:
- Price breaks above the upper channel line in an uptrend or below the lower channel line in a downtrend (**breakout signal**), OR
- Price fails to reach the expected channel boundary during a trend (**failure signal**).

## Core Procedures

### 1. Respond to Channel Breakouts
- **In an ascending channel**: If price breaks **above** the upper channel line:
  - Interpret as **trend acceleration**, not reversal.
  - Consider adding long positions.
  - Redraw the base trendline from the last significant swing low, parallel to the new steeper upper channel.
- **In a descending channel**: If price breaks **below** the lower channel line:
  - Interpret as **downward acceleration**.
  - Consider adding short positions.

### 2. Respond to Channel Failures
- **In an ascending channel**: If price **fails to reach** the upper channel boundary:
  - Treat as a **warning of weakening momentum**.
  - Anticipate increased risk of breaking the **lower** (support) channel line.
  - Draw a new tentative descending channel using the last two lower highs and the most recent swing low.
- **In a descending channel**: If price **fails to reach** the lower boundary:
  - Treat as early sign of trend exhaustion.
  - Watch for potential break of the **upper** (resistance) channel line.

### 3. Calculate Price Targets After Breakout
- Measure the **channel width** (vertical distance between base trendline and channel line).
- From the **breakout point**, project price **in the direction of the breakout** by one channel width.
- Use this projection as a **minimum price target**.

### 4. Risk Management
- **Avoid逆势 (counter-trend) trades** based solely on channel failures—these carry high risk.
- Always confirm signals with additional technical evidence before acting.

> ⚠️ **Critical Constraint**: These signals are **meaningless** without a pre-confirmed, valid price channel.