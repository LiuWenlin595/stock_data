---
name: Trading System Robustness Validation Framework
description: Executes a three-dimensional robustness test (parameter, time period, and cross-market) for coded trading systems using historical data. Use this skill after completing system coding and preliminary chart validation, and before live deployment, to ensure the strategy is not curve-fit or fragile.
---

# Trading System Robustness Validation Framework

## When to Use
Activate this skill **after you have coded a rule-based trading system** and completed manual chart verification, and you are preparing for formal backtesting. Do not use it for single-parameter, single-market, or single-period tests.

## How to Execute

Perform the following validation steps in sequence:

### 1. Parameter Robustness Test
- Generate neighboring parameter sets around your core values (e.g., if using 5/20 SMA crossover, test 4/19, 6/21, 5/18, etc.).
- If these variants do not yield reasonably strong performance, **reject the original system**.

### 2. Time Period Robustness Test
- Run the system on multiple non-overlapping historical windows (e.g., 1981–1986 and 1990–1995).
- The system must perform acceptably in **any reasonable 5-year span**, not just recent data.

### 3. Cross-Market Robustness Test
- Apply the same system to multiple correlated markets (e.g., crude oil, heating oil, gasoline).
- If it works in one but fails in closely related markets, **investigate and likely discard**.
- Ideally, validate across a broad universe of markets.

### 4. Data and Cost Handling
- Use **continuous contracts** (gap-adjusted) for initial testing.
- Exclude transaction costs (slippage, commissions) during testing to assess pure logic.
- Reintroduce costs only in final reporting to confirm real-world viability.

### 5. Post-Test Manual Verification
- Plot all computer-generated signals on price charts.
- Confirm each trade aligns with your original intent.
- If discrepancies exist, **debug and retest**.

> 📌 Output: A robustness assessment report across all three dimensions. Proceed to live use only if the system passes all tests.