---
name: Price Gap Classification and Forecasting
description: 对日线图、周线图或月线图中出现的价格跳空（缺口）进行分类，并基于其类型、趋势阶段和成交量判断市场含义、支撑/阻挡作用及填回可能性。当在线图上识别到当日最低价高于前日最高价（向上跳空）或当日最高价低于前日最低价（向下跳空）时使用本技能。
---

# Price Gap Classification and Forecasting

## When to Use
Use this skill when you observe a price gap (an unfilled trading range between two consecutive bars) on daily, weekly, or monthly charts. Apply it only if:
- There is a clear gap (no overlap between the current bar’s price range and the prior bar’s);
- Trading volume and trend context are available;
- The market allows for gaps (e.g., not a 24/7 continuous market without session breaks).

## How to Execute

### Step 1: Confirm the Gap Exists
- **Upward gap**: Current period’s low > previous period’s high.
- **Downward gap**: Current period’s high < previous period’s low.

### Step 2: Classify the Gap Type
Evaluate based on trend phase, volume, and market context:

#### A. Breakaway Gap
- **Occurs at**: Start of a new trend or breakout from a consolidation pattern (e.g., head-and-shoulders neckline, key support/resistance).
- **Volume**: High.
- **Forecasting role**: Acts as future support (upward) or resistance (downward).
- **Fill behavior**: Typically not filled; if fully filled, the breakout may be invalid.

#### B. Measuring (Runaway) Gap
- **Occurs at**: Midpoint of an ongoing trend.
- **Volume**: Moderate.
- **Forecasting role**: Confirms trend strength; can be used to estimate remaining move (measure distance from start to gap, project same distance beyond).
- **Fill behavior**: Usually not filled; a fill may signal weakening momentum.

#### C. Exhaustion Gap
- **Occurs at**: Near end of a mature trend, after significant move and often following a breakaway and measuring gap.
- **Volume**: May spike initially but reverses quickly.
- **Confirmation**: Close below (for upward exhaustion) or above (for downward exhaustion) the gap zone within days.
- **Fill behavior**: Often filled quickly; filling confirms trend reversal.

### Step 3: Assess Implications
- Determine whether the gap provides support/resistance.
- Evaluate likelihood of being filled based on type.
- Judge trend sustainability: breakaway and measuring gaps support continuation; exhaustion gaps warn of reversal.

> **Note**: The common saying “all gaps get filled” is misleading. Only exhaustion gaps are reliably filled; breakaway and measuring gaps often remain unfilled and serve as structural reference points.

### Step 4: Prioritize Higher Timeframes
Gaps on weekly or monthly charts carry stronger predictive power than those on daily charts. Treat them with greater significance in strategic decisions.