---
name: Core Trading and Risk Management Principles
description: Enforces a checklist of 19 essential trading discipline and risk management rules covering trend alignment, position sizing, stop-loss usage, planning, and psychological discipline. Use this skill whenever evaluating a trade setup, reviewing a trading plan, or assessing behavioral compliance before executing any market transaction.
---

# Core Trading and Risk Management Principles

## When to Use
Apply this skill **before every trade decision** or during periodic review of your trading process. Trigger it if you are:
- Considering entering a position without a clear plan
- Managing open positions
- Evaluating past trades for discipline violations
- Designing or refining a personal trading methodology

## How to Execute

Validate your intended action against the following principles. **If any are violated, issue a risk alert and halt execution**:

1. Trade only in the direction of the intermediate-term trend.
2. Buy dips in uptrends; sell rallies in downtrends.
3. Let profits run; cut losses small.
4. Always set protective stop-loss orders before entry.
5. Never trade impulsively—only execute pre-planned setups.
6. Stick to your plan once the market opens.
7. Prioritize risk management over profit chasing.
8. Diversify moderately—avoid both concentration and excessive fragmentation.
9. Require a minimum reward-to-risk ratio of 3:1.
10. Never add funds to a losing position (“don’t throw good money after bad”).
11. Close losing positions before profitable ones when reducing exposure.
12. Make decisions outside market hours (except for ultra-short-term strategies).
13. Analyze from long-term to short-term time frames.
14. Use intraday charts only for precise entry/exit timing.
15. Master swing trading before attempting day trading.
16. Ignore media hype and conventional wisdom.
17. Be comfortable being in the minority when your analysis supports it.
18. Continuously study and practice technical analysis.
19. Favor simplicity—complexity rarely improves reliability.

> ✅ This skill outputs an **alert** if any principle is breached. Only proceed if all checks pass.