---
name: Standard Moving Average Combinations
description: Provides standardized simple moving average (SMA) parameter combinations for trend tracking and signal generation based on market type (futures/stocks), time frame (daily/weekly/monthly), and indicator context (e.g., Bollinger Bands). Use this skill when configuring technical analysis systems that rely on moving averages, especially to avoid over-engineering with unproven EMA variants.
---

# Standard Moving Average Combinations

## When to Use
Use this skill **when you have decided to use moving averages as a core technical indicator** and need to select appropriate, market-validated parameters. Apply it during system design or chart setup for futures or stock trading across daily, weekly, or monthly time frames.

## How to Execute

1. **Prefer Simple Moving Averages (SMA)** over Exponential Moving Averages (EMA), as there is no conclusive evidence that EMA offers improvement.

2. **Select standard SMA pairs based on market and time frame**:
   - **Futures (daily charts)**:
     - 4-day and 9-day
     - 5-day and 20-day
     - 10-day and 40-day
   - **Stocks**:
     - Short-to-medium term: 50-day SMA (or 10-week)
     - Long-term (weekly charts): 30-week and 40-week SMAs (equivalent to ~200-day)

3. **For Bollinger Bands**, use:
   - Daily charts: 20-day SMA
   - Weekly charts: 20-week SMA (≈100-day SMA on daily)

4. **Combine with channel breakout systems** when trading in trending markets—these work well on daily, weekly, and monthly charts.

5. **Follow the principle**: “Return to simplicity.” Avoid complex or custom-weighted moving averages unless empirically justified.

> ⚠️ Do not use this skill if you are pursuing novel or academically optimized weighting schemes without real-world validation.