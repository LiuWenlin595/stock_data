---
name: defensive-investment-strategy
description: |
  Use when: You are managing an investment portfolio and need to avoid common cognitive traps, filter unreliable external advice, and protect capital during market downturns or trend changes.
  What it does: Provides a three-phase framework to (1) eliminate overconfidence from high IQ/education, (2) evaluate and reject flawed expert and analyst recommendations, and (3) execute disciplined capital protection by selling underperforming assets when market trends reverse.
---

# Defensive Investment Strategy

## Overview
Most investment failures stem not from lack of intelligence, but from psychological traps and misplaced trust in external authorities. This skill guides you through eliminating false confidence, filtering information sources, and executing mechanical capital protection rules.

## Phase 1: Cognitive Preparation - Eliminate Overconfidence

### When to Apply
When you possess high academic credentials, high IQ, or professional expertise and assume these translate to market advantage.

### Execution Steps

1. **Acknowledge the Zero-Correlation Principle**
   - Investment success correlates poorly with:
     - Academic degrees (PhD, MBA, CFA)
     - University prestige
     - IQ scores or standardized test performance
   - Historical evidence: 2008 crisis caused by "smartest" people (senators, Fannie Mae executives, top Wall Street leaders) using 50x leverage and complex derivatives

2. **Identify Male Overconfidence Bias** 
   - Warning signs:
     - "I can figure this out with enough analysis"
     - Preference for complex strategies over simple rules
     - Excessive leverage or concentration
   - Action: Deliberately reduce position sizes and increase diversification when you feel "certain"

3. **Adopt "Market Student" Mindset**
   - Assume you know less than the market collective
   - Focus on learning price action rather than proving intellectual superiority

## Phase 2: Information Filtering - Eliminate False Authorities

### 2A: Media Expert Evaluation

#### When to Apply
Before acting on market predictions from television (CNBC, Bloomberg), financial newsletters, or popular pundits.

#### Execution Protocol
1. **Treat Consensus Expert Opinion as Contrarian Indicator**
   - Rule: When experts unanimously predict direction, prepare for the opposite
   - Historical pattern: Traditional wisdom is rarely correct in markets

2. **Verify Expert Experience Level**
   - Minimum requirement: Must have managed through 1987, 1974-75, or 1962 bear markets
   - Red flag: Analysts with <10 years experience (only bull market exposure)

3. **Dangerous Prediction Patterns to Ignore**
   - Interest rate/inflation predictions based on government borrowing theories (failed in 1982)
   - "Bear market coming" calls at market bottoms (failed in 1996)
   - "Buying opportunities" during sustained downtrends (failed in 2000 tech crash)

4. **Independent Verification Requirement**
   - Never act on TV opinions without data verification
   - Check primary sources (e.g., Investor's Business Daily for mutual fund cash position claims)

### 2B: Analyst Report Evaluation

#### When to Apply
When evaluating Wall Street research reports or building investment research processes.

#### Execution Protocol
1. **Recognize Structural Inefficiencies**
   - Industry specialization creates blind spots:
     - Cold sectors: Analysts recommend "least bad" options
     - Hot sectors: Miss majority of winners due to narrow coverage
   - Industry experts know products but lack market timing skills

2. **Account for Conflict of Interest**
   - Investment banking relationships prevent "sell" ratings
   - Reference data: In 2000, only 29 sell ratings among 8000 recommendations
   - Post-Regulation FD (2000): Analysts lost insider information advantage

3. **Prefer Generalists over Specialists**
   - Optimal team: 5 generalist analysts vs. 50-70 industry specialists
   - Test: Verify if analysts personally invest successfully using their own recommendations

## Phase 3: Execution - Capital Protection

### When to Apply
When market trend changes (distribution phase, bear market signals) and you hold stocks showing performance deterioration.

### Execution Steps

1. **Monitor Trend Change Signals**
   - Market indices show distribution days (higher volume declines)
   - Leading stocks break support on heavy volume
   - Economic data deterioration confirming technical weakness

2. **Evaluate Individual Holdings**
   Identify stocks to sell:
   - No longer making new highs while market rallies
   - Declining earnings or revenue growth
   - Breaking below 50-day or 200-day moving averages on volume

3. **Execute Partial Liquidation**
   - **Mandatory**: Sell at least a portion (25-50%) of non-performing holdings immediately
   - **Rationale**: 
     - Most stocks decline in bear markets
     - Not all stocks recover to previous highs (permanent capital impairment risk)
     - Opportunity cost of holding dead money (miss new leaders emerging)

4. **Avoid Buy-and-Hold Rationalization**
   - Do not use "long-term investor" label to justify holding declining assets
   - Historical reality: Severe bear markets (1973-74: -37%, 2000-02: tech stocks -75-90%, 2007-08) destroy capital that never recovers
   - Accept that "you cannot predict how bad or how long" bear markets will last

5. **Preserve Dry Powder**
   - Maintain 20-50% cash during confirmed downtrends
   - Prepare to redeploy in new market leaders when trend reverses

## Decision Checklist
Before making any investment decision, verify:
- [ ] I am not relying on my intelligence/education as edge
- [ ] I have not sourced this idea from TV/media experts without verification  
- [ ] I have not sourced this idea from traditional analyst buy ratings
- [ ] If market trend is down, I have sold non-performing positions
- [ ] I have defined stop-loss levels based on technical support, not hope