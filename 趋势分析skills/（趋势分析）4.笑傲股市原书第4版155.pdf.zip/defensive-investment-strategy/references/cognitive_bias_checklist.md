# Cognitive Bias Detection Checklist

## Overconfidence Indicators (SKU 4)
- [ ] Do I believe my education gives me an edge?
- [ ] Am I using leverage >2x?
- [ ] Do I understand the product/business better than the market?
- [ ] Have I backtested this strategy across multiple market cycles?

## Expert Reliance Indicators (SKU 5 & 6)
- [ ] Did I get this idea from CNBC/CNN/Bloomberg today?
- [ ] Is the expert under 35 years old?
- [ ] Has the expert changed their view in the last 30 days?
- [ ] Does the analyst have a buy rating on a stock down >50%?
- [ ] Am I looking at industry-specific reports for timing decisions?

## Buy-and-Hold Rationalization Indicators (SKU 3)
- [ ] Am I calling myself a "long-term investor" to avoid selling?
- [ ] Is the stock down >20% from my purchase price?
- [ ] Would I buy this stock today at current price?
- [ ] Is the general market in a confirmed downtrend?
- [ ] Am I waiting to "break even" before selling?