# Historical Case Studies for Defensive Investment

## 2008 Financial Crisis: Intelligence Failure
### Participants
- Senators and Congressmen (both parties)
- Fannie Mae and Freddie Mac executives  
- Top-tier investment bank leadership
- PhD-level quantitative analysts

### Errors Committed
- 50x leverage exposure to subprime mortgages
- Creation of complex derivatives (CDOs, CDS) to obscure risk
- Reliance on historical housing price data without tail risk analysis

### Lesson
Collective intelligence failed due to incentive misalignment and overconfidence in models.

## 1973-1974 Bear Market: Buy-and-Hold Danger
### Market Statistics
- Decline: 36.98% (vs. typical 26% average)
- Duration: 21 months (vs. typical 9 months)
- Context: Vietnam War, inflation, monetary tightening

### Impact on Holders
Investors holding through decline faced 3-5 year recovery periods; many never returned to breakeven.

## 2000-2002 Tech Crash: Permanent Impairment
### Failed Stocks (Never Recovered to 2000 Highs)
- Time Warner
- Corning  
- Yahoo
- Intel (took 15+ years to recover)
- JDS Uniphase
- EMC

### Loss Magnitude
- Speculative tech: 75-90% declines
- Blue-chip tech: 50-70% declines

### Analyst Failure
CNBC experts repeatedly called "buying opportunities" during 2000-2001 decline, leading to serial losses.

## 1998 Coca-Cola Case: Opportunity Cost
### Scenario
- Coca-Cola peaked summer 1998
- Entered mild bear market with general indices
- Failed to participate in 1999 rally

### Alternative
Capital rotated into AOL and Qualcomm generated 300-500% gains while Coke holders remained flat to down.

## Expert Prediction Failures

### 1982 Interest Rate/Inflation Predictions
**Expert Consensus**: Government borrowing would crowd out private investment, causing rates and inflation to spike to new highs.

**Actual Result**: Inflation collapsed; interest rates fell dramatically. Bonds entered 20-year bull market.

### 1996 Bear Market Call
**Expert Prediction**: Prominent strategist declared bear market imminent in summer 1996.

**Actual Result**: Market bottomed next day and began 4-year bull run. Expert created permanent psychological damage causing investors to miss gains.

### 2000 Mutual Fund Cash Argument
**Expert Logic**: High mutual fund cash positions indicated "dry powder" for market support.

**Verification**: Investor's Business Daily data showed cash levels high because market was below historical averages, not because managers were bullish. Market continued declining.