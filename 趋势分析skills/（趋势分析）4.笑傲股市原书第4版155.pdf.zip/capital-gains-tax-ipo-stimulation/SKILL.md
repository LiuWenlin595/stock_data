---
name: capital-gains-tax-ipo-stimulation
description: |
  Use when: Designing macroeconomic stimulus policies during or after economic crises, specifically when needing to revitalize IPO markets and incentivize venture capital and entrepreneurship.
  What it does: Evaluates capital gains tax reduction as a policy tool to stimulate new business formation, IPO activity, and job creation, based on historical market data and investor behavior mechanisms.
---

# Capital Gains Tax Policy for IPO Market Stimulation

## Trigger Conditions
Apply this policy framework when:
- Economic collapse or severe downturn has occurred (e.g., post-2008 crisis environment)
- IPO markets are dormant or declining
- Policy goal includes job creation through new enterprise formation

## Core Policy Mechanism

### 1. Investor Behavior Dynamics
- **Lock-up Effect**: High capital gains tax rates cause investors to defer selling to avoid tax liability, reducing capital available for reinvestment in new ventures
- **Estate Planning Extremes**: Retirees may hold appreciated assets until death to avoid taxation entirely, freezing capital in mature companies rather than recycling it to new enterprises
- **Mobility Effect**: Lower rates unlock capital for reallocation to higher-growth, innovative startups

### 2. Historical IPO Performance Data
- **8-10 Year Rule**: Approximately 80% of significant stock market winners (multi-baggers) issued their IPO 8-10 years prior to their major price advances
- **Job Creation Lag**: Companies that become large employers typically require 8-10 years from founding/IPO to reach scale
- **Implication**: Stimulating today's IPO market creates the employment base for the next decade

### 3. Policy Implementation
1. **Rate Reduction**: Propose reduction in long-term capital gains tax rates
2. **Target Duration**: Design as temporary stimulus (typically 2-4 years) to encourage immediate realization of gains and reinvestment
3. **Revenue Projection**: Account for potential short-term revenue loss offset by:
   - Increased transaction volume
   - Higher IPO activity generating underwriting taxes
   - Long-term employment growth expanding income tax base

## Expected Outcomes
- Increased IPO underwriting activity
- Enhanced venture capital availability (exit liquidity improves)
- Accelerated capital rotation from mature to growth companies
- Job creation timeline: Effects visible in 3-5 years, peaking in 8-10 years

## Constraints and Considerations
- **Market Specificity**: Framework developed for US market context (circa 2009); adapt for local tax structures
- **Fiscal Environment**: Requires tolerance for short-term revenue reduction
- **Complementary Policies**: Most effective when combined with regulatory easing for small-cap public offerings