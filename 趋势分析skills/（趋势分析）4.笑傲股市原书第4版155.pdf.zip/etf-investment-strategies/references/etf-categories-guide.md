# ETF类别与选择指南

## 按资产类别分类

### 股票ETF

#### 美国大盘股
| 代码 | 名称 | 费用率 | 特点 |
|------|------|--------|------|
| SPY | SPDR S&P 500 | 0.09% | 最早、流动性最好 |
| IVV | iShares Core S&P 500 | 0.03% | 费用低 |
| VOO | Vanguard S&P 500 | 0.03% | 费用低 |

#### 美国中盘股
| 代码 | 名称 | 费用率 | 特点 |
|------|------|--------|------|
| IJH | iShares Core S&P Mid-Cap | 0.05% | 覆盖中盘股 |
| VO | Vanguard Mid-Cap ETF | 0.04% | 费用低 |

#### 美国小盘股
| 代码 | 名称 | 费用率 | 特点 |
|------|------|--------|------|
| IJR | iShares Core S&P Small-Cap | 0.06% | 覆盖小盘股 |
| VB | Vanguard Small-Cap ETF | 0.05% | 费用低 |

#### 国际股票
| 代码 | 名称 | 费用率 | 特点 |
|------|------|--------|------|
| EFA | iShares MSCI EAFE | 0.32% | 发达市场（除美加） |
| EEM | iShares MSCI Emerging | 0.67% | 新兴市场 |
| VEA | Vanguard FTSE Developed | 0.05% | 发达市场 |
| VWO | Vanguard Emerging Markets | 0.08% | 新兴市场 |

### 行业ETF

| 代码 | 名称 | 费用率 | 行业 |
|------|------|--------|------|
| XLF | Financial Select Sector | 0.10% | 金融 |
| XLK | Technology Select Sector | 0.10% | 科技 |
| XLE | Energy Select Sector | 0.10% | 能源 |
| XLV | Health Care Select Sector | 0.10% | 医疗 |
| XLI | Industrial Select Sector | 0.10% | 工业 |
| XLU | Utilities Select Sector | 0.10% | 公用事业 |
| XLP | Consumer Staples Select | 0.10% | 消费必需品 |
| XLY | Consumer Discretionary | 0.10% | 消费非必需品 |
| XLB | Materials Select Sector | 0.10% | 材料 |
| XLRE | Real Estate Select Sector | 0.10% | 房地产 |

### 债券ETF

| 代码 | 名称 | 费用率 | 特点 |
|------|------|--------|------|
| AGG | iShares Core U.S. Aggregate Bond | 0.03% | 美国综合债券 |
| BND | Vanguard Total Bond Market | 0.03% | 美国总债券市场 |
| TLT | iShares 20+ Year Treasury Bond | 0.15% | 长期国债 |
| SHY | iShares 1-3 Year Treasury Bond | 0.15% | 短期国债 |
| LQD | iShares Investment Grade Corporate | 0.14% | 投资级公司债 |
| HYG | iShares High Yield Corporate | 0.49% | 高收益公司债 |

### 商品ETF

| 代码 | 名称 | 费用率 | 特点 |
|------|------|--------|------|
| GLD | SPDR Gold Shares | 0.40% | 黄金 |
| IAU | iShares Gold Trust | 0.25% | 黄金（费用更低） |
| SLV | iShares Silver Trust | 0.50% | 白银 |
| USO | United States Oil Fund | 0.81% | 原油 |
| DBA | Invesco DB Agriculture | 0.85% | 农产品 |

### 货币ETF

| 代码 | 名称 | 费用率 | 特点 |
|------|------|--------|------|
| UUP | Invesco DB US Dollar Index | 0.77% | 美元指数 |
| FXE | Invesco CurrencyShares Euro | 0.40% | 欧元 |
| FXY | Invesco CurrencyShares Japanese Yen | 0.40% | 日元 |
| FXB | Invesco CurrencyShares British Pound | 0.40% | 英镑 |

### 杠杆和反向ETF

#### 反向ETF（-1倍）
| 代码 | 名称 | 费用率 | 特点 |
|------|------|--------|------|
| SH | ProShares Short S&P 500 | 0.89% | 标普500反向 |
| SDS | ProShares UltraShort S&P 500 | 0.90% | 标普500双倍反向 |
| DOG | ProShares Short Dow 30 | 0.89% | 道指反向 |
| PSQ | ProShares Short QQQ | 0.95% | 纳指反向 |

#### 杠杆ETF（+2倍或+3倍）
| 代码 | 名称 | 费用率 | 特点 |
|------|------|--------|------|
| SSO | ProShares Ultra S&P 500 | 0.90% | 标普500双倍 |
| UPRO | ProShares UltraPro S&P 500 | 0.91% | 标普500三倍 |
| QLD | ProShares Ultra QQQ | 0.95% | 纳指双倍 |
| TQQQ | ProShares UltraPro QQQ | 0.95% | 纳指三倍 |

## 按策略分类

### 因子ETF

| 代码 | 名称 | 费用率 | 策略 |
|------|------|--------|------|
| VTV | Vanguard Value ETF | 0.04% | 价值因子 |
| VUG | Vanguard Growth ETF | 0.04% | 成长因子 |
| MTUM | iShares Momentum ETF | 0.15% | 动量因子 |
| QUAL | iShares Edge MSCI USA Quality | 0.15% | 质量因子 |
| SIZE | iShares Edge MSCI USA Size | 0.15% | 规模因子 |
| USMV | iShares Edge MSCI Min Vol | 0.15% | 低波动 |

### 股息ETF

| 代码 | 名称 | 费用率 | 特点 |
|------|------|--------|------|
| VYM | Vanguard High Dividend Yield | 0.06% | 高股息 |
| SCHD | Schwab U.S. Dividend Equity | 0.06% | 股息成长 |
| DVY | iShares Select Dividend | 0.38% | 选择性股息 |
| SDY | SPDR S&P Dividend ETF | 0.35% | 标普股息 |

## ETF选择标准

### 流动性

- 平均日成交量 > 100万股
- 买卖价差 < 0.10%

### 费用率

- 股票ETF：< 0.10%
- 债券ETF：< 0.15%
- 商品ETF：< 0.50%

### 资产规模

- 管理资产 > 10亿美元

### 跟踪误差

- 年化跟踪误差 < 0.20%

## 避免的ETF类型

### 过于细分的主题ETF

- 单一公司供应链ETF
- 特定道德标准ETF
- 过于狭窄的行业ETF

### 高费用ETF

- 费用率 > 1%的ETF
- 杠杆ETF（长期持有）

### 低流动性ETF

- 日成交量 < 10万股
- 管理资产 < 1亿美元

## ETF使用场景

### 场景1：无法直接投资外国市场

**解决方案**：使用国际股票ETF
- EFA（发达市场）
- EEM（新兴市场）

### 场景2：账户禁止卖空

**解决方案**：使用反向ETF
- SH（标普500反向）
- SDS（标普500双倍反向）

### 场景3：无法开设期货账户

**解决方案**：使用商品ETF
- GLD（黄金）
- USO（原油）

### 场景4：希望投资特定行业

**解决方案**：使用行业ETF
- XLK（科技）
- XLF（金融）

### 场景5：希望获得股息收入

**解决方案**：使用股息ETF
- VYM（高股息）
- SCHD（股息成长）