---
name: market-news-contrarian-effects
description: |
  Use when: Analyzing stock price reactions to corporate or macro news that has been previously reported, leaked, or anticipated by market participants.
  What it does: Identifies when news will produce counter-intuitive price movements (buying on bad news, selling on good news) and guides contrarian position entry based on market expectation saturation.
---

# Market News Contrarian Effects

## Core Concept: The "Old News" Phenomenon

News operates on a depreciation curve in financial markets:
- **First Report**: Maximum impact, direction aligns with news sentiment (good = up, bad = down)
- **Repeated/Anticipated**: Becomes "old news" with diminished or reversed impact
- **Contrarian Phase**: When universally expected, news triggers opposite price movement

## Execution Framework

### Step 1: Classify News Status
Determine if news is "New" or "Old":

**Old News Indicators:**
- Story has been circulating in media for 3+ days
- Analysts have published preview notes
- Whisper numbers/expectations widely disseminated
- Stock has moved in anticipation (buy the rumor phase completed)

**New News Indicators:**
- Surprise announcement
- Unexpected earnings deviation
- Unscheduled management changes
- Sudden regulatory actions

### Step 2: Apply the Reverse Effect Rule
If news is classified as **Old**:
- **Bad News**: Consider buying/long entry ("Buy on bad news")
  - Logic: Weak holders have already sold; short sellers cover; value buyers step in
  - Risk: Only valid if news does not represent continuous deterioration
  
- **Good News**: Consider selling/profit taking
  - Logic: Expectations already priced in; "smart money" distributes to retail buyers reacting to headline

### Step 3: Verify Market Regime
This effect requires:
- **Efficient Market Environment**: Active institutional participation, free information flow
- **NOT applicable in**: Controlled information environments where repetition reinforces belief (authoritarian propaganda models)

### Step 4: Exception Handling
**Abort contrarian position if:**
- News represents second derivative acceleration (getting worse, not just bad)
- Company guidance indicates sustained deterioration
- Industry-wide structural damage (not company-specific)

## Tactical Application: "Buy on Bad News"

### Setup Recognition
1. Stock declines into earnings/report on widely anticipated negative news
2. Professional investors observed accumulating during decline
3. Short interest elevated (potential covering fuel)

### Entry Execution
- Enter after news release confirmation
- Stop-loss below recent support (in case of continuous deterioration)
- Target: Mean reversion to 20-day moving average or prior resistance

## Risk Management
- Position size smaller than trend-following trades (counter-trend nature)
- Time stop: Exit if no bounce within 3-5 trading days
- Correlation check: Ensure sector isn't in systemic decline