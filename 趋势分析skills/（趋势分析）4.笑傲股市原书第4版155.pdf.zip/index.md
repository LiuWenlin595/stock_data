```markdown
# CAN SLIM 投资体系技能集合

本技能集合源自专业投资书籍，涵盖威廉·欧奈尔CAN SLIM投资法、IBD（投资者商业日报）方法论以及系统化的股票投资策略。这些技能帮助投资者从选股、择时、风险管理到卖出决策，建立完整的投资体系，适用于个人投资者和职业投资者实现超越市场平均表现的目标。

## Available Skills

| Skill | Description | Use When |
|-------|-------------|----------|
| [can-slim-investment-system](can-slim-investment-system/SKILL.md) | 应用CAN SLIM投资体系实现财务独立的完整方法 | 建立投资信念体系、学习CAN SLIM核心原则 |
| [can-slim-stock-selection](can-slim-stock-selection/SKILL.md) | 应用CAN SLIM法则筛选高成长潜力股票 | 成长股筛选和投资决策 |
| [can-slim-fundamental-analysis](can-slim-fundamental-analysis/SKILL.md) | 应用CAN SLIM投资法进行股票基本面评估 | 筛选超级牛股、评估公司基本面质量 |
| [can-slim-growth-investing](can-slim-growth-investing/SKILL.md) | 筛选高成长潜力股票的全面验证流程 | 寻找潜在牛股、验证CAN SLIM法则 |
| [momentum-stock-selection](momentum-stock-selection/SKILL.md) | 基于价格动量和机构认同度的股票筛选策略 | 寻找突破形态、机构支持的优质股票 |
| [growth-stock-investment-strategy](growth-stock-investment-strategy/SKILL.md) | 应用共同基金复利投资策略制定成长股策略 | 利用共同基金积累财富、超越市场平均 |
| [chart-analysis-fundamentals](chart-analysis-fundamentals/SKILL.md) | 理解图表分析在投资决策中的核心价值 | 判断股票强势/弱势、识别价格形态 |
| [technical-pattern-analysis](technical-pattern-analysis/SKILL.md) | 分析价格形态和技术信号 | 技术分析和交易时机选择 |
| [technical-pattern-breakout-analysis](technical-pattern-breakout-analysis/SKILL.md) | 识别茶杯形价格形态、验证突破买入点 | 分析股票图表、寻找买卖时机 |
| [technical-pattern-recognition](technical-pattern-recognition/SKILL.md) | 识别股票价格形态，区分可靠与有缺陷形态 | 技术分析、图表解读和买卖时机判断 |
| [price-pattern-recognition](price-pattern-recognition/SKILL.md) | 识别价格形态的紧凑程度和波动特征 | 分析周线图、评估价格形态质量 |
| [price-pattern-volume-analysis](price-pattern-volume-analysis/SKILL.md) | 利用周线图验证市场行为与买入时机 | 验证市场行为、分析股票图表 |
| [ibd-chart-technical-analysis](ibd-chart-technical-analysis/SKILL.md) | IBD走势图双周期技术分析法 | 执行买入操作、监控持有股票、寻找卖出时机 |
| [chart-pattern-historical-performance](chart-pattern-historical-performance/SKILL.md) | 查询技术分析形态的历史表现数据 | 识别特定图表形态并参考历史成功案例 |
| [market-timing-analysis](market-timing-analysis/SKILL.md) | 基于大盘指数进行市场择时决策 | 决定何时进入或退出市场 |
| [market-trend-following](market-trend-following/SKILL.md) | 大盘趋势跟随与市场顶部识别策略 | 制定交易决策、调整持仓、判断市场时机 |
| [market-trend-analysis-timing](market-trend-analysis-timing/SKILL.md) | 分析股市大盘趋势并把握投资时机 | 判断市场处于牛市还是熊市、评估市场阶段 |
| [market-trend-analysis-timing-2](market-trend-analysis-timing-2/SKILL.md) | 综合评估大盘趋势状态，预警趋势转折 | 判断市场趋势方向、决定持仓策略 |
| [market-timing-cycle-analysis](market-timing-cycle-analysis/SKILL.md) | 分析股市周期阶段、识别牛市黄金时机 | 判断市场整体强弱、寻找市场走势证据 |
| [market-timing-and-bottom-recognition](market-timing-and-bottom-recognition/SKILL.md) | 识别股市底部信号和反弹失败标志 | 大盘择时和趋势判断 |
| [market-top-identification-system](market-top-identification-system/SKILL.md) | 识别市场顶部和熊市预警信号的综合系统 | 大盘顶部识别、市场周期判断 |
| [market-top-timing-and-protection](market-top-timing-and-protection/SKILL.md) | 识别大盘顶点反转的时间窗口，执行熊市保护 | 市场见顶迹象出现时、股指冲顶并开始下跌 |
| [distribution-day-tracking-market-exit](distribution-day-tracking-market-exit/SKILL.md) | 识别市场换筹时点并执行逐步减仓策略 | 跟踪大盘指数、识别市场顶部并执行退出 |
| [market-signals-and-distribution-detection](market-signals-and-distribution-detection/SKILL.md) | 识别市场派发信号和机构行为 | 顶部识别和风险预警 |
| [stop-loss-selling-rules](stop-loss-selling-rules/SKILL.md) | 综合止损策略与卖出规则体系 | 持有股票出现亏损、达到预设止损点 |
| [stop-loss-risk-management](stop-loss-risk-management/SKILL.md) | 执行止损策略和资金再配置以保护本金 | 股票亏损达到7%-10%时 |
| [stop-loss-and-risk-management](stop-loss-and-risk-management/SKILL.md) | 执行严格的止损纪律和风险管理策略 | 个股亏损达到7%-8%时立即卖出 |
| [stop-loss-order-risk-management](stop-loss-order-risk-management/SKILL.md) | 止损指令的风险识别与使用原则 | 考虑使用止损指令时 |
| [risk-management-exit-strategies](risk-management-exit-strategies/SKILL.md) | 执行CAN SLIM投资法核心流程、应用8%止损规则 | 保护投资本金、执行止损操作 |
| [margin-trading-risk-management](margin-trading-risk-management/SKILL.md) | 评估是否启用融资投资、确定融资比例 | 年轻在职投资者评估是否启用杠杆 |
| [margin-risk-historical-cycles](margin-risk-historical-cycles/SKILL.md) | 分析市场交易资金来源结构、比较历史保证金水平 | 评估市场稳定性与系统性风险 |
| [leader-stock-top-signals](leader-stock-top-signals/SKILL.md) | 识别领军股见顶的十大征兆并执行卖出决策 | 领军股经过多个月上涨后出现见顶征兆 |
| [strategic-stock-selling-system](strategic-stock-selling-system/SKILL.md) | 执行全面的股票卖出策略 | 管理现有持仓、考虑止盈止损 |
| [comprehensive-selling-position-management](comprehensive-selling-position-management/SKILL.md) | 综合卖出规则与持仓管理策略 | 决定何时卖出、如何设置止损 |
| [exit-strategy-profit-protection](exit-strategy-profit-protection/SKILL.md) | 防止收益回吐，建立系统化卖出规则 | 投资收益达到预设目标后需要决定是否卖出 |
| [stock-selection-sell-signals](stock-selection-sell-signals/SKILL.md) | 应用RS值选股标准并识别技术性卖出信号 | 提高选股水平并锁定领军股 |
| [fund-analysis-and-selection](fund-analysis-and-selection/SKILL.md) | 分析开放式与封闭式基金区别，评估大型基金规模约束 | 基金投资决策、基金选择和资产配置 |
| [fund-portfolio-diversification](fund-portfolio-diversification/SKILL.md) | 确定合理的基金持有数量、选择不同管理风格的基金 | 构建或调整基金组合、考虑分散化程度 |
| [fund-load-fee-selection-strategy](fund-load-fee-selection-strategy/SKILL.md) | 在收费基金与免收费基金之间做出选择 | 需要在基金类型间做决策或优化基金交易成本 |
| [mutual-fund-investment](mutual-fund-investment/SKILL.md) | 共同基金投资策略与复利管理 | 持有共同基金、考虑转换基金或进行资产配置 |
| [fund-dca-timing](fund-dca-timing/SKILL.md) | 放弃择时行为，立即开始定期定额投资 | 投资者考虑何时开始购买基金、试图择时入场 |
| [fund-allocation-strategy](fund-allocation-strategy/SKILL.md) | 决定避免债券型基金和对冲基金以最大化收益 | 进行基金投资组合配置、选择基金类型 |
| [portfolio-turnover-performance-evaluation](portfolio-turnover-performance-evaluation/SKILL.md) | 评估投资组合周转率与基金业绩关系 | 因高周转率或管理费用考虑排除某基金 |
| [portfolio-manager-evaluation](portfolio-manager-evaluation/SKILL.md) | 建立投资经理全周期评估与更替协议 | 评估投资经理表现 |
| [excellent-fund-family-tracking](excellent-fund-family-tracking/SKILL.md) | 跟踪已识别出历史上表现优秀的基金家族 | 了解其当前投资动向和市场判断 |
| [etf-investment-strategies](etf-investment-strategies/SKILL.md) | 利用ETF实现市场准入和策略灵活性 | 访问受限外国市场、无法开设期货账户 |
| [ibd-etf-screening-ranking](ibd-etf-screening-ranking/SKILL.md) | 使用IBD方法论筛选和排名ETF | 从350只高成交量ETF中发现强势标的 |
| [etf-daily-winners-losers-cycle](etf-daily-winners-losers-cycle/SKILL.md) | 处理ETF赢家与输家的每日展示 | 分析ETF表现排名或生成每日ETF市场摘要 |
| [etf-in-kind-redemption-tax-advantage](etf-in-kind-redemption-tax-advantage/SKILL.md) | 解释ETF通过实物申赎机制实现的税收优势 | 税务敏感型投资者比较ETF与共同基金 |
| [options-strategy-by-market-environment](options-strategy-by-market-environment/SKILL.md) | 根据市场环境选择期权策略 | 期权交易者、市场择时者和对冲投资者 |
| [options-investment-framework](options-investment-framework/SKILL.md) | 期权投资综合框架 | 投资者决定使用期权进行投资时 |
| [option-buying-strategy](option-buying-strategy/SKILL.md) | 指导期权买入策略的制定 | 准备购买期权、询问应该买多长期限的期权 |
| [call-option-writing-assessment](call-option-writing-assessment/SKILL.md) | 评估创设看涨期权的风险与收益 | 询问要不要做备兑开仓、卖出看涨期权怎么样 |
| [warrant-investment-evaluation](warrant-investment-evaluation/SKILL.md) | 提供权证投资的决策框架 | 遇到权证投资机会、询问权证值得买吗 |
| [option-liquidity-risk](option-liquidity-risk/SKILL.md) | 识别和规避期权交易中的流动性风险 | 评估期权交易可行性或准备下单时 |
| [futures-risk-management](futures-risk-management/SKILL.md) | 评估期货投资风险并执行风险控制 | 考虑参与期货市场的投资者 |
| [ibd-earnings-analysis-screening](ibd-earnings-analysis-screening/SKILL.md) | 分析IBD收益报告数据，应用每股收益增长筛选标准 | 筛选具有强劲收益增长潜力的股票 |
| [earnings-quality-verification](earnings-quality-verification/SKILL.md) | 验证收益增长的可持续性 | 验证收益增长质量、识别虚假增长 |
| [eps-calculation-and-yoy-comparison](eps-calculation-and-yoy-comparison/SKILL.md) | 计算每股收益并进行同比对比分析 | 分析股票基本面、评估公司盈利能力 |
| [company-fundamentals-capital-structure](company-fundamentals-capital-structure/SKILL.md) | 评估股本供给结构与管理层持股比例 | 评估股票供给量规模、管理层持股比例 |
| [valuation-and-price-analysis](valuation-and-price-analysis/SKILL.md) | 分析估值指标和价格特征 | 估值分析和价格筛选 |
| [pe-ratio-valuation-analysis](pe-ratio-valuation-analysis/SKILL.md) | 理解市盈率的正确认知、避免同行业市盈率比较误区 | 评估股票估值、进行行业内股票比较 |
| [ibd-industry-leadership-analysis](ibd-industry-leadership-analysis/SKILL.md) | 使用IBD行业体系识别市场领涨板块 | 确定市场投资主题、验证行业趋势强度 |
| [industry-analysis-selection](industry-analysis-selection/SKILL.md) | 应用行业进步驱动牛股法则，分析行业领导地位轮动 | 进行长期投资决策、寻找潜在牛股 |
| [industry-classification-framework](industry-classification-framework/SKILL.md) | 应用三级分类体系确定股票的行业标签 | 对股票或公司进行行业归类、分析行业结构 |
| [industry-follow-through-strategy](industry-follow-through-strategy/SKILL.md) | 产业链跟进效应投资策略 | 识别主导产业增长对关联产业创造的溢出效应 |
| [cross-market-industry-leadership-confirmation](cross-market-industry-leadership-confirmation/SKILL.md) | 通过跨市场同行业股票确认，识别新兴行业领导组群 | 在纳斯达克发现强势股、需要确认行业趋势真实性 |
| [institutional-sponsorship-quality-analysis](institutional-sponsorship-quality-analysis/SKILL.md) | 评估股票的机构投资背景和质量 | 基本面分析中判断机构赞助质量 |
| [institutional-sentiment-analysis](institutional-sentiment-analysis/SKILL.md) | 机构投资者情绪周期与决策质量分析 | 评估机构投资者在市场极端行情下的情绪状态 |
| [institutional-investment-strategies](institutional-investment-strategies/SKILL.md) | 管理大规模机构投资组合 | 养老基金、共同基金经理管理资金规模扩大 |
| [institutional-investment-constraints-analysis](institutional-investment-constraints-analysis/SKILL.md) | 分析机构投资者因法律风险和治理结构导致的投资灵活性降低 | 评估制度化决策障碍、预先核准清单僵化性 |
| [institutional-investment-pitfall-prevention](institutional-investment-pitfall-prevention/SKILL.md) | 帮助机构投资者识别和防范常见投资误区 | 面临债券是安全投资的建议、被建议选择收费最低的基金经理 |
| [market-psychology-and-portfolio-management](market-psychology-and-portfolio-management/SKILL.md) | 管理投资心态和投资组合 | 投资心理管理和投资组合优化 |
| [market-cycle-crowd-psychology](market-cycle-crowd-psychology/SKILL.md) | 基于群体心理学解释市场周期重复性 | 分析长期市场周期、评估当前市场与历史危机相似性 |
| [pension-fund-contrarian-indicator](pension-fund-contrarian-indicator/SKILL.md) | 利用养老基金资产配置数据作为逆向投资情绪指标 | 检测到华尔街形成强烈共识、机构资金同时涌入或涌出 |
| [ibd-research-tools-analysis](ibd-research-tools-analysis/SKILL.md) | 使用IBD股票搜索工具、亚行业组别排名和NSMI服务 | 寻找业绩领先股票、确定买卖时机 |
| [ibd-research-workflow](ibd-research-workflow/SKILL.md) | 使用IBD的多个版面和工具进行股票研究 | 订阅IBD并希望系统化地进行股票研究 |
| [ibd-daily-analysis-workflow](ibd-daily-analysis-workflow/SKILL.md) | 系统化地利用大盘分析、IBD 100、行业排名进行决策 | 进行每日市场分析、构建投资组合 |
| [ibd-stock-rating-screening](ibd-stock-rating-screening/SKILL.md) | 应用IBD智能搜索综合排名系统，分析省时表数据 | 快速评估股票整体表现、从大量股票中筛选潜在投资机会 |
| [ibd-comprehensive-stock-evaluation](ibd-comprehensive-stock-evaluation/SKILL.md) | 使用IBD的综合评估体系对股票进行多维度分析 | 个股筛选、基本面分析、技术分析和量化评分 |
| [ibd-accumulation-distribution-rating](ibd-accumulation-distribution-rating/SKILL.md) | 解读IBD吸筹/出货排名评级，评估机构投资者行为 | 股票交易决策、机构投资者行为分析 |
| [ibd-market-news-reading](ibd-market-news-reading/SKILL.md) | 快速阅读IBD第一页的十大新闻版块 | 需要快速了解市场事件、个股异动 |
| [ibd-reading-guide](ibd-reading-guide/SKILL.md) | 指导如何阅读IBD的各个版面 | IBD订阅者、市场分析师和投资者 |
| [ibd-learning-system](ibd-learning-system/SKILL.md) | 建立IBD系统化学习框架，从投资新手成长为独立决策投资者 | 系统学习CAN SLIM体系、从依赖经纪人转向独立决策 |
| [ibd-community-engagement](ibd-community-engagement/SKILL.md) | 参与IBD投资者社区，包括线下会面和在线论坛交流 | 与志趣相投的投资者交流、获取投资信息 |
| [daily-market-prep-ibd-workflow](daily-market-prep-ibd-workflow/SKILL.md) | 每日登录投资者网开始投资分析 | 建立对市场环境的整体认知 |
| [weekly-chart-review-workflow](weekly-chart-review-workflow/SKILL.md) | 执行每周走势图浏览和买入清单准备流程 | 股票投资者、技术分析师和大盘分析者 |
| [trading-operations](trading-operations/SKILL.md) | 执行交易操作规程和应对市场波动 | 止损指令已设定且未执行但投资者决定改为市价卖出时 |
| [trading-strategy-and-execution](trading-strategy-and-execution/SKILL.md) | 执行交易策略和买卖决策 | 股票交易执行和投资组合管理 |
| [leading-stock-entry-timing](leading-stock-entry-timing/SKILL.md) | 在股价接近或位于新的股价高点之上、从恰当的底部形态突破时买入 | 准备买入股票、寻找领军股入场点 |
| [pivot-point-buying-timing](pivot-point-buying-timing/SKILL.md) | 确定中轴买入点价格和精确买入时机 | 确定中轴买入点具体价格、准备在最佳时机买入股票 |
| [buying-timing-patterns](buying-timing-patterns/SKILL.md) | 基于价格形态突破的精准买入时机判定 | 已识别出具备新要素的股票、股票价格接近或处于新高 |
| [jack-dreyfus-breakout-buying-strategy](jack-dreyfus-breakout-buying-strategy/SKILL.md) | 执行杰克·德莱弗斯的趋势跟踪买入策略 | 寻找技术分析买点、确认趋势启动时机 |
| [investment-discipline-execution](investment-discipline-execution/SKILL.md) | 投资纪律与执行规范 | 执行交易决策、面临外部诱惑或压力 |
| [investment-loss-recovery-calculation](investment-loss-recovery-calculation/SKILL.md) | 计算投资亏损后回本所需的涨幅百分比 | 投资组合风险评估、资金管理和投资心理建设 |
| [analyst-performance-skepticism](analyst-performance-skepticism/SKILL.md) | 评估华尔街分析师推荐的可靠性 | 考虑跟随分析师建议、评估超级明星分析师推荐 |
| [investment-information-filtering](investment-information-filtering/SKILL.md) | 拒绝基于谣言、秘密消息和内部信息的投资决策 | 面临投资建议、市场信息或需要信息甄别 |
| [income-stock-risk-assessment](income-stock-risk-assessment/SKILL.md) | 评估收入型股票和高股息股票的投资风险 | 考虑投资公用事业、银行、电信等高股息板块 |
| [contrarian-investment-value-trap-avoidance](contrarian-investment-value-trap-avoidance/SKILL.md) | 逆向投资时机选择与价值陷阱识别 | 在股票潜力尚未被市场广泛认知时寻找买入机会 |
| [contrarian-investment-extremes](contrarian-investment-extremes/SKILL.md) | 在市场极端位置执行逆向投资策略 | 市场弥漫悲观情绪、投资顾问普遍看空 |
| [news-reaction-analysis](news-reaction-analysis/SKILL.md) | 分析市场对重大新闻事件的反应以判断市场内在强度 | 国内或国际重大新闻冲击华尔街时 |
| [information-filtering-psychology](information-filtering-psychology/SKILL.md) | 利空消息与传闻的过滤策略 | 持仓股票遭遇突发消息、出现利空消息或市场传闻 |
| [intraday-market-behavior-analysis](intraday-market-behavior-analysis/SKILL.md) | 识别午餐时间的市场节奏减缓，通过收盘前几个小时的表现判断趋势持续性 | 进行日内大盘分析、观察市场活动 |
| [year-end-market-distortion](year-end-market-distortion/SKILL.md) | 识别年底至次年2月初的市场扭曲现象 | 时间处于12月-2月、观察到原领军股停滞而低等级股票异常强势 |
| [defensive-stock-market-top-warning](defensive-stock-market-top-warning/SKILL.md) | 通过监测防御性股票的资金流入和新高点占比，识别市场顶部 | 牛市后期经验者资金涌入公用事业、消费品等防御板块 |
| [foreign-stock-risk-assessment](foreign-stock-risk-assessment/SKILL.md) | 评估境外股票的额外风险 | 考虑投资境外股票、外国证券或评估跨境投资风险 |
| [new-stock-investment-tracking](new-stock-investment-tracking/SKILL.md) | 系统追踪过去10年发行的新股、识别新兴成长型公司 | 寻找新兴成长股、关注纳斯达克市场新股机会 |
| [nasdaq-stock-screening-liquidity](nasdaq-stock-screening-liquidity/SKILL.md) | 筛选纳斯达克股票并评估流动性安全性 | 选择投资标的、追求灵活性与安全性 |
| [nasdaq-market-structure-analysis](nasdaq-market-structure-analysis/SKILL.md) | 分析纳斯达克市场的OTC交易机制、ECN基础设施 | 投资标的为纳斯达克上市股票、分析场外交易市场结构 |
| [tech-stock-volatility-calculation](tech-stock-volatility-calculation/SKILL.md) | 计算高科技股相对于消费类股的波动率风险暴露 | 构建投资组合、评估行业配置风险 |
| [demographic-trend-industry-forecast](demographic-trend-industry-forecast/SKILL.md) | 基于人口结构变化预测行业增长潜力 | 分析特定行业增长潜力、寻找长期趋势投资机会 |
| [tax-shelter-investment-principles](tax-shelter-investment-principles/SKILL.md) | 指导避税工具和免税证券的投资决策 | 考虑投资市政债券、询问如何避税 |
| [historical-pattern-recognition](historical-pattern-recognition/SKILL.md) | 识别股市历史模式的重复性 | 基于历史研究的投资决策 |
| [market-index-historical-comparison](market-index-historical-comparison/SKILL.md) | 通过纳斯达克与道琼斯指数的历史叠加对比，分析当代股市与1929年大萧条时期的市场模式相似性 | 比较当代股市与1929年大萧条时期的市场模式 |
| [financial-crisis-government-debt-comparison](financial-crisis-government-debt-comparison/SKILL.md) | 分析银行债务质量演变与政府驱动的金融危机成因 | 比较1929年大萧条与2008年次贷危机的债务类型差异 |
| [historical-market-analogy-framework](historical-market-analogy-framework/SKILL.md) | 应用2009年与1938年历史情境类比框架，评估地缘政治风险和战争风险 | 2009年3月市场分析、地缘政治风险评估 |
| [housing-affordability-crisis-analysis](housing-affordability-crisis-analysis/SKILL.md) | 分析住房可负担性问题的根本原因、识别局部问题被误判为全国性问题的风险 | 分析住房市场政策制定、金融机构风险评估 |
| [wonda-database-system](wonda-database-system/SKILL.md) | 使用WONDA系统进行机构级股票筛选与监控 | 机构投资者需要实时访问欧奈尔数据库 |
| [wonda-database-screening](wonda-database-screening/SKILL.md) | 使用WONDA数据库进行系统性筛选 | 特定行业即将成为领导性产业或需要快速筛选大量公司 |
| [stock-selection-strategy-validation](stock-selection-strategy-validation/SKILL.md) | 验证选股策略的历史有效性 | 评估选股策略的潜在回报或对比不同股票的涨幅表现 |
| [comprehensive-stock-selection](comprehensive-stock-selection/SKILL.md) | 综合基本面与技术面进行选股 | 股票选股、投资标的评估和资产配置决策 |
| [stock-selection-portfolio-strategy](stock-selection-portfolio-strategy/SKILL.md) | 在强势行业中优中选优、结合基本面与强势图形进行选股 | 筛选买入股票、构建投资组合、寻找市场领军股 |
| [ibd-success-secrets-education](ibd-success-secrets-education/SKILL.md) | 应用IBD十大成功秘诀框架进行品格教育和成功学指导 | 向青少年传授生活成功法则、建立个人成就思维模式 |
| [long-term-investment-philosophy](long-term-investment-philosophy/SKILL.md) | 应用长期投资复利哲学，通过持有美国市场资产实现财富增长 | 投资期限超过20年、希望保障个人或家庭财政前景 |
| [market-humility-investment-philosophy](market-humility-investment-philosophy/SKILL.md) | 市场谦逊投资哲学 | - |
| [error-based-learning-framework](error-based-learning-framework/SKILL.md) | 通过深度研究每一个亏损错误、识别模式、制定精准规则 | 发生投资错误导致亏损、需要提升投资能力 |
| [independent-research-conflict-free-methodology](independent-research-conflict-free-methodology/SKILL.md) | 建立和验证无利益冲突的独立研究方法论 | 建立研究可信度、避免利益冲突、选择无偏见研究来源 |
| [chapter-context-marker](chapter-context-marker/SKILL.md) | 标记第14章核心主题为像专家一样投资 | 阅读该章节时需要明确内容方向 |
| [chapter-navigation-placeholder](chapter-navigation-placeholder/SKILL.md) | 占位符技能，标识阅读位置为第10章赢在起跑处 | 用户明确询问第10章内容或需要章节结构导航 |
| [capital-gains-tax-ipo-stimulation](capital-gains-tax-ipo-stimulation/SKILL.md) | 资本利得税IPO刺激 | - |
| [market-news-contrarian-effects](market-news-contrarian-effects/SKILL.md) | 市场新闻逆向效应 | - |
| [huazhang-classic-finance-investment-bibliography](huazhang-classic-finance-investment-bibliography/SKILL.md) | 华章经典金融投资书目 | - |
| [us-media-political-bias-filter](us-media-political-bias-filter/SKILL.md) | 阅读或观看美国全国性新闻媒体时，用于识别政治偏见、区分事实与观点 | 评估媒体对经济状况和政治事件的片面报道 |
| [civilizational-vulnerability-counterterrorism-prioritization](civilizational-vulnerability-counterterrorism-prioritization/SKILL.md) | 应用文明脆弱性分析框架确定反恐安全优先级 | 面临恐怖主义威胁、需要评估安全措施有效性 |
| [sme-employment-contribution-analysis](sme-employment-contribution-analysis/SKILL.md) | 分析中小企业在就业创造中的真实贡献 | 评估经济政策效果、分析就业数据来源 |
| [large-scale-fund-fee-optimization](large-scale-fund-fee-optimization/SKILL.md) | 大规模基金管理费用优化决策 | 管理资产规模达数十亿美元且考虑削减管理费用 |
| [wall-street-research-quota-defects](wall-street-research-quota-defects/SKILL.md) | 识别和分析华尔街研究报告配额制度的结构性缺陷 | 组织研究部门工作流、分配分析师资源 |
| [excellent-business-manager-assessment](excellent-business-manager-assessment/SKILL.md) | 通过财务控制精细度和双重能力评估企业管理质量 | 筛选投资标的、评估管理层能力 |
| [defensive-investment-strategy](defensive-investment-strategy/SKILL.md) | 防御性投资策略 | - |
| [double-bottom-pattern-trading](double-bottom-pattern-trading/SKILL.md) | 当股票价格走势呈现W形且需要识别双重底形态 | 股票价格走势呈现W形且需要识别双重底形态 |
| [cup-with-handle-pattern-trading](cup-with-handle-pattern-trading/SKILL.md) | 分析股票价格图表识别带柄茶杯形态、确定精确买入点 | 技术分析师和趋势投资者寻找突破买点 |
| [systematic-withdrawal-income](systematic-withdrawal-income/SKILL.md) | 通过定期卖出部分优质股获取收入 | 投资者需要稳定收入用于生活开销 |
| [market-bottom-sentiment-indicators](market-bottom-sentiment-indicators/SKILL.md) | 通过看涨看跌期权比率和股票卖空比率识别潜在市场底部 | 通过看涨看跌期权比率和股票卖空比率识别潜在市场底部 |
| [technical-indicator-traps](technical-indicator-traps/SKILL.md) | 识别超买超卖指标在市场趋势转折期的陷阱 | 使用10天移动平均超买超卖指标 |
| [super-bull-stock-performance-reference](super-bull-stock-performance-reference/SKILL.md) | 参考美国股市历史上超级牛股的极端表现幅度 | 寻找市场爆发力案例或评估股票潜在上涨空间的历史极值 |
| [growth-vs-value-investment-strategy](growth-vs-value-investment-strategy/SKILL.md) | 比较成长型与价值型投资策略的历史收益表现 | 投资策略选择、商业周期分析 |
| [short-selling-execution](short-selling-execution/SKILL.md) | 当市场处于熊市阶段、目标股票符合特定技术形态时，执行卖空操作 | 市场处于熊市阶段、目标股票符合特定技术形态 |
| [portfolio-management-pyramiding](portfolio-management-pyramiding/SKILL.md) | 执行基于资金规模的集中持股策略和金字塔式加仓 | 初始仓位上涨显著且市场价格比平均成本高出20个基点 |
| [special-corporate-event-analysis](special-corporate-event-analysis/SKILL.md) | 特殊公司事件分析策略 | 分析兼并候选公司、IPO发行和股票分拆 |
| [advanced-trading-strategies](advanced-trading-strategies/SKILL.md) | 高级交易策略包括金字塔策略、卖空操作和反向投资 | 识别出表现优秀的股票、市场处于疲软状态 |
| [chart-text-data-verification](chart-text-data-verification/SKILL.md) | 将文档中的图表数据与文字描述进行匹配验证 | 文档数据提取、图文信息匹配、OCR结果验证 |
| [news-screening-technique](news-screening-technique/SKILL.md) | 通过标题相关性决策是否深入阅读 | 阅读财经报告、需要快速筛选新闻头条 |

## Quick Navigation

### 核心投资策略
- **can-slim-investment-system**: CAN SLIM投资体系完整方法
- **can-slim-stock-selection**: CAN SLIM法则筛选高成长股票
- **can-slim-fundamental-analysis**: 股票基本面评估
- **momentum-stock-selection**: 价格动量和机构认同度筛选
- **growth-stock-investment-strategy**: 共同基金复利投资策略

### 技术分析与图表
- **chart-analysis-fundamentals**: 图表分析核心价值
- **technical-pattern-analysis**: 价格形态和技术信号
- **technical-pattern-breakout-analysis**: 茶杯形形态与突破分析
- **price-pattern-volume-analysis**: 周线图验证与量价分析
- **ibd-chart-technical-analysis**: IBD双周期技术分析法

### 市场择时与趋势
- **market-timing-analysis**: 基于大盘指数的市场择时
- **market-trend-following**: 大盘趋势跟随与顶部识别
- **market-timing-cycle-analysis**: 股市周期阶段分析
- **market-top-identification-system**: 市场顶部识别系统
- **distribution-day-tracking-market-exit**: 换筹日跟踪与退出策略

### 止损与风险管理
- **stop-loss-selling-rules**: 综合止损策略
- **stop-loss-and-risk-management**: 严格止损纪律
- **risk-management-exit-strategies**: 风险管理与退出策略
- **margin-trading-risk-management**: 融资交易风险管理

### 卖出策略
- **leader-stock-top-signals**: 领军股见顶十大征兆
- **strategic-stock-selling-system**: 全面股票卖出策略
- **exit-strategy-profit-protection**: 收益保护与退出策略

### 基金投资
- **fund-analysis-and-selection**: 基金分析与选择
- **fund-portfolio-diversification**: 基金组合分散化
- **mutual-fund-investment**: 共同基金投资策略
- **fund-dca-timing**: 基金定期定额投资时机

### ETF投资
- **etf-investment-strategies**: ETF投资策略
- **ibd-etf-screening-ranking**: IBD ETF筛选与排名

### 期权与衍生品
- **options-investment-framework**: 期权投资综合框架
- **option-buying-strategy**: 期权买入策略
- **call-option-writing-assessment**: 看涨期权创设评估
- **futures-risk-management**: 期货风险管理

### 基本面分析
- **ibd-earnings-analysis-screening**: IBD收益分析筛选
- **earnings-quality-verification**: 收益质量验证
- **eps-calculation-and-yoy-comparison**: EPS计算与同比分析
- **company-fundamentals-capital-structure**: 公司基本面与资本结构

### 行业分析
- **ibd-industry-leadership-analysis**: IBD行业领导力分析
- **industry-analysis-selection**: 行业分析与选择
- **industry-follow-through-strategy**: 产业链跟进策略

### IBD工具与工作流
- **ibd-research-workflow**: IBD研究工作流
- **ibd-daily-analysis-workflow**: IBD每日分析工作流
- **ibd-stock-rating-screening**: IBD股票评级筛选
- **ibd-comprehensive-stock-evaluation**: IBD综合股票评估
- **daily-market-prep-ibd-workflow**: 每日市场准备
- **weekly-chart-review-workflow**: 每周图表回顾

### 交易执行
- **trading-strategy-and-execution**: 交易策略与执行
- **leading-stock-entry-timing**: 领军股入场时机
- **pivot-point-buying-timing**: 中轴买入点时机
- **buying-timing-patterns**: 基于价格形态的买入时机

### 投资心理与教育
- **market-psychology-and-portfolio-management**: 市场心理与组合管理
- **ibd-learning-system**: IBD系统化学习框架
- **error-based-learning-framework**: 基于错误的学习框架
- **long-term-investment-philosophy**: 长期投资哲学

## How to Use

这些技能可以通过以下方式使用：

1. **根据任务类型选择技能**：参考上表的"Use When"列，找到与您当前任务最匹配的技能。

2. **按类别浏览**：使用"Quick Navigation"部分快速定位到相关类别的技能。

3. **技能调用**：每个技能都是一个独立的模块，包含详细的知识和操作指南。点击技能名称即可访问完整内容。

4. **组合使用**：许多投资任务需要多个技能配合使用。例如，选股可能需要结合`can-slim-stock-selection`、`ibd-earnings-analysis-screening`和`technical-pattern-analysis`。

5. **学习路径**：建议新手从`ibd-learning-system`开始，系统学习CAN SLIM体系；有经验的投资者可以直接使用具体的分析和交易技能。

这些技能基于威廉·欧奈尔的CAN SLIM投资法和IBD（投资者商业日报）的方法论，旨在帮助投资者建立系统化的投资决策流程，实现超越市场平均表现的目标。
```