---
name: dow-theory-yield-signals
description: Use dividend yield thresholds as auxiliary signals for Dow Theory market timing. Use when attempting to identify market tops and bottoms earlier than traditional Dow Theory confirmation signals, or when adjusting portfolio positions based on yield levels.
---

# Dow Theory Yield Signals

## Overview
Use Industrial Index dividend yield levels as early warning signals for market tops and bottoms to compensate for Dow Theory's 20-25% signal lag.

## When to Use
- Seeking early market reversal signals before Dow Theory confirmation
- Adjusting portfolio positions based on yield levels
- Complementing Dow Theory confirmation signals
- Improving investment returns while managing risk

## Core Procedures

### 1. Understand the Principle

**Purpose:**
- Compensate for Dow Theory signal lag (typically 20-25%)
- Provide early trend reversal prediction
- Observe Industrial Index dividend yield

**Calculation:**
- Dividend Yield = Annual Dividend ÷ Stock Price

### 2. Market Top Identification

**Threshold:**
- Industrial Index dividend yield ≤ 3%

**Historical Effectiveness:**
- Consistently effective until mid-1990s

**Failure Cases:**
- **1976:** Market at top, but yield didn't fall to 3%; stocks dropped 20% before confirmation signal
- **Late 1990s:** Following 3% rule would have missed 5-year bull market

### 3. Market Bottom Identification

**Threshold:**
- Industrial Index dividend yield ≥ 6%

**Implication:**
- Typically indicates market has bottomed

### 4. Operational Guidelines

**Position Adjustment:**
- If Industrial and Transportation indices cannot confirm each other, Dow Theory experts may not execute actual buy/sell
- **However:** May consider adjusting positions
- **Effect:** Helps improve Dow Theory returns, but doesn't always produce exceptional returns

**Usage Principles:**
- Cannot replace confirmation signals
- Use for position adjustment, not direct trading
- Combine with other indicators

## Important Constraints

- **Significant failure periods exist** (especially after mid-1990s for top identification)
- 3% threshold for market tops has become unreliable in recent decades
- 6% threshold for market bottoms remains more reliable
- Must be combined with other indicators
- Not a standalone trading system

## Execution Steps

1. **Calculate Current Yield:** Compute Industrial Index dividend yield
2. **Compare to Thresholds:**
   - ≤ 3%: Market top warning
   - ≥ 6%: Market bottom warning
3. **Check Dow Theory Signals:** Verify if Industrial and Transportation indices confirm
4. **Assess Market Context:** Consider recent market behavior and other indicators
5. **Adjust Positions:** If warning triggered, consider position adjustment rather than full entry/exit
6. **Monitor for Confirmation:** Watch for traditional Dow Theory confirmation

## Output Template

Current Yield: {X%} | Signal: {Top Warning/Bottom Warning/Neutral} | Dow Confirmation: {Yes/No} | Recommended Action: {Adjust Position/Hold/Wait for Confirmation} | Confidence: {High/Medium/Low}