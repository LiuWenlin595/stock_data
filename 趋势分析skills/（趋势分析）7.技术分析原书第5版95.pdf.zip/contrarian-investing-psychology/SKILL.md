---
name: contrarian-investing-psychology
description: Apply contrarian thinking principles to identify market extremes caused by crowd psychology. Use when market consensus becomes overwhelming, investor emotions reach extremes, or when seeking opportunities created by irrational herd behavior.
---

# Contrarian Investing Psychology

## Overview
Identify market opportunities by challenging consensus views and exploiting irrational crowd behavior.

## When to Use
- Market shows strong consensus or uniform opinion
- Investor emotions reach extreme levels
- Crowd behavior appears to override individual judgment
- Seeking mispriced assets due to group irrationality
- Identifying potential market turning points

## Core Principles

### 1. Crowd Psychology Characteristics

**Organized/Psychological Crowd:**
- Maintains mental unity
- Individuals lose self-awareness
- Influenced by emotions rather than reason
- Ready to act according to low-level crowd thinking
- **Source:** Thomas T. Hoyle

### 2. Contrarian Thinker's Task

**Fundamental Mission:**
- Challenge views we take for granted
- Question beliefs precisely because they are firmly held
- These beliefs are rarely rigorously examined
- **Source:** Mark Hulbert

### 3. Application Logic

**Trigger Conditions:**
- Market participants form strong consensus (mental unity)
- Driven by emotions rather than analysis
- Loss of independent judgment

**Contrarian Action:**
- Actively question the consensus
- Seek assets mispriced by irrational crowd behavior
- Identify potential market turning points

## Important Constraints

- Applies to markets dominated by crowd psychology
- Must be combined with other analytical tools for verification
- Not every consensus is wrong (timing is critical)
- Requires patience and discipline

## Execution Steps

1. **Identify Consensus:** Assess market sentiment and opinion uniformity
2. **Evaluate Emotional State:** Determine if emotions are driving decisions
3. **Check Independent Judgment:** Assess if investors are thinking independently
4. **Challenge the View:** Actively question the consensus narrative
5. **Seek Contrarian Evidence:** Look for data supporting opposite view
6. **Identify Mispriced Assets:** Find assets potentially mispriced by crowd behavior
7. **Time the Entry:** Wait for confirmation that crowd psychology is peaking
8. **Verify with Other Tools:** Use fundamental/technical analysis to confirm

## Output Template

Consensus Level: {Overwhelming/Strong/Moderate/Weak} | Emotional State: {Extreme/Elevated/Normal} | Independent Judgment: {Low/Medium/High} | Contrarian Opportunity: {High/Medium/Low} | Recommended Action: {Challenge Consensus/Monitor/Wait}