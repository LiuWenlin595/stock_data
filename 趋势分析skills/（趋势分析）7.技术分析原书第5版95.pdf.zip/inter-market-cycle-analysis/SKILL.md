---
name: inter-market-cycle-analysis
description: Analyze relationships between bond yields, commodity prices, and stock markets across different cycle stages. Use when identifying long-term trends, predicting market reversals, or understanding how interest rate changes affect corporate profits and stock valuations.
---

# Inter-Market Cycle Analysis

## Overview
This skill helps analyze the interconnected relationships between different financial markets and identify cycle stages to predict market movements.

## When to Use
- Identifying long-term trend reversals
- Predicting bond yield movements based on commodity prices
- Determining current market cycle stage
- Understanding interest rate transmission to corporate profits
- Assessing inter-market timing relationships

## Core Procedures

### 1. Commodity-Bond Yield Leading Relationship

**Identify Long-Term Trend Reversals:**
1. Monitor commodity prices for long-term turning points
2. Expect bond yields to follow in the same direction
3. Note: Leading time varies (can be months to years)
4. Historical record: 4 out of 5 long-term turning points showed commodities leading bonds

**Key Insight:**
- Industrial commodity price fluctuations (inflation) are the primary driver of long-term bond yield trends
- Use commodity price strength to predict long-term bond yield reversals

### 2. Market Cycle Stage Identification

**Required Data:**
- 3-month commercial paper yield and its 12-month moving average
- S&P Composite Index and its 12-month moving average
- CRB Industrial Raw Materials Spot Index and its 12-month moving average

**Market Top Indicators:**
1. Commercial paper yield > 12-month MA
2. Bond yields > 12-month MA
3. S&P Index above average (may have broken below 12-month MA)
4. CRB Index above average (if below 12-month MA, less support for stocks)

**Cycle End Indicators:**
1. S&P Index breaks below 12-month MA
2. CRB Index breaks below 12-month MA
3. Typically signals upcoming decline

**Auxiliary Checks:**
- 4-year cycle: If 2-3 years from last 4-year bottom, likely at bull market peak
- Intermediate rally count: 3 identifiable intermediate rallies suggest major market peak

### 3. Interest Rate Impact on Corporate Profits

**Rate Increase Transmission:**
1. Tight monetary policy → Interest rates rise
2. Companies forced to reduce expansion plans and cut inventory
3. **Critical factor:** Speed of adjustment matters more than magnitude
4. Rapid rate hikes → Companies cannot adapt in time → Economic damage
5. Result: Corporate profits decline → P/E ratios fall → Stock prices drop

**Rate Decrease Transmission:**
1. Authorities lower short-term rates when concerned about economy
2. Opposite effects stimulate economic growth

**Key Principle:**
- Most companies can adapt to gradual rate increases
- Rapid rate adjustments cause significant disruption

## Important Constraints

### Commodity-Bond Relationship
- Leading time is inconsistent
- Not every turning point shows perfect leading
- 1920 was an exception (simultaneous reversal)

### Market Cycle Analysis
- Based on historical data (1966-2001)
- Exceptions exist (e.g., 1989, 2001)
- Single signal insufficient for definitive cycle stage determination

### Interest Rate Impact
- Indirect mechanism through business behavior
- Speed of adjustment is critical

## Execution Steps

1. **Assess Commodity Trend:** Check for long-term commodity price turning points
2. **Predict Bond Yield Direction:** Expect bond yields to follow commodity trend
3. **Gather Market Data:** Collect yields, indices, and moving averages
4. **Evaluate Cycle Stage:** Apply top/bottom identification rules
5. **Check Auxiliary Signals:** Verify with 4-year cycle and intermediate rally count
6. **Assess Rate Environment:** Determine if rates are rising/falling rapidly
7. **Synthesize Analysis:** Combine all signals for comprehensive view

## Output Template

Commodity-Bond: {Leading/Following/Neutral} | Cycle Stage: {Top/Middle/Bottom} | Rate Impact: {Positive/Negative} | Confidence: {High/Medium/Low}