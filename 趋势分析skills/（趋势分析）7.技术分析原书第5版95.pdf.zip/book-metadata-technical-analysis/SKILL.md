---
name: book-metadata-technical-analysis
description: 提供《技术分析（原书第5版）》书籍来源元数据，用于引用和版权确认。WHEN：需要引用本书内容、确认版权信息、或核实书籍出版信息时触发。
---

# 书籍来源元数据

## 基本信息

| 项目 | 内容 |
|-----|------|
| 中文书名 | 技术分析（原书第5版） |
| 原书名 | Technical Analysis Explained: The Successful Investor's Guide to Spotting Investment Trends and Turning Points |
| 作者 | （美）普林格（Pring, M. J.） |
| 译者 | 笃恒，王茜 |
| 出版社 | 机械工业出版社 |
| 出版时间 | 2015.12 |
| 丛书系列 | 华章经典·金融投资 |

## 标识信息

| 项目 | 内容 |
|-----|------|
| ISBN | 978-7-111-52601-8 |
| CIP核字号 | （2015）第 311642 号 |
| 版权登记号 | 图字：01-2014-1073 |
| 分类号 | IV.F830.91 (股票市场－分析) |

## 版权限制

- **原版版权**：© 2014 by McGraw-Hill Education
- **中文版版权**：© 2016 by McGraw-Hill Education and China Machine Press
- **销售范围**：仅限中华人民共和国境内（不包括香港、澳门特别行政区及中国台湾地区）
- **防伪标识**：本书封面贴有 McGraw-Hill Education 公司防伪标签，无标签者不得销售

## 领域标签

金融投资、技术分析、书籍元数据