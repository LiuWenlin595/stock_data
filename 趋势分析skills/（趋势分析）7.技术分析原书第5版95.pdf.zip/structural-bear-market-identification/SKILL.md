---
name: structural-bear-market-identification
description: Identify structural bear markets caused by overcapacity and capital misallocation. Use when analyzing long-term market trends, assessing whether a market decline is cyclical or structural, or evaluating the duration and severity of bear markets.
---

# Structural Bear Market Identification

## Overview
Identify long-term bear markets driven by structural factors (overcapacity, capital misallocation) that require multiple business cycles to resolve.

## When to Use
- Assessing if a market decline is cyclical or structural
- Evaluating long-term market outlook
- Estimating bear market duration and severity
- Analyzing historical bubble aftermaths
- Understanding impact of government intervention and demographics

## Core Procedures

### 1. Identify Structural Factor Formation

**Formation Mechanism:**
- Occurs in 10 years preceding secular peak
- Specific sectors/economic sectors experience excessive prosperity
- Results in overbuilding and sustained overcapacity
- Leads to capital misallocation

**Historical Examples:**
- Early 19th century: Canal construction
- 1870s: Railroad construction
- Internet company bubble
- Real estate bubble

### 2. Assess Adjustment Characteristics

**Duration Requirements:**
- Overcapacity requires multiple business cycles to adjust
- Participants' suffering attracts government attention

**Government Intervention Impact:**
- Government measures often complicate problems
- Extend bear market duration
- **Example:** 1930 recession → US raised tariffs to protect overbuilt manufacturing → Other countries retaliated → International trade remained at lows → Worse than zero-sum game

**Demographic Factors (21st Century):**
- Declining workforce
- Working population supporting more non-working elderly
- Government response: Massive deficits (mathematically unsustainable)
- Creates heavy burden on future growth

### 3. Quantitative Identification Criteria

**Historical Averages (Table 23-1):**
- **Duration:** Average 18 years 7 months (range: 16y6m to 19y9m)
- **Recessions:** 4-6 occurrences (vs 2 in 1949-1966, 1 in 1982-2000)
- **P/E Change:** Start 27.3x → End 6.9x (decline ~266%)

**Key Signals:**
- Economy experiencing persistent negative growth
- Repeated recessions intensify disappointment at market lows

### 4. Compare Current Situation to Historical Norms

**2011 Data Assessment:**
- Duration: 11 years 4 months (below 18y7m average)
- Recessions: 2 (below 4-6 average)
- P/E: 44.2 → 20.8 (237% decline, below 266% average)
- **Implication:** Adjustment likely insufficient

## Important Constraints

- Structural adjustment requires multiple business cycles
- Government intervention may prolong bear markets
- Demographic changes add complexity
- Historical precedents provide guidance but not guarantees

## Execution Steps

1. **Check Pre-Peak History:** Identify excessive sector prosperity in preceding 10 years
2. **Assess Overcapacity:** Evaluate extent of overbuilding and capital misallocation
3. **Measure Duration:** Track time since secular peak began
4. **Count Recessions:** Monitor number of economic recessions during period
5. **Evaluate P/E Compression:** Compare current P/E to historical start/end levels
6. **Assess Government Intervention:** Identify policy measures that may extend adjustment
7. **Consider Demographics:** Evaluate workforce and dependency ratio trends
8. **Compare to Historical Norms:** Determine if adjustment is complete based on averages

## Output Template

Structural Factors: {Formed/Forming/None} | Adjustment Duration: {X years} | Recessions: {X} | P/E Compression: {X%} | vs Historical Average: {Above/Below} | Government Intervention Risk: {High/Medium/Low} | Demographic Pressure: {Worsening/Stable/Improving} | Adjustment Complete: {Yes/No/Partial}