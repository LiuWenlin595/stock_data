```markdown
# 技术分析专业技能集

本技能集基于专业技术分析书籍生成，涵盖了从基础理论到高级策略的全方位技术分析能力。这些技能旨在帮助用户进行市场趋势识别、价格形态解读、交易时机选择、动能指标分析以及交易系统的构建与评估。无论是股票、大宗商品还是跨市场资产配置，该集合都能提供系统性的决策支持。

## Available Skills

| Skill | Description | Use When |
|-------|-------------|----------|
| [market-structure-framework](market-structure-framework/SKILL.md) | 当需要进行全面的市场结构分析，整合价格指数、板块轮动、时间维度、成交量和市场广度等多维数据时使用。适用于构建系统性的技术分析框架。 | 构建系统性的技术分析框架 |
| [moving-average-trend-strategy](moving-average-trend-strategy/SKILL.md) | 选择和应用有效移动均线时间跨度判定主要趋势，识别趋势逆转信号，以及使用40周均线进行中期趋势跟踪。 | 需要监测股票指数或大宗商品的主要趋势方向、判定趋势是否逆转、或制定中期趋势跟踪策略时触发。 |
| [envelope-and-bollinger-bands](envelope-and-bollinger-bands/SKILL.md) | 构建包络线和布林带指标，分析价格波动范围和趋势强度。 | 当需要界定价格波动范围、识别支撑/阻力位或判断趋势过度延伸时使用。 |
| [momentum-cycle-identification](momentum-cycle-identification/SKILL.md) | 当使用动能摆荡指标（如ROC）识别价格周期并预警周期逆转时使用。适用于长周期分析（如9.2年周期、82周周期），通过动能极端水平与预期周期位置的背离识别周期失败或逆转。 | 使用动能摆荡指标识别价格周期并预警周期逆转 |
| [market-breadth-new-highs-lows](market-breadth-new-highs-lows/SKILL.md) | 计算和应用净新高累积指标，识别市场广度背离信号，判断大盘趋势强度。 | 分析大盘指数、板块指数或大宗商品的市场广度、需要判断主要趋势是否即将逆转、或识别技术面走强/走弱信号时触发。 |
| [relative-strength-analysis](relative-strength-analysis/SKILL.md) | 构建和解释相对强度(RS)曲线，评估个股或商品相对于基准市场指数的表现强度。 | 当需要比较不同证券的表现、进行个股选股或行业轮动分析时使用。 |
| [technical-investment-principles](technical-investment-principles/SKILL.md) | 当基于技术分析进行股票交易决策、评估市场状况或验证自动交易系统逻辑时，应用此技能遵循七大核心原则，确保决策过程客观、理性且符合长期纪律，避免情绪化交易和认知偏差。 | 基于技术分析进行股票交易决策、评估市场状况或验证自动交易系统逻辑 |
| [momentum-trendline-breakout-trading](momentum-trendline-breakout-trading/SKILL.md) | 当动能指标（摆荡指标）的趋势线被突破，需要结合价格趋势确认判断趋势逆转时使用。适用于动能指标走势图分析，通过动能与价格的联合确认提高信号可靠性。 | 动能指标（摆荡指标）的趋势线被突破，需要结合价格趋势确认判断趋势逆转 |
| [dow-theory-yield-signals](dow-theory-yield-signals/SKILL.md) | Use dividend yield thresholds as auxiliary signals for Dow Theory market timing. Use when attempting to identify market tops and bottoms earlier than traditional Dow Theory confirmation signals, or wh | 尝试比传统道氏理论确认信号更早地识别市场顶部和底部，或... |
| [oscillator-behavior-major-trends-migratory-rule](oscillator-behavior-major-trends-migratory-rule/SKILL.md) | 通过摆动指标在主要行情中的特征变化判断趋势方向（候鸟法则）。 | 使用MACD或RSI分析时，发现指标无法达到正常的超买/超卖区域，或观察到指标行为与常规模式不符时，用于确认当前主要趋势是多头还是空头。 |
| [cycle-psychology-analysis](cycle-psychology-analysis/SKILL.md) | 分析市场周期转折点和市场对新闻的反应，用于判断趋势逆转和投资者情绪。 | 当需要识别周期有效性、评估市场情绪或利用新闻事件判断趋势时使用。 |
| [technical-chart-construction](technical-chart-construction/SKILL.md) | 构建K线图（蜡烛图）和点数图(OX图)，处理价格数据并配置图表参数。 | 当需要绘制技术分析图表或处理OHLC数据时使用。 |
| [market-breadth-indicators](market-breadth-indicators/SKILL.md) | 计算腾落线(AD Line)和扩散指标，衡量市场广度和趋势强度。 | 当需要分析市场整体健康状况、确认趋势或识别潜在转折点时使用。 |
| [volume-oscillator-analysis-2](volume-oscillator-analysis-2/SKILL.md) | 当需要分析成交量动能变化、识别趋势衰竭信号、或确认价格走势的量能配合度时使用。适用于股票和期货成交量分析，必须与价格走势结合确认趋势方向。 | 需要分析成交量动能变化、识别趋势衰竭信号、或确认价格走势的量能配合度 |
| [decennial-pattern-cycle-trading](decennial-pattern-cycle-trading/SKILL.md) | 基于10年周期模式（Decennial Pattern）预测股市年度走势。 | 年份尾数为9或0时，结合12个月ROC指标判断当年及次年的市场大概率方向。必须配合其他技术指标确认，不可单独依赖。 |
| [candlestick-star-patterns](candlestick-star-patterns/SKILL.md) | 当识别到由长实体线和陀螺线/十字线组成的3根K线组合时使用。适用于股票和其他金融产品的K线图分析，识别看涨启明星和看跌黄昏之星及其失败形态。 | 识别到由长实体线和陀螺线/十字线组成的3根K线组合 |
| [candlestick-reversal-patterns](candlestick-reversal-patterns/SKILL.md) | 识别和解读关键蜡烛图反转形态（乌云压顶、执带线），用于判断趋势逆转信号。 | 当在上升趋势或关键价位出现特定K线组合时使用。 |
| [calendar-effects-long-term-patterns](calendar-effects-long-term-patterns/SKILL.md) | 利用节假日效应、日内效应和长期价格形态规模预测市场走势。 | 临近节假日需要判断持仓策略，或交易日收盘前时段考虑交易时机，或识别到长期底部/顶部形态需要预测后续波动幅度时触发。 |
| [elliott-wave-fibonacci-analysis](elliott-wave-fibonacci-analysis/SKILL.md) | 应用艾略特波浪理论和斐波纳契比率分析市场价格周期性波动，预测回调幅度和目标价位。 | 当需要分析波浪结构、测算回调支撑位或预测价格目标时使用。 |
| [chart-pattern-recognition](chart-pattern-recognition/SKILL.md) | 识别经典价格形态（头肩形、双重顶/底、矩形、镳形顶/底），确认形态有效性，测算目标价位。 | 价格图表出现疑似反转或整理形态、需要确认突破信号有效性、或测算价格目标时触发。 |
| [ultra-long-term-stock-selection](ultra-long-term-stock-selection/SKILL.md) | 当从极长期角度（数年至数十年）评估个股趋势，结合相对强度（RS）分析进行选股时使用。适用于周期性股票和长期投资组合构建。 | 从极长期角度（数年至数十年）评估个股趋势，结合相对强度（RS）分析进行选股 |
| [dow-theory-trend-analysis](dow-theory-trend-analysis/SKILL.md) | 应用道氏理论分析市场主要趋势方向、识别趋势逆转信号，以及验证工业指数与交通运输指数的相互确认关系。 | 需要判定股票市场主要趋势方向、确认趋势是否形成或逆转、或发现两指数背离预警时触发。 |
| [economic-expectation-asset-allocation](economic-expectation-asset-allocation/SKILL.md) | 当需要根据投资者对经济走势的预期进行跨资产类别配置时使用。适用于股票、债券和工业商品的趋势判断，基于经济周期预期选择受益资产。 | 需要根据投资者对经济走势的预期进行跨资产类别配置 |
| [logarithmic-vs-arithmetic-scale](logarithmic-vs-arithmetic-scale/SKILL.md) | 选择对数坐标或算术坐标绘制趋势线，判断突破信号的时机差异，确保趋势分析准确性。 | 绘制长期趋势线、判断趋势突破有效性、或价格处于趋势末端加速阶段需要精确判断突破时机时触发。 |
| [double-bottom-volume-test](double-bottom-volume-test/SKILL.md) | 通过双底形态的成交量变化识别底部确认信号。 | 经历长期下跌后，价格反弹后再度折返形成第二个谷底，需要判断做空力量是否衰竭时触发。 |
| [seasonal-cycle-trading-strategy](seasonal-cycle-trading-strategy/SKILL.md) | 当需要基于历史统计的季节性模式（5月清仓效应）、长期周期（10年周期）和短期择时（月底效应）进行股市择时决策时使用。适用于道琼斯工业平均指数和标普综合指数，生成仓位调整、板块轮动和风险控制信号。 | 基于历史统计的季节性模式（5月清仓效应）、长期周期（10年周期）和短期择时（月底效应）进行股市择时决策 |
| [discount-rate-cycle-market-timing](discount-rate-cycle-market-timing/SKILL.md) | 基于美联储贴现率周期预测股市趋势转折。 | 监测到贴现率连续上调接近第3次，或贴现率在低点维持后可能出现上调时，用于判断多头行情终结或确认上升趋势开始。核心规则：'上调3次，股市必跌'法则与15个月/两次上调低点确认法则。 |
| [moving-average-strategies](moving-average-strategies/SKILL.md) | 选择移动均线时间跨度、验证穿越有效性以及使用延后均线过滤虚假信号。 | 当使用移动均线进行趋势分析或交易信号生成时使用。 |
| [etf-investment-mechanisms](etf-investment-mechanisms/SKILL.md) | 当需要通过交易所交易基金（ETF）获得指数敞口，或理解ETF市场结构演变时使用。适用于资产配置扩展至国际股票、债券、商品及货币市场领域。 | 需要通过交易所交易基金（ETF）获得指数敞口，或理解ETF市场结构演变 |
| [inter-market-cycle-analysis](inter-market-cycle-analysis/SKILL.md) | Analyze relationships between bond yields, commodity prices, and stock markets across different cycle stages. Use when identifying long-term trends, predicting market reversals, or understanding how i | 识别长期趋势、预测市场反转，或理解不同周期阶段债券收益率、大宗商品价格与股票市场之间的关系 |
| [consumer-staples-relative-strength-model](consumer-staples-relative-strength-model/SKILL.md) | 基于必需消费品板块与大盘相对强度（XLP/SPY）判断市场趋势和防御性配置时机。 | 需要判断必需消费品板块的相对走势，或评估市场整体风险偏好变化时触发。结合RS曲线背离和KST差值生成信号。 |
| [contrarian-investing-psychology](contrarian-investing-psychology/SKILL.md) | Apply contrarian thinking principles to identify market extremes caused by crowd psychology. Use when market consensus becomes overwhelming, investor emotions reach extremes, or when seeking opportuni | 市场共识变得压倒性、投资者情绪达到极端，或寻求逆向投资机会时 |
| [volume-oscillator-curriculum-guide](volume-oscillator-curriculum-guide/SKILL.md) | 当学习成交量技术分析课程、在第7章基本原理后选择进阶内容，或需要区分通用型与股市专用成交量指标时，提供章节结构导航和学习路径指导。适用于规划成交量分析学习路线和选择合适的指标类型。 | 学习成交量技术分析课程、在第7章基本原理后选择进阶内容，或需要区分通用型与股市专用成交量指标 |
| [commodity-long-term-trend-reversal](commodity-long-term-trend-reversal/SKILL.md) | 当分析大宗商品价格的极长期趋势（数十年周期）并识别趋势逆转时使用。适用于大宗商品价格指数，结合超长期移动均线、ROC指标和趋势线分析判断牛熊转换。 | 分析大宗商品价格的极长期趋势（数十年周期）并识别趋势逆转 |
| [reversal-pattern-recognition](reversal-pattern-recognition/SKILL.md) | 识别头肩底等主要反转形态，通过形态结构和成交量特征判断趋势逆转信号。 | 当需要在市场底部识别反转形态或验证突破有效性时使用。 |
| [net-new-highs-lows-breadth-oscillator](net-new-highs-lows-breadth-oscillator/SKILL.md) | 使用13周净新高/净新低摆荡指标判断全球市场趋势方向。 | 分析MSCI世界指数ETF等全球股票指数，需要区分趋势方向信号与反趋势信号时触发。核心规则：牛市买入信号需指标跌破0后向上逆转，熊市卖出信号需指标高于0时逆转。 |
| [put-call-ratio-sentiment-contrarian](put-call-ratio-sentiment-contrarian/SKILL.md) | 基于看跌/看涨期权比率（Put/Call Ratio）进行逆向情绪分析。 | 期权比率出现极端读数（>125%）或价格与指标形成背离时，用于判断市场情绪极端点并生成反向交易信号。 |
| [seasonal-trading-strategies](seasonal-trading-strategies/SKILL.md) | Implement seasonal trading strategies based on historical monthly patterns. Use when timing market entries and exits, adjusting portfolio allocations between weak (May-October) and strong (November-Ap | 把握市场进出时机，在弱势（5月-10月）和强势（11月-4月）期间调整投资组合配置 |
| [trend-analysis-methodology](trend-analysis-methodology/SKILL.md) | 用于识别、确认和跟踪市场趋势的核心方法论。 | 当需要判断市场处于趋势型还是区间型市场、确定趋势方向、或选择合适的技术指标时使用。 |
| [technical-analysis-toolkit-overview](technical-analysis-toolkit-overview/SKILL.md) | 了解技术分析完整工具体系，选择适当的分析方法应对不同市场场景。 | 需要系统了解技术分析方法、选择适合当前场景的分析工具、或构建综合分析框架时触发。 |
| [coppock-indicator-bottom-fishing](coppock-indicator-bottom-fishing/SKILL.md) | 使用Coppock指标识别长期市场底部买入时机。 | 标普综合指数经历长期下跌后，需要判断是否为可靠的中长期底部时触发。核心规则：指标必须跌破均衡线后向上逆转才产生有效买入信号，顶部无效不可用于卖出。 |
| [relative-strength-analysis-2](relative-strength-analysis-2/SKILL.md) | 应用相对强度（RS）分析个股与大盘的相对表现，识别背离信号，进行跨市场比较（如SPY/EFA比率）。 | 需要评估个股相对大盘强弱、识别领先/滞后股票、进行板块轮动分析、或比较不同市场表现时触发。 |
| [automated-trading-system-design](automated-trading-system-design/SKILL.md) | 自动交易系统设计原则与系统健康度监控。 | 设计新交易系统、评估现有系统有效性、或监测系统是否因市场变化而失效时触发。核心规则：避免历史数据过度拟合，使用300周收益曲线均线监控系统失效。 |
| [nine-month-roc-signals](nine-month-roc-signals/SKILL.md) | 使用9个月ROC指标识别中期到长期趋势转折点。 | 大盘指数的9个月ROC触及-20%或+20%阈值并发生回转穿越时，用于生成底部买入或峰位卖出信号。 |
| [sector-rotation-strategy](sector-rotation-strategy/SKILL.md) | Implement sector rotation strategies based on economic cycle stages. Use when allocating assets across industries, determining whether to favor inflation-sensitive or deflation-sensitive sectors, or c | 在各行业间配置资产，确定是倾向于通胀敏感型还是通缩敏感型板块，或... |
| [technical-psychological-divergence-peaks](technical-psychological-divergence-peaks/SKILL.md) | 通过技术面与心理因素的背离识别市场顶部，以及判断峰位类型（极长期转折点/衰退型顶部/增长型衰退）。 | 市场处于高位区域，观察到利好消息逆向反应、媒体情绪极端、保证金债务信号异常，或需要判断当前顶部性质和持续时间时触发。 |
| [sentiment-momentum-combined-timing](sentiment-momentum-combined-timing/SKILL.md) | 结合人气指标与动能指标（RSI）生成趋势逆转信号。 | 市场走势以震荡区间波动为主，需要判断债券市场或相关资产的中期转折点时触发。适用于巴克莱20年国债ETF等利率敏感型资产。 |
| [relative-strength-trendline-breakout](relative-strength-trendline-breakout/SKILL.md) | 当相对强度（RS）曲线突破其趋势线，需要等待价格确认后采取交易行动时使用。适用于个股与基准指数的相对表现分析，通过RS突破与价格确认的联合信号提高交易可靠性。 | 相对强度（RS）曲线突破其趋势线，需要等待价格确认后采取交易行动 |
| [advance-decline-line-breadth-analysis](advance-decline-line-breadth-analysis/SKILL.md) | 综合运用腾落线（AD Line）、广度摆荡指标和信心比率判断市场趋势和转折点。 | 需要判断市场整体长期趋势、监测大盘与广度指标背离、或确认趋势突破有效性时触发。核心规则：所有信号必须等待大盘指数本身趋势逆转确认后才能采取行动。 |
| [momentum-indicator-strategies](momentum-indicator-strategies/SKILL.md) | 应用动能指标（CMO、随机指标、ADX、RSI、ROC）识别趋势强度变化、超买超卖状态和趋势衰竭信号。 | 需要判断趋势强度是否衰竭、识别超买超卖极端状态、确认趋势改变或启动、或进行多时间周期动能比较时触发。 |
| [futures-spread-relationship-analysis](futures-spread-relationship-analysis/SKILL.md) | 分析期货市场中两种资产价差关系的驱动因素，适用于价差交易、套利机会识别和证券基本面分析。 | 当需要判断价差形成原因、预测价差走势或评估跨品种/跨市场/跨期限交易机会时触发。 |
| [volume-oscillator-analysis](volume-oscillator-analysis/SKILL.md) | 计算和解读上涨/下跌成交量摆荡指标，用于判断市场处于进货还是出货状态，监测价格新高/新低是否得到成交量确认。 | 当需要分析市场资金流向、验证价格趋势或识别背离信号时使用。 |
| [trading-system-evaluation](trading-system-evaluation/SKILL.md) | 综合评估交易系统的最大跌幅和交易频率，判断系统实用性。 | 当需要评估交易系统性能、比较不同系统或进行资金管理决策时使用。 |
| [kst-indicator-calculation](kst-indicator-calculation/SKILL.md) | 计算KST指标、SPK指标以及与RS曲线结合分析趋势转折点。 | 当需要识别短期、中期或长期趋势的动能变化，或需要综合多个时间框架的趋势信号时使用。 |
| [on-balance-volume](on-balance-volume/SKILL.md) | 计算能量潮指标(OBV)，分析市场买卖压力并识别价格趋势背离。 | 当需要分析成交量与价格关系或识别潜在趋势反转时使用。 |
| [three-methods-pattern-trading](three-methods-pattern-trading/SKILL.md) | 识别K线图中上升三法(Rising Three Methods)和下降三法(Falling Three Methods)持续形态，用于判断短期趋势延续并生成交易信号。 | 当用户在分析趋势中的回调/反弹是否为健康盘整、是否应持仓或加仓时触发使用。适用于日线/小时线级别的趋势跟踪交易。 |
| [technical-analysis-timeframe-reliability](technical-analysis-timeframe-reliability/SKILL.md) | 当选择技术分析时间周期或评估不同时间框架下技术信号可靠性时，评估随机噪声对信号质量的干扰程度，并提供多时间框架验证策略。适用于技术分析师、短线交易者和系统交易者确定最优分析周期，避免在噪声过高的短周期中过度交易。 | 选择技术分析时间周期或评估不同时间框架下技术信号可靠性 |
| [cycle-identification](cycle-identification/SKILL.md) | 使用趋势偏离法识别价格周期的高点和低点。 | 当需要识别历史价格数据中的周期性规律时使用。 |
| [single-candlestick-pattern-analysis](single-candlestick-pattern-analysis/SKILL.md) | 当分析单根K线棒线以识别反转信号或解读市场心理时，识别十字线、陀螺线、伞状线等单根形态，并结合趋势位置判断其市场含义。适用于技术分析中判断即时买卖力量对比和潜在趋势转折。 | 分析单根K线棒线以识别反转信号或解读市场心理 |
| [support-resistance-analysis](support-resistance-analysis/SKILL.md) | 识别和评估价格图表中的支撑位与阻力位，确定其重要性等级，并制定相应的交易策略。 | 需要寻找潜在买卖点、设置止损位、判断价格转折点、或评估关键价格水平有效性时触发。 |
| [structural-bear-market-identification](structural-bear-market-identification/SKILL.md) | Identify structural bear markets caused by overcapacity and capital misallocation. Use when analyzing long-term market trends, assessing whether a market decline is cyclical or structural, or evaluati | 分析长期市场趋势，评估市场下跌是周期性的还是结构性的，或评估... |
| [trend-reversal-confirmation](trend-reversal-confirmation/SKILL.md) | 当市场出现部分突破（X点）或需要区分次级折返与主要趋势逆转时使用。基于道氏理论，通过峰位-谷底演进、幅度/时间标准和多重确认信号判断趋势是否真正逆转。 | 市场出现部分突破（X点）或需要区分次级折返与主要趋势逆转 |
| [market-breadth-divergence-analysis](market-breadth-divergence-analysis/SKILL.md) | 当非加权指数或腾落线（AD Line）与大盘指数出现背离，需要判断市场广度与价格走势分歧时使用。通过趋势线突破和移动均线确认识别潜在的趋势逆转。 | 非加权指数或腾落线（AD Line）与大盘指数出现背离，需要判断市场广度与价格走势分歧 |
| [saucer-rounding-pattern-analysis](saucer-rounding-pattern-analysis/SKILL.md) | 当价格走势形成开口向上的弧形/U形（碟形底）或开口向下的弧形（圆形顶），且成交量呈现圆弧状变化时使用。适用于识别缓慢的趋势逆转或整理形态。 | 价格走势形成开口向上的弧形/U形（碟形底）或开口向下的弧形（圆形顶），且成交量呈现圆弧状变化 |
| [ichimoku-cloud-trend-analysis](ichimoku-cloud-trend-analysis/SKILL.md) | 解读一目均衡表云带以判断趋势方向和强度。 | 当需要使用一目均衡表分析价格趋势、识别支撑阻力位或评估趋势动能时使用。 |
| [volume-analysis-rectangular-pattern](volume-analysis-rectangular-pattern/SKILL.md) | 应用成交量分析验证矩形形态突破的有效性，识别假突破信号，测算目标价位。 | 矩形形态出现突破时需要验证信号质量、判断是否为有效突破或假突破、或评估趋势强度时触发。 |
| [fibonacci-time-cycle-analysis](fibonacci-time-cycle-analysis/SKILL.md) | 使用斐波纳契数列分析金融市场重要转折点之间的时间周期，预测潜在的市场反转时间窗口。 | 当分析历史峰位与谷底的时间规律、预测长期周期转折点、或寻找基于斐波纳契数列的潜在时间参考时触发使用。 |
| [weighted-moving-average-calculation](weighted-moving-average-calculation/SKILL.md) | 当简单移动均线滞后性过强，需要更及时地捕捉趋势逆转信号时使用。适用于价格时间序列数据，通过线性递增权重分配提高近期数据敏感度。 | 简单移动均线滞后性过强，需要更及时地捕捉趋势逆转信号 |
| [gap-trading-strategies](gap-trading-strategies/SKILL.md) | 分析开盘缺口形态，制定日内交易策略，判断缺口填补后的趋势方向。 | 出现开盘缺口（高开或低开）、需要制定日内交易计划、或判断缺口后短期趋势方向时触发。 |
| [candlestick-pattern-analysis](candlestick-pattern-analysis/SKILL.md) | 识别关键K线形态（外侧棒、内侧棒、关键逆转棒），判断信号强度，预测短期趋势变化。 | 单根或双根K线出现特殊形态、需要判断短期趋势逆转或加速信号、或评估买卖双方力量平衡变化时触发。 |
| [rsi-extreme-readings-divergence](rsi-extreme-readings-divergence/SKILL.md) | 基于RSI极端读数和摆动不足（divergence）判断买卖时机。 | RSI进入超买/超卖区域，或观察到第二次极端穿越时，用于发出买卖时机警告。注意：仅为时机参考而非实际交易信号，需结合时间跨度评估重要性。 |
| [book-metadata-technical-analysis](book-metadata-technical-analysis/SKILL.md) | 提供《技术分析（原书第5版）》书籍来源元数据，用于引用和版权确认。 | 需要引用本书内容、确认版权信息、或核实书籍出版信息时触发。 |
| [time-price-adjustment-principle](time-price-adjustment-principle/SKILL.md) | 应用时间与趋势调整幅度的关系原则，评估长期趋势逆转后的预期调整幅度和持续时间。 | 分析长期趋势（数年）是否即将逆转、预测趋势逆转后的调整幅度、或判断市场情绪调整是否充分时触发。 |
| [breakaway-gap-buying-strategy](breakaway-gap-buying-strategy/SKILL.md) | 基于突破缺口和折返波动的买入策略。 | 识别到股票出现向上突破缺口，或价格突破形态后出现折返修正时，用于寻找低风险入场点。包含突破缺口三步骤验证和折返波动顺势入场两种场景。 |
| [120-percent-rule-intermarket-system](120-percent-rule-intermarket-system/SKILL.md) | 基于货币市场（倒置短期利率）与股市双重确认的跨市场趋势跟踪系统。 | 需要判断中长期趋势方向，同时监控利率环境和股市反应时触发。核心规则：两个指标（倒置商业票据收益率和标普指数）必须同时向上穿越12个月均线才发出看涨信号。 |
| [symmetrical-triangle-trading](symmetrical-triangle-trading/SKILL.md) | 当价格形成对称三角形（螺旋形态）并在特定区间突破时使用。适用于识别盘整后的强劲突破，测定目标价位，区分有效突破与不可靠突破。 | 价格形成对称三角形（螺旋形态）并在特定区间突破 |
| [stochastic-oscillator](stochastic-oscillator/SKILL.md) | 计算随机指标(%K和%D线)并识别超买超卖信号及趋势反转点。 | 当需要衡量收盘价在交易区间内的位置或识别趋势反转信号时使用。 |
| [trading-system-consistency-evaluation](trading-system-consistency-evaluation/SKILL.md) | 当评估自动交易系统绩效，检验获利来源分布是否健康时使用。适用于历史回测数据分析，识别系统是否过度依赖单一极端行情。 | 评估自动交易系统绩效，检验获利来源分布是否健康 |
| [ultra-long-term-trend-duration](ultra-long-term-trend-duration/SKILL.md) | 评估债券、股票或大宗商品极长期趋势（超级周期）的持续时间特征。 | 当分析跨越数十年的长期趋势、判断当前趋势所处阶段或预测趋势转折时点时使用。适用于技术分析、周期理论研究和资产配置中的长期趋势判断。 |
| [divergence-confirmation-analysis](divergence-confirmation-analysis/SKILL.md) | 分析市场指数、债券市场之间的背离与确认关系，用于判断趋势逆转信号。 | 当需要验证趋势信号、识别市场背离或评估投资者信心时使用。 |
| [bollinger-bands-squeeze-trading](bollinger-bands-squeeze-trading/SKILL.md) | 当观察到布林带宽度收窄至近期低位，需要识别低波动率后的高波动率爆发机会时使用。适用于价格走势分析和波动率交易，捕捉强劲趋势启动点。 | 观察到布林带宽度收窄至近期低位，需要识别低波动率后的高波动率爆发机会 |
| [trend-divergence-indicator](trend-divergence-indicator/SKILL.md) | 计算趋势背离指标（价格摆荡指标），分析价格相对于趋势的波动速度并识别背离。 | 当需要分析价格相对于趋势的波动速度或识别趋势背离时使用。 |
| [sector-rotation-cycles](sector-rotation-cycles/SKILL.md) | 应用板块轮动规律和三市场周期顺序框架，判定商业周期阶段，识别领先与滞后板块，优化资产配置。 | 需要分析股市周期趋势、进行个股选择、定位商业周期位置、或制定跨市场资产配置策略时触发。 |
| [kst-indicator-calculation-2](kst-indicator-calculation-2/SKILL.md) | 当需要分析主要趋势（基于4年商业周期）或捕捉长期趋势转折点时使用。适用于对商业周期敏感的市场，通过加权平滑的ROC指标组合生成趋势信号。 | 需要分析主要趋势（基于4年商业周期）或捕捉长期趋势转折点 |
| [secular-bear-market-valuation](secular-bear-market-valuation/SKILL.md) | 当分析股票市场极长期趋势（数十年周期）的顶部和底部区域，通过估值指标判断市场情绪和心理周期时使用。适用于识别极长期牛熊转换的估值极端和心理学驱动机制。 | 分析股票市场极长期趋势（数十年周期）的顶部和底部区域，通过估值指标判断市场情绪和心理周期 |
| [fibonacci-fan-lines](fibonacci-fan-lines/SKILL.md) | 当分析价格趋势并需要识别动态支撑阻力位，在确定的市场转折点（极点）间应用时使用。适用于技术分析中的趋势回撤和支撑阻力识别。 | 分析价格趋势并需要识别动态支撑阻力位，在确定的市场转折点（极点）间应用 |
| [breakout-volume-confirmation](breakout-volume-confirmation/SKILL.md) | 当价格突破关键形态边界、趋势线或移动平均线，需要通过成交量确认突破有效性时使用。适用于趋势突破确认和支撑阻力位突破分析。 | 价格突破关键形态边界、趋势线或移动平均线，需要通过成交量确认突破有效性 |
| [djia-index-construction](djia-index-construction/SKILL.md) | 当需要理解道琼斯工业平均指数（DJIA）的构建方法、局限性及其作为市场基准的特征时使用。适用于分析价格加权指数的特殊性和成分股影响。 | 需要理解道琼斯工业平均指数（DJIA）的构建方法、局限性及其作为市场基准的特征 |
| [kondratiev-wave-analysis](kondratiev-wave-analysis/SKILL.md) | 当分析跨度为50-54年的极长期经济趋势，识别上升波（通胀期）、过渡期（高原期）和下降波（通缩期）时使用。适用于股票价格、债券和大宗商品的极长期战略配置。 | 分析跨度为50-54年的极长期经济趋势，识别上升波（通胀期）、过渡期（高原期）和下降波（通缩期） |
| [candlestick-pattern-analysis-2](candlestick-pattern-analysis-2/SKILL.md) | 识别单棒、双棒及特定蜡烛图形态（如匹诺曹棒、竭尽缺口），评估其信号强度并制定交易策略。 | 出现延长的涨势或跌势、假突破信号或缺口形态时使用。 |
| [multi-indicator-trend-analysis](multi-indicator-trend-analysis/SKILL.md) | 综合运用趋势指标、动能指标、相对强度(RS)及比例原则，识别市场主要转折点。 | 当需要确认趋势逆转、寻找买卖时机或预测价格折返位时使用。 |
| [price-pattern-identification](price-pattern-identification/SKILL.md) | 识别各类价格形态（矩形、扩散、旗形、三角旗、楔形等），判断其类型（逆转/连续）并预测后续走势。 | 当价格进入水平波动区间或出现特定形态特征时使用。 |
| [support-resistance-analysis-2](support-resistance-analysis-2/SKILL.md) | 识别价格走势中的支撑位和阻力位，理解其定义、角色转换原则及心理机制。 | 当需要定位潜在买卖点、预测价格行为或分析趋势停顿区域时使用。 |
| [roc-momentum-indicator](roc-momentum-indicator/SKILL.md) | 计算和解读ROC（变动率）指标，理解动能指标的领先性特征，在不同市场环境下正确解读超买超卖信号。 | 当需要量化价格变动速度、识别趋势动能变化或预判潜在转折点时使用。 |
| [trendline-drawing-validation](trendline-drawing-validation/SKILL.md) | 绘制有效的趋势线，评估其质量，并判定突破后的走势方向。 | 当需要分析价格趋势、识别支撑阻力区或判断趋势改变时使用。 |

## Quick Navigation

### 基础理论与趋势分析
- **dow-theory-trend-analysis**: 应用道氏理论分析市场主要趋势方向及逆转信号。
- **trend-analysis-methodology**: 识别、确认和跟踪市场趋势的核心方法论。
- **moving-average-trend-strategy**: 使用移动均线判定主要趋势及逆转信号。
- **trendline-drawing-validation**: 绘制有效趋势线并评估突破有效性。
- **logarithmic-vs-arithmetic-scale**: 选择对数或算术坐标以确保趋势分析准确性。

### 图表形态与K线分析
- **chart-pattern-recognition**: 识别头肩形、双重顶/底等经典价格形态。
- **candlestick-star-patterns**: 识别启明星、黄昏之星等K线组合。
- **candlestick-reversal-patterns**: 解读乌云压顶、执带线等反转形态。
- **single-candlestick-pattern-analysis**: 分析单根K线（十字线、陀螺线）的市场含义。
- **reversal-pattern-recognition**: 识别头肩底等主要反转形态。
- **price-pattern-identification**: 识别矩形、旗形、楔形等各类价格形态。

### 动能指标与摆荡指标
- **momentum-indicator-strategies**: 应用RSI、随机指标等识别超买超卖及趋势衰竭。
- **rsi-extreme-readings-divergence**: 基于RSI极端读数和背离判断买卖时机。
- **stochastic-oscillator**: 计算随机指标并识别趋势反转点。
- **kst-indicator-calculation**: 计算KST指标分析多时间框架趋势动能。
- **roc-momentum-indicator**: 解读ROC指标量化价格变动速度。

### 成交量与市场广度
- **volume-oscillator-analysis**: 解读成交量摆荡指标判断进货/出货状态。
- **on-balance-volume**: 计算OBV指标分析买卖压力。
- **market-breadth-indicators**: 计算腾落线和扩散指标衡量市场广度。
- **advance-decline-line-breadth-analysis**: 综合运用广度指标判断市场趋势。
- **market-breadth-new-highs-lows**: 应用净新高累积指标识别背离信号。

### 周期分析与时间选择
- **cycle-identification**: 使用趋势偏离法识别价格周期。
- **seasonal-cycle-trading-strategy**: 基于季节性模式（如5月清仓）进行择时。
- **elliott-wave-fibonacci-analysis**: 应用波浪理论和斐波纳契比率预测目标位。
- **decennial-pattern-cycle-trading**: 基于10年周期模式预测年度走势。
- **kondratiev-wave-analysis**: 分析50-54年的极长期经济趋势。

### 市场心理与情绪分析
- **contrarian-investing-psychology**: 应用逆向思维识别由群体心理造成的市场极端。
- **put-call-ratio-sentiment-contrarian**: 基于期权比率进行逆向情绪分析。
- **cycle-psychology-analysis**: 分析市场对新闻的反应判断趋势逆转。
- **technical-psychological-divergence-peaks**: 通过技术面与心理因素背离识别市场顶部。

### 跨市场分析与资产配置
- **inter-market-cycle-analysis**: 分析债券、商品与股票在不同周期阶段的关系。
- **sector-rotation-strategy**: 基于经济周期阶段实施板块轮动策略。
- **relative-strength-analysis**: 评估个股或商品相对基准的表现强度。
- **economic-expectation-asset-allocation**: 根据经济预期进行跨资产类别配置。

### 交易系统设计与评估
- **automated-trading-system-design**: 设计自动交易系统及监控健康度。
- **trading-system-evaluation**: 评估系统的最大跌幅和实用性。
- **trading-system-consistency-evaluation**: 检验获利来源分布是否健康。
- **technical-investment-principles**: 遵循七大核心原则进行理性交易决策。

## How to Use

当用户提出与技术分析相关的问题时，请按以下步骤操作：

1.  **分析用户意图**：确定用户的需求是关于趋势判断、形态识别、指标计算、周期预测还是系统构建。
2.  **查阅表格或导航**：根据上述"Available Skills"表格或"Quick Navigation"分类，找到最匹配用户问题的技能。
3.  **调用技能**：引用对应的技能文件（例如：`[skill-name](skill-name/SKILL.md)`），应用其中的方法和原则来回答用户的问题。
4.  **综合应用**：对于复杂问题，可能需要结合多个技能（例如：结合趋势分析和成交量分析）来提供全面的解答。
```