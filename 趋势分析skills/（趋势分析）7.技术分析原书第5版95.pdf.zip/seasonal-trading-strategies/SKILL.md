---
name: seasonal-trading-strategies
description: Implement seasonal trading strategies based on historical monthly patterns. Use when timing market entries and exits, adjusting portfolio allocations between weak (May-October) and strong (November-April) periods, or optimizing sector selection based on seasonal performance.
---

# Seasonal Trading Strategies

## Overview
Use historical seasonal patterns to time market entries/exits and optimize sector allocations.

## When to Use
- Planning portfolio allocation for upcoming months
- Timing market entries and exits
- Adjusting sector exposure based on seasonal patterns
- Implementing "Sell in May" strategy

## Core Procedures

### 1. Identify Seasonal Cycle

**Weak Period:**
- **Timeframe:** May to October
- **Characteristics:** Historically worst performing months

**Strong Period:**
- **Timeframe:** November to April
- **Characteristics:** Strong positive signals

### 2. Historical Performance Data

**Jeffrey Hirsch Calculation (62 years):**
- Initial investment: $10,000 in DJIA
- **November-April only:** $674,074
- **May-October only:** -$1,024 (loss)

### 3. Sector Rotation Optimization

**Market Weak Period (May-November):**
- Focus on defensive sectors
- **Outperformers:** Consumer staples, Healthcare
- **Rationale:** These sectors historically perform well during weak periods

**Market Strong Period (November-May):**
- Focus on high-beta sectors
- **Outperformers:** Materials, Industrials
- **Rationale:** These sectors historically outperform during strong periods

**Source:** Sam Stovall research

## Important Constraints

- Based on historical statistics, not absolute guarantees
- Not every May-October period shows losses
- Not every November-April period shows gains
- Strategy has statistical significance but not certainty
- Should be combined with other analysis methods

## Execution Steps

1. **Determine Current Period:** Identify if in weak (May-Oct) or strong (Nov-Apr) period
2. **Assess Market Context:** Consider current market conditions and trends
3. **Adjust Position Size:**
   - Weak period: Consider reducing exposure or defensive posture
   - Strong period: Consider full exposure or offensive posture
4. **Rotate Sectors:**
   - Weak period: Overweight consumer staples, healthcare
   - Strong period: Overweight materials, industrials
5. **Monitor Performance:** Track actual vs expected seasonal patterns
6. **Combine with Other Signals:** Use fundamental/technical analysis for confirmation

## Output Template

Current Period: {Weak (May-Oct)/Strong (Nov-Apr)} | Recommended Position: {Reduce/Increase/Maintain} | Sector Focus: {Defensive/Offensive/Specific sectors} | Historical Success Rate: {High/Medium}