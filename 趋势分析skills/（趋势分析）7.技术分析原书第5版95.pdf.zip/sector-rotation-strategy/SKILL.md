---
name: sector-rotation-strategy
description: Implement sector rotation strategies based on economic cycle stages. Use when allocating assets across industries, determining whether to favor inflation-sensitive or deflation-sensitive sectors, or classifying sectors by their cyclical characteristics.
---

# Sector Rotation Strategy

## Overview
Allocate assets across sectors based on economic cycle position, inflation/deflation environment, and sector characteristics.

## When to Use
- Determining which sectors to overweight/underweight
- Assessing current economic cycle stage
- Building inflation/deflation indicators for sector allocation
- Classifying sectors by cyclical behavior
- Implementing tactical sector shifts

## Core Procedures

### 1. Classify Sectors by Cycle Stage

**Leading Sectors (Liquidity-Driven):**
- Utilities, REITs, Electric Power
- Residential Construction, Telecommunications
- Natural Gas, Non-durable Consumer Goods
- Financial (Brokerage, Banks, Insurance, S&L)
- Beverages, Household Products, Tobacco
- Personal Care, Food, Airlines, Trucking
- Textiles, Railroads, Transportation, Air Freight, Footwear

**Synchronous & Late-Cycle Leading Sectors (Earnings-Driven):**
- Retail, Manufacturing, Healthcare
- Durable Consumer Goods, Auto & Auto Parts
- Furniture & Appliances, Building Materials
- Metal & Glass Containers, Leisure, Hotels
- Waste Management, Energy, Oil, Coal
- Oil Drilling, Mining, Basic Industries
- Paper Products, Chemicals, Steel
- Heavy Machinery, High Tech, Computers
- Electronics, Semiconductors

### 2. Apply Sector Rotation Rules by Cycle Stage

**Late Recession → Early Recovery (Leading Sectors):**
- **Trigger:** Interest rates declining, real estate demand rising
- **Favor:** Residential construction, building materials
- **Favor:** Retail, hotels, cosmetics, tobacco (consumer spending)
- **Favor:** Interest-sensitive: Utilities, telecom, insurance, S&Ls, consumer finance

**Sustained Recovery (Synchronous Sectors):**
- **Trigger:** Inventory depletion from recession period
- **Favor:** Manufacturing (rising RS)

**Late Recovery → Expansion End (Lagging Sectors):**
- **Trigger:** Manufacturing capacity exhausted, capex expansion
- **Favor:** Capital-intensive: Steel, chemicals, mining

**Market Confidence Evolution:**
- **Early bull:** Cautious investors → Favor strong balance sheets, high yield
- **Mid bull:** Rising prices, improving news → Consumer confidence increases
- **Late bull:** Speculation extends to low-quality stocks

### 3. Build Inflation/Deflation Indicators

**Construct Inflation Sector Index:**
- Simple average of S&P Gold, Domestic Oil, Metals, Aluminum indices

**Construct Deflation Sector Index:**
- Electric utilities, banks, insurance companies

**Calculate Ratio:**
- Inflation Index ÷ Deflation Index
- Calculate KST momentum indicator for trend confirmation

**Interpretation:**
- **Ratio downtrend:** Deflationary phase → Favor deflation-sensitive (utilities, financials, early-cycle)
- **Ratio uptrend:** Inflationary phase → Favor inflation-sensitive (gold, oil, metals, late-cycle)

**Simplified Alternative (Data Constraints):**
- IGE (Goldman Sachs Natural Resources ETF) ÷ XLP (SPDR Consumer Staples ETF)
- IGE = Inflation-sensitive
- XLP = Early-cycle leaders (defensive)

**Commodity Sell Signals:**
- Condition A: 18-month ROC of inflation/deflation ratio exceeds +50%
- Condition B: ROC breaks below its MA
- Condition C: ROC breaks below overbought level
- **Trigger:** First signal to appear
- **Implication:** High probability of new trend favoring deflation-sensitive stocks

### 4. Special Sector Exceptions

**Air Transportation:**
- Market bottom: Synchronous or slightly lagging
- Before peak: Often first sector to decline
- **Reason:** Highly sensitive to interest rates and energy prices (both rise late cycle)

**Pharmaceuticals:**
- Market top: Clearly best relative performance (lagging sector)
- Market bottom: May also lag (RS up), but less pronounced than at top

## Important Constraints

- Not all sectors fit neatly into categories
- Not all classifications work in every cycle
- Sector rotation operates in intermediate rallies/corrections, not just long-term
- Avoid single-stock or single-sector comparisons (non-cyclical factors distort)
- Use multi-sector indices to smooth non-cyclical influences

## Execution Steps

1. **Determine Economic Cycle Stage:** Assess recession/recovery/expansion/overheating
2. **Classify Sectors:** Map sectors to leading/synchronous/lagging categories
3. **Build Inflation/Deflation Indicator:** Calculate ratio and KST
4. **Identify Cycle Phase:** Determine inflationary vs deflationary environment
5. **Select Target Sectors:** Choose sectors aligned with cycle stage and inflation phase
6. **Check Exceptions:** Review special cases (airlines, pharmaceuticals)
7. **Monitor Rotation:** Track RS changes to confirm rotation is occurring

## Output Template

Cycle Stage: {Recovery/Expansion/etc} | Inflation Phase: {Inflationary/Deflationary} | Leading Sectors: {list} | Lagging Sectors: {list} | Special Cases: {exceptions}