```markdown
# 技术分析与交易策略技能库

本技能库源自专业投资经典著作，系统化整理了技术分析的核心方法论。涵盖从基础的图表绘制、趋势线分析，到复杂的形态识别、期权定价及投资组合风险管理。无论您是进行市场趋势研判、寻找买卖时机，还是构建风险可控的交易系统，都能在此找到相应的辅助技能。

## Available Skills

| Skill | Description | Use When |
|-------|-------------|----------|
| [期权组合风险与利润评估](期权组合风险与利润评估/SKILL.md) | 评估包含股票和期权的投资组合的风险敞口和盈利能力 | 需要计算期权组合的风险指标或利润效率指标时 |
| [dow-theory-confirmation](dow-theory-confirmation/SKILL.md) | 应用道氏理论相互印证原则监控指数一致性 | 经典技术分析确认趋势变化信号时 |
| [market-breadth-analysis](market-breadth-analysis/SKILL.md) | 构建迈吉评价指数判断市场整体多空力量 | 判断大盘走势、分析市场广度或风险预警时 |
| [trendline-drawing-validation](trendline-drawing-validation/SKILL.md) | 绘制趋势线并判定突破有效性 | 识别趋势方向、判断趋势反转或验证突破信号时 |
| [head-and-shoulders-pattern-analysis](head-and-shoulders-pattern-analysis/SKILL.md) | 分析头肩顶和头肩底形态及价格目标 | 识别头肩形、计算目标价位或确认突破信号时 |
| [dow-theory-market-structure](dow-theory-market-structure/SKILL.md) | 应用道氏理论框架分析市场结构和阶段 | 判断市场整体趋势方向或确定市场周期阶段时 |
| [analysis-methodology-comparison](analysis-methodology-comparison/SKILL.md) | 区分技术分析与基本面分析的差异 | 选择分析方法或理解两种方法的适用场景时 |
| [chart-pattern-analysis](chart-pattern-analysis/SKILL.md) | 识别和确认各种图表形态并计算目标位 | 询问特定形态识别标准或分析价格突破信号时 |
| [chart-construction-and-coordinates](chart-construction-and-coordinates/SKILL.md) | 按标准规范构建股票价格图表并选择坐标系 | 绘制或理解技术分析图表时 |
| [diamond-pattern-analysis](diamond-pattern-analysis/SKILL.md) | 识别钻石形态（复杂头肩形变体） | 形态先扩大振幅后收窄形成钻石状时 |
| [trend-line-analysis](trend-line-analysis/SKILL.md) | 绘制趋势线并选择坐标系分析趋势 | 识别趋势边界和判断长线趋势时 |
| [multiple-top-bottom-pattern-analysis](multiple-top-bottom-pattern-analysis/SKILL.md) | 识别并确认股票的双底、三重顶、三重底等反转形态 | 分析出现2-3个顶部或底部的股票时 |
| [fundamental-analysis-limitations](fundamental-analysis-limitations/SKILL.md) | 评估基本面分析方法的局限性和可靠性 | 使用基本面分析方法进行投资决策时 |
| [commodity-pattern-applicability](commodity-pattern-applicability/SKILL.md) | 判断期货市场适用的技术形态及工具 | 分析期货趋势变化或跨市场交易时 |
| [trading-discipline-and-capital-management](trading-discipline-and-capital-management/SKILL.md) | 建立交易纪律并管理资金投入 | 各个交易阶段确保策略执行和本金保护时 |
| [macd-trend-indicator](macd-trend-indicator/SKILL.md) | 应用MACD识别趋势方向和超买超卖状况 | 询问趋势方向判断或需要确认信号时 |
| [moving-average-calculation](moving-average-calculation/SKILL.md) | 计算简单移动平均线的数值 | 平滑价格趋势分析或绘制MA曲线时 |
| [trendline-effectiveness-validation](trendline-effectiveness-validation/SKILL.md) | 评估上升趋势线的技术效力 | 判断已绘制的趋势线是否可靠时 |
| [technical-analysis-foundation](technical-analysis-foundation/SKILL.md) | 理解技术分析的理论基础、市场前提和流派分类 | 理解技术分析为何有效或区分不同技术分析流派时 |
| [chart-pattern-analysis-principles](chart-pattern-analysis-principles/SKILL.md) | 提供技术分析的通用哲学原则和历史形态应用指导 | 询问技术分析方法论或历史形态可靠性时 |
| [futures-vs-stocks-analysis](futures-vs-stocks-analysis/SKILL.md) | 理解大宗商品期货与股票的固有差异 | 将股票技术分析方法应用于期货市场时 |
| [chart-patterns-identification](chart-patterns-identification/SKILL.md) | 识别和判定图表形态特别是圆顶形态和圆形反转形态 | 分析股票K线图顶部形态或观察到圆润的顶部或底部轮廓时 |
| [投资组合平衡策略](投资组合平衡策略/SKILL.md) | 使用迈吉评价指数进行多空平衡投资实现自然对冲 | 需要根据市场强弱调整多空仓位比例时 |
| [stock-index-analysis](stock-index-analysis/SKILL.md) | 分析主要股票指数及其用途 | 判断大盘趋势、预测经济走势或选择指数作为替代性投资标的时 |
| [obv-calculation-analysis](obv-calculation-analysis/SKILL.md) | 计算能量潮指标分析资金流向验证价格趋势 | 询问成交量分析、资金流向判断或需要通过OBV验证价格趋势可靠性时 |
| [trailing-stop-and-risk-management](trailing-stop-and-risk-management/SKILL.md) | 使用迈吉基准点法执行止损纪律管理持仓风险 | 市场趋势逆转或持仓亏损时保护本金时 |
| [chart-analysis-boundary-guide](chart-analysis-boundary-guide/SKILL.md) | 明确图表分析与量化指标的界限 | 询问技术分析方法适用范围或需要区分图表分析与统计分析时 |
| [moving-average-configuration](moving-average-configuration/SKILL.md) | 选择合适的移动平均线参数和配置策略 | 确定最佳的均线周期组合时 |
| [head-shoulders-consolidation](head-shoulders-consolidation/SKILL.md) | 识别头肩形整固形态和连续圆底形态 | 日线和周线图特别是流通盘较大的股票在长期低迷后的走势分析时 |
| [mechanical-systems-limitation](mechanical-systems-limitation/SKILL.md) | 理解机械交易系统的局限性 | 评估购买或使用机械交易系统时 |
| [triangle-pattern-analysis](triangle-pattern-analysis/SKILL.md) | 完整分析三角形形态包括时间框架有效性评估 | 识别三角形形态、判断其有效性、确认突破方向、计算目标价位时 |
| [chart-maintenance-standards](chart-maintenance-standards/SKILL.md) | 建立并遵循系统化的图表制作和维护流程 | 技术分析师、手工绘图者和使用软件的投资者进行技术分析时 |
| [最优资金管理策略](最优资金管理策略/SKILL.md) | 应用最优f值公式和杠杆空间组合模型确定资金分配比例 | 确定每笔交易的本金冒险比例或在多个市场同时交易时 |
| [交易风险规模计算与监控](交易风险规模计算与监控/SKILL.md) | 计算单笔交易的合理仓位规模并监控投资组合的整体风险暴露 | 确定新交易的股票数量或需要评估投资组合整体风险时 |
| [double-top-bottom-patterns](double-top-bottom-patterns/SKILL.md) | 确认双底和双顶形态的有效性根据突破信号执行买入或卖出策略 | 股票走势图的反转形态分析帮助识别趋势的转折点时 |
| [investor-positioning-and-strategy](investor-positioning-and-strategy/SKILL.md) | 根据性格、时间和风险承受能力确定投资类型和操作策略 | 所有市场参与者在进入市场前或制定交易计划时进行自我定位时 |
| [dow-theory-signal-validation](dow-theory-signal-validation/SKILL.md) | 应用道氏理论验证趋势信号的有效性 | 确认趋势反转信号、验证突破是否有效或判断当前趋势是否持续时 |
| [portfolio-construction](portfolio-construction/SKILL.md) | 构建股票投资组合的筛选标准 | 构建技术分析股票组合、选股池或需要确定合适的投资标的时 |
| [double-top-pattern-recognition](double-top-pattern-recognition/SKILL.md) | 识别双顶反转形态将其与整固形态区分 | 观察到两个高度相近的股价高点需要判断是否为双顶形态时 |
| [stop-loss-management](stop-loss-management/SKILL.md) | 设置和管理止损位 | 建立仓位后需要设置止损、控制单笔交易风险时 |
| [金融基础指标计算](金融基础指标计算/SKILL.md) | 计算波动率（标准差）和夏普比率等传统金融指标 | 需要计算资产的历史波动性或需要评估投资组合的风险调整后收益时 |
| [dow-theory-enhancement](dow-theory-enhancement/SKILL.md) | 基于个股技术分析的道氏理论增强策略及迈吉基准点替代法 | 追求比道氏理论更高的收益或需要具体选股指导时 |
| [stock-selection-by-volatility](stock-selection-by-volatility/SKILL.md) | 根据波动性和走势特征筛选交易标的区分投机型与保守型股票 | 技术分析交易者和选股人员在筛选交易标的时确定股票风格时 |
| [rounding-bottom-pattern-evolution](rounding-bottom-pattern-evolution/SKILL.md) | 分析连续圆底形态的价格演变特征 | 股票呈现连续圆底形态需要根据价格水平预测后续走势变化时 |
| [triangle-wedge-patterns](triangle-wedge-patterns/SKILL.md) | 识别三角形和楔形形态判断趋势方向及突破时机 | 日线、周线、月线图的技术分析包括对称三角形、上升/下降三角形及上升/下降楔形时 |
| [etf-passive-investing](etf-passive-investing/SKILL.md) | 基于ETF的长线被动指数投资策略 | 目标是击败市场且公募基金、追求稳健收益或希望简化投资流程时 |
| [dow-theory-signals](dow-theory-signals/SKILL.md) | 识别道氏理论的牛市和熊市信号处理信号失效机制 | 询问道琼斯指数信号、需要确认长线趋势反转或处理指数突破和确认时 |
| [volatility-analysis-by-price-level](volatility-analysis-by-price-level/SKILL.md) | 分析低价股与高价股的波动性差异 | 需要评估不同价位的股票潜力、计算预期收益率或理解价格水平对投资回报的影响时 |
| [box-rectangle-pattern-analysis](box-rectangle-pattern-analysis/SKILL.md) | 识别箱体/矩形形态的特征判断其可靠性 | 股票在水平阻力位和支撑位之间震荡或需要根据箱体形态测算目标价格时 |
| [rsi-indicator-analysis](rsi-indicator-analysis/SKILL.md) | 应用怀尔德相对强弱指标(RSI)识别价格顶部和底部 | 询问超买超卖、RSI背离、失败波动或需要补充柱状图分析时 |
| [wedge-triangle-pattern-discrimination](wedge-triangle-pattern-discrimination/SKILL.md) | 区分楔形形态与三角形形态验证楔形形态的有效性 | 在价格图表上观察到收敛形态需要判断是楔形还是三角形时 |
| [dynamic-stop-loss](dynamic-stop-loss/SKILL.md) | 动态管理持仓止损价格保护利润控制风险 | 持有股票价格上涨或市场条件变化需要重新评估并调整止损价格时 |
| [rounding-reversal-analysis](rounding-reversal-analysis/SKILL.md) | 分析圆形反转形态（圆底和圆顶）重点分析成交量演变规律 | 需要识别圆底/圆顶、分析其成交量特征、判断长线趋势反转时 |

## Quick Navigation

### 市场趋势与理论基础
- **technical-analysis-foundation**: 建立技术分析理论基础
- **dow-theory-market-structure**: 应用道氏理论分析市场结构
- **dow-theory-signals**: 识别道氏理论牛熊信号
- **dow-theory-confirmation**: 应用道氏理论相互印证原则
- **dow-theory-signal-validation**: 验证道氏理论趋势信号有效性
- **dow-theory-enhancement**: 基于个股的道氏理论增强策略
- **market-breadth-analysis**: 构建迈吉评价指数判断市场多空力量
- **analysis-methodology-comparison**: 区分技术与基本面分析
- **chart-pattern-analysis-principles**: 理解历史形态应用原则

### 图表形态识别
- **head-and-shoulders-pattern-analysis**: 分析头肩顶底形态
- **head-shoulders-consolidation**: 识别头肩形整固形态
- **triangle-pattern-analysis**: 完整分析三角形形态
- **triangle-wedge-patterns**: 识别三角形和楔形形态
- **wedge-triangle-pattern-discrimination**: 区分楔形与三角形形态
- **multiple-top-bottom-pattern-analysis**: 识别双底三顶三底形态
- **double-top-bottom-patterns**: 确认双底和双顶形态
- **double-top-pattern-recognition**: 识别双顶反转形态
- **diamond-pattern-analysis**: 识别钻石形态
- **chart-pattern-analysis**: 识别和确认各种图表形态
- **chart-patterns-identification**: 识别圆顶和圆形反转形态
- **rounding-reversal-analysis**: 分析圆形反转形态
- **rounding-bottom-pattern-evolution**: 分析连续圆底形态演变
- **box-rectangle-pattern-analysis**: 识别箱体/矩形形态

### 技术指标与工具
- **trendline-drawing-validation**: 绘制趋势线并判定突破
- **trendline-effectiveness-validation**: 评估趋势线技术效力
- **trend-line-analysis**: 绘制趋势线并分析趋势
- **moving-average-calculation**: 计算移动平均线数值
- **moving-average-configuration**: 选择移动平均线参数
- **macd-trend-indicator**: 应用MACD指标
- **rsi-indicator-analysis**: 应用RSI指标
- **obv-calculation-analysis**: 计算能量潮指标
- **chart-construction-and-coordinates**: 构建标准图表
- **chart-maintenance-standards**: 建立图表制作和维护流程
- **chart-analysis-boundary-guide**: 明确图表分析界限

### 风险管理与资金控制
- **stop-loss-management**: 设置和管理止损位
- **dynamic-stop-loss**: 动态管理持仓止损价格
- **trailing-stop-and-risk-management**: 使用迈吉基准点法执行止损
- **交易风险规模计算与监控**: 计算单笔交易合理仓位规模
- **最优资金管理策略**: 应用最优f值确定资金分配比例
- **trading-discipline-and-capital-management**: 建立交易纪律并管理资金
- **金融基础指标计算**: 计算波动率和夏普比率

### 期权与期货交易
- **期权组合风险与利润评估**: 评估期权组合风险敞口和盈利能力
- **commodity-pattern-applicability**: 判断期货市场适用的技术形态
- **futures-vs-stocks-analysis**: 理解期货与股票差异

### 投资组合与策略构建
- **portfolio-construction**: 构建股票投资组合筛选标准
- **投资组合平衡策略**: 使用迈吉评价指数进行多空平衡
- **stock-selection-by-volatility**: 根据波动性筛选交易标的
- **stock-index-analysis**: 分析主要股票指数
- **etf-passive-investing**: 基于ETF的长线被动指数投资
- **volatility-analysis-by-price-level**: 分析不同价位波动性差异
- **investor-positioning-and-strategy**: 确定投资类型和操作策略

### 分析框架与认知
- **fundamental-analysis-limitations**: 评估基本面分析局限性
- **mechanical-systems-limitation**: 理解机械交易系统局限性

## How to Use

1. **识别需求**：明确当前任务类型（如形态识别、风险管理、策略构建等）
2. **选择技能**：根据上述分类导航至相关技能，或在表格中搜索关键词
3. **调用技能**：使用技能路径（如 `support-resistance-analysis`）调用具体技能文件
4. **组合应用**：复杂任务可组合多个技能，如先进行形态识别，再计算仓位规模
```