# 外部量化分析参考资源

## 推荐作者及著作

### 1. 墨菲（John J. Murphy）

**主要贡献**：
- 技术分析的集大成者
- 涵盖了多种量化指标和统计方法

**推荐著作**：
- 《Technical Analysis of the Financial Markets》
- 《The Visual Investor》

### 2. 柯克帕特里克（Charles D. Kirkpatrick）

**主要贡献**：
- 技术分析的系统化方法
- 量化指标的应用

**推荐著作**：
- 《Technical Analysis: The Complete Resource for Financial Market Technicians》

### 3. 考夫曼（Perry J. Kaufman）

**主要贡献**：
- 交易系统设计
- 量化方法在交易中的应用

**推荐著作**：
- 《Trading Systems and Methods》
- 《New Trading Systems and Methods》

## 常见量化指标类型

### 动量指标
- RSI（相对强弱指标）
- 随机指标（Stochastic）
- 威廉指标（Williams %R）

### 趋势跟踪指标
- 移动平均线（MA）
- MACD（指数平滑异同移动平均线）
- 抛物线转向指标（SAR）

### 波动性指标
- 布林带（Bollinger Bands）
- ATR（平均真实波幅）

### 成交量指标
- OBV（能量潮）
- 成交量移动平均线