```markdown
# 海龟交易法则与系统化交易技能集

本技能集源自专业书籍，涵盖了从海龟交易法则的系统化构建、趋势跟踪策略设计，到风险控制、绩效评估以及交易心理与职业危机管理的全方位知识。旨在帮助用户建立稳健的交易系统，应对市场波动，并提升在高压环境下的决策能力。

## Available Skills

| Skill | Description | Use When |
|-------|-------------|----------|
| [financial-crisis-management](financial-crisis-management/SKILL.md) | 财务危机应对和职业转型的步骤，用于在资产归零或现金流断裂时的危机处理。 | 面临资产几乎归零、现金流断裂或需要紧急调整职业规划时。 |
| [change-management-without-authority](change-management-without-authority/SKILL.md) | 当顾问或基层员工在没有正式权力、预算或下属的情况下需要推动组织变革时使用。 | 在资源匮乏的环境中，需要通过影响力、说服技巧和沟通策略实现变革目标。 |
| [trend-following-trading-discipline](trend-following-trading-discipline/SKILL.md) | 趋势跟踪交易中的持仓纪律、心理控制和买强卖弱策略，用于在趋势行情中保持纪律并优化市场选择。 | 需要在趋势回调时维持头寸、选择交易市场或控制交易心理时。 |
| [turtle-trading-system-setup](turtle-trading-system-setup/SKILL.md) | 当建立或运行海龟交易系统时，执行市场选择、流动性筛选、头寸规模四层限制的全流程配置。 | 适用于数百万美元级期货账户、系统化趋势跟踪策略的初始搭建与日常风控。 |
| [turtle-trading-essentials](turtle-trading-essentials/SKILL.md) | 介绍海龟交易法则的起源、四大核心原则及执行纪律。 | 当用户询问海龟交易背景、核心哲学、如何评判交易表现或需要建立系统化交易基础时。 |
| [trading-system-design-optimization](trading-system-design-optimization/SKILL.md) | 交易系统简化原则、交易者效应防范和系统分散化组合策略，用于设计稳健的交易系统。 | 需要设计或优化交易系统、防范策略失效或构建多系统组合时。 |
| [turtle-trading-position-management](turtle-trading-position-management/SKILL.md) | 海龟交易法则中的头寸规模计算、账户规模缩减和止损策略管理，用于控制交易风险和资金管理。 | 需要确定交易头寸数量、管理账户风险或设置止损时。 |
| [resilience-and-failure-recovery-mindset](resilience-and-failure-recovery-mindset/SKILL.md) | 当创业者或追梦人遭遇重大失败、陷入恐惧瘫痪时，建立"恐惧脱敏-失败学习-持续迭代"的心理韧性框架。 | 适用于创业失败、项目崩盘、职业转型受挫等场景。 |
| [turtle-trader-selection](turtle-trader-selection/SKILL.md) | 用于组建交易团队时执行海龟交易员选拔流程，包括招募规模设定、核心标准制定、背景多样性考虑和面试内容设计。 | 需要选拔系统化交易员、量化交易人才或构建高智商交易团队时。 |
| [trading-system-sample-size-assessment](trading-system-sample-size-assessment/SKILL.md) | 当测试新交易法则或评估交易系统有效性时，判断样本规模是否充足、识别低频法则的统计局限性。 | 适用于量化策略回测、交易系统开发、策略优化阶段。 |
| [entry-signal-evaluation](entry-signal-evaluation/SKILL.md) | E-比率（优势率）的计算方法、解读标准及其在趋势跟踪策略中的应用，用于量化评估入市信号的有效性。 | 需要评估入市信号是否具有统计优势、比较不同入市策略或理解趋势跟踪的时间维度时。 |
| [market-selection-entry-systems](market-selection-entry-systems/SKILL.md) | 市场筛选排除规则和布林格突破系统交易规则，用于选择合适的交易市场和执行趋势跟踪策略。 | 需要评估是否将某市场纳入投资组合或执行布林格突破系统时。 |
| [risk-management-framework](risk-management-framework/SKILL.md) | 评估交易系统风险、设定风险水平、应对价格动荡和衰落期。 | 需要量化系统风险、设定仓位上限、评估历史回撤真实性或准备应对极端市场事件时。 |
| [sharpe-ratio-evaluation](sharpe-ratio-evaluation/SKILL.md) | 夏普比率和稳健夏普比率的计算方法、适用场景和限制，用于评估交易系统的风险调整收益。 | 需要评估交易策略绩效、比较不同系统表现或识别过度拟合时。 |
| [management-empathy-through-bottom-up-experience](management-empathy-through-bottom-up-experience/SKILL.md) | 当管理者缺乏被管理经验、难以建立下属同理心时，通过主动获取底层工作体验来弥补管理盲区。 | 适用于新任管理者、空降高管、技术转管理岗位人员。 |
| [trend-following-systems](trend-following-systems/SKILL.md) | 选择和设计趋势跟踪系统，包括唐奇安通道、移动均线系统和突破策略。 | 需要比较不同趋势跟踪系统类型、设计入场出场规则或评估止损对趋势系统的影响时。 |
| [trader-performance-assessment](trader-performance-assessment/SKILL.md) | 区分交易者业绩中运气与技能的原则和方法，用于评估交易者或基金的真实能力。 | 需要评估交易者或基金业绩、判断历史记录的可靠性或识别真正的优秀交易者时。 |
| [market-dynamics-structure](market-dynamics-structure/SKILL.md) | 分析市场结构、支撑阻力形成机制、市场分类和参与者行为。 | 需要理解支撑阻力位的心理基础、选择适合趋势跟踪的市场类型或解释市场恐慌时的价格变动时。 |
| [strategy-evaluation-longevity](strategy-evaluation-longevity/SKILL.md) | 评估策略寿命、选择长期有效的策略并使用R立方指标评估风险调整回报。 | 需要选择长期策略、评估策略被模仿的风险或使用稳健指标比较系统时。 |
| [optimization-overfitting-avoidance](optimization-overfitting-avoidance/SKILL.md) | 优化交易系统参数并检测过度拟合。 | 需要调整系统参数、识别曲线拟合风险或解读蒙特卡洛模拟结果时。 |
| [position-sizing-expectancy](position-sizing-expectancy/SKILL.md) | 计算交易期望值、确定头寸规模和验证交易优势。 | 需要计算仓位大小、评估策略是否值得执行、确定止损位置或验证系统是否具有正期望值时。 |
| [decision-psychology-trading](decision-psychology-trading/SKILL.md) | 克服交易和学习过程中的心理障碍，包括沉没成本谬误和对犯错的恐惧。 | 难以执行交易系统、害怕犯错或需要做出退出决策（职业、投资、关系）时。 |
| [backtesting-statistical-validation](backtesting-statistical-validation/SKILL.md) | 验证交易系统回测的统计有效性，识别历史测试与实盘差异的原因。 | 需要评估回测结果是否可信、样本是否充足或解释为什么实盘表现不如历史测试时。 |
| [hedging-strategies](hedging-strategies/SKILL.md) | 设计套期保值策略以隔离原材料价格或汇率波动风险。 | 企业面临大宗商品价格波动或外汇风险，需要通过金融工具对冲经营风险时。 |

## Quick Navigation

### 海龟交易核心
- **turtle-trading-essentials**: 海龟交易法则的起源、核心原则及执行纪律基础。
- **turtle-trading-system-setup**: 海龟交易系统的全流程配置，包括市场选择与风控。
- **turtle-trading-position-management**: 头寸规模计算、账户缩减与止损策略。
- **turtle-trader-selection**: 交易团队组建与海龟交易员选拔流程。

### 交易系统设计与策略
- **trend-following-systems**: 唐奇安通道、移动均线等趋势跟踪系统的设计。
- **trading-system-design-optimization**: 系统简化原则、防范交易者效应及分散化组合。
- **market-selection-entry-systems**: 市场筛选规则与布林格突破系统执行。
- **entry-signal-evaluation**: 使用E-比率量化评估入市信号的有效性。
- **strategy-evaluation-longevity**: 评估策略寿命及使用R立方指标。

### 风险管理与资金控制
- **risk-management-framework**: 系统风险评估、风险水平设定及应对动荡。
- **position-sizing-expectancy**: 计算期望值、确定头寸规模及验证交易优势。
- **hedging-strategies**: 设计套期保值策略以隔离大宗商品或汇率风险。

### 统计分析与评估
- **backtesting-statistical-validation**: 验证回测统计有效性，识别历史与实盘差异。
- **trading-system-sample-size-assessment**: 判断样本规模充足性及低频法则的局限性。
- **sharpe-ratio-evaluation**: 计算夏普比率评估风险调整收益。
- **optimization-overfitting-avoidance**: 参数优化与过度拟合检测。
- **trader-performance-assessment**: 区分业绩中的运气与技能。

### 心理与职业发展
- **trend-following-trading-discipline**: 趋势交易中的持仓纪律与心理控制。
- **decision-psychology-trading**: 克服沉没成本谬误和对犯错的恐惧。
- **resilience-and-failure-recovery-mindset**: 建立心理韧性框架，应对失败与恐惧。
- **financial-crisis-management**: 资产归零或现金流断裂时的危机应对与转型。
- **change-management-without-authority**: 在无正式权力的情况下推动组织变革。
- **management-empathy-through-bottom-up-experience**: 通过底层体验提升管理同理心。

### 市场基础
- **market-dynamics-structure**: 分析市场结构、支撑阻力机制及参与者行为。

## How to Use
这些技能旨在帮助您在交易、管理和个人决策中取得更好的成果。您可以直接描述您面临的问题或目标，Claude 将根据上下文自动调用最相关的技能。例如：
- 如果您想了解如何开始构建趋势交易系统，可以询问“如何建立海龟交易系统？”
- 如果您正在经历交易亏损并感到恐慌，可以询问“如何在交易失败后恢复心态？”
- 如果您需要评估某个策略是否值得投入，可以询问“如何计算这个策略的期望值？”
```