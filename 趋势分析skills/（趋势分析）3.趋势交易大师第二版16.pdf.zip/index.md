```markdown
# 趋势交易与风险管理技能集

本技能集基于专业技术交易书籍提炼而成，旨在帮助交易者和投资者掌握系统的趋势交易方法、风险控制技巧以及资金管理策略。核心内容涵盖顾比复合移动平均线（GMMA）的应用、趋势突破与回调入场策略、动态止损管理、以及从新手到专职交易者的成长路径。通过这些技能，用户可以建立完整的交易系统，有效识别市场趋势，并在保护本金的前提下追求资本增值。

## Available Skills

| Skill | Description | Use When |
|-------|-------------|----------|
| [guppy-countdown-exit-strategy](guppy-countdown-exit-strategy/SKILL.md) | 使用顾比倒数线进行趋势交易的退出决策，保护利润并识别趋势反转。 | 持有多头或空头仓位，需要根据趋势变化决定退出时。 |
| [two-percent-rule-risk-management](two-percent-rule-risk-management/SKILL.md) | 应用2%规则进行交易资本分类管理和心理风险控制。 | 需要控制单笔交易风险，或心理承受力与2%规则金额冲突时。 |
| [gmmt-trend-analysis](gmmt-trend-analysis/SKILL.md) | 使用顾比复合移动平均线（GMMA）分析趋势强度、稳定性及反转信号。 | 评估趋势健康度、判断价格反弹性质或寻找低风险入场点时。 |
| [trader-learning-path](trader-learning-path/SKILL.md) | 指导新手交易者从业余兼职逐步发展为专职交易者的完整学习路径。 | 规划交易员职业发展路径，从新手到专职的进阶时。 |
| [price-bubble-trading-strategy](price-bubble-trading-strategy/SKILL.md) | 识别价格泡沫类型并执行对应的投机交易策略。 | 上升趋势中出现价格泡沫，需要识别类型并执行投机策略时。 |
| [gmma-trend-breakout-identification](gmma-trend-breakout-identification/SKILL.md) | 使用GMMA识别真正的趋势突破，区分暂时价格反弹与趋势反转。 | 价格突破趋势线后，需要验证是否为真正的趋势反转时。 |
| [cost-averaging-timing-sensitivity-analysis](cost-averaging-timing-sensitivity-analysis/SKILL.md) | 分析成本平均法在不同市场环境下对进场时间的敏感性。 | 评估定期定额投资在不同市场时机下的表现时。 |
| [guppy-countback-stop-loss-management](guppy-countback-stop-loss-management/SKILL.md) | 在上升趋势中使用顾比倒数线进行动态止损管理。 | 上升趋势中需要动态追踪止损以保护利润时。 |
| [trading-system-framework](trading-system-framework/SKILL.md) | 构建完整交易系统的框架，涵盖要素检查、股票筛选和纪律建立。 | 构建完整交易系统、评估系统完整性或筛选股票时。 |
| [layered-capital-allocation-strategy](layered-capital-allocation-strategy/SKILL.md) | 采用分层配置策略在保护本金的前提下实现资金快速增长。 | 需要在保护本金的前提下实现资金快速增长时。 |
| [trendline-trading-management](trendline-trading-management/SKILL.md) | 使用趋势线进行趋势交易管理，包括绘制、入场和退出。 | 使用趋势线进行交易管理，包括入场、验证和退出时。 |
| [trend-trading-passenger-strategy](trend-trading-passenger-strategy/SKILL.md) | 采用“搭便车”式的趋势交易策略，放弃预测，专注跟随。 | 无法时刻盯盘，希望采用“搭便车”方式跟随趋势时。 |
| [trend-continuation-pullback-entry](trend-continuation-pullback-entry/SKILL.md) | 在强势上升趋势的回调中寻找买入机会。 | 强势上升趋势中出现回调，判断是买入机会还是趋势崩溃时。 |
| [guppy-multiple-moving-average-core](guppy-multiple-moving-average-core/SKILL.md) | 使用GMMA分析趋势特征、验证信号及理解市场参与者行为。 | 分析趋势特征、验证指标信号或理解市场参与者行为时。 |
| [trend-breakout-entry-strategy](trend-breakout-entry-strategy/SKILL.md) | 在价格突破下跌趋势或横盘整理时确定入场时机。 | 价格从下跌或横盘突破，出现趋势改变信号需要确定入场时机时。 |
| [position-sizing-risk-management](position-sizing-risk-management/SKILL.md) | 计算具体持仓规模以控制风险，设置止损位。 | 计算具体持仓规模、设置止损位或管理交易资金时。 |

## Quick Navigation

### 核心概念与框架
- **[trading-system-framework](trading-system-framework/SKILL.md)**: 构建完整交易系统的八要素框架与筛选检验。
- **[trader-learning-path](trader-learning-path/SKILL.md)**: 从业余到专职交易者的进阶学习路径。
- **[guppy-multiple-moving-average-core](guppy-multiple-moving-average-core/SKILL.md)**: 顾比复合移动平均线（GMMA）的核心应用逻辑。

### 趋势分析与识别
- **[gmmt-trend-analysis](gmmt-trend-analysis/SKILL.md)**: 分析趋势强度、稳定性及反转信号。
- **[gmma-trend-breakout-identification](gmma-trend-breakout-identification/SKILL.md)**: 识别真正的趋势突破与假反弹。
- **[trendline-trading-management](trendline-trading-management/SKILL.md)**: 趋势线的绘制与交易管理。

### 入场策略
- **[trend-breakout-entry-strategy](trend-breakout-entry-strategy/SKILL.md)**: 趋势突破时的入场时机选择。
- **[trend-continuation-pullback-entry](trend-continuation-pullback-entry/SKILL.md)**: 趋势回调中的低风险入场点。
- **[price-bubble-trading-strategy](price-bubble-trading-strategy/SKILL.md)**: 价格泡沫的识别与投机交易。

### 退出与风险管理
- **[guppy-countdown-exit-strategy](guppy-countdown-exit-strategy/SKILL.md)**: 基于顾比倒数线的退出决策。
- **[guppy-countback-stop-loss-management](guppy-countback-stop-loss-management/SKILL.md)**: 上升趋势中的动态止损管理。
- **[position-sizing-risk-management](position-sizing-risk-management/SKILL.md)**: 持仓规模计算与风险控制。
- **[two-percent-rule-risk-management](two-percent-rule-risk-management/SKILL.md)**: 2%资金规则与心理风险管理。

### 资金与组合管理
- **[layered-capital-allocation-strategy](layered-capital-allocation-strategy/SKILL.md)**: 分层资金配置策略。
- **[cost-averaging-timing-sensitivity-analysis](cost-averaging-timing-sensitivity-analysis/SKILL.md)**: 成本平均法的时间敏感性分析。

### 交易心态与风格
- **[trend-trading-passenger-strategy](trend-trading-passenger-strategy/SKILL.md)**: “搭便车”式的被动趋势跟随策略。

## How to Use
这些技能旨在作为交易决策的辅助工具。当您提出与市场分析、交易执行或风险管理相关的问题时，我会根据您的具体场景自动调用最相关的技能。例如，如果您询问“如何判断这次突破是否有效”，我将使用 `gmma-trend-breakout-identification` 技能来辅助分析；如果您询问“我该买入多少股”，我将使用 `position-sizing-risk-management` 技能来帮您计算。
```