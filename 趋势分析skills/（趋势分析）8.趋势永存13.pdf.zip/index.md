```markdown
# 量化投资与动量策略技能集

本技能集源自专业投资著作，涵盖了量化投资策略构建、动量投资实施、风险控制及基金分析等核心领域。这些技能旨在帮助用户建立系统化的投资框架，避免常见的回测陷阱，优化资金管理，并深入理解主动与被动投资的差异。通过这些技能，Claude 能够协助用户进行从策略设计、参数设置到执行与复盘的全流程决策。

## Available Skills

| Skill | Description | Use When |
|-------|-------------|----------|
| [active-fund-underperformance-analysis](active-fund-underperformance-analysis/SKILL.md) | 分析主动管理型共同基金长期跑输基准指数的统计规律和结构性原因。 | 评估主动基金投资价值、比较主动基金与指数基金表现、或分析基金经理主动管理能力时。 |
| [momentum-window-parameter-setting](momentum-window-parameter-setting/SKILL.md) | 设置动量策略的时间窗口参数，特别是选择90日中期窗口。 | 用户需要确定动量计算的时间窗口长度、询问参数优化问题、或讨论如何避免过度优化时。 |
| [etf-screening-and-avoidance-rules](etf-screening-and-avoidance-rules/SKILL.md) | 用于评估和筛选ETF产品，识别并排除高风险或非被动投资的ETF。 | 任何ETF投资决策前的产品审查阶段，包括初次接触新ETF、对比多个ETF或验证现有持仓合规性时。 |
| [ban-post-hoc-parameter-optimization](ban-post-hoc-parameter-optimization/SKILL.md) | 在量化策略回测和复盘过程中，防止基于已知历史结果修改策略参数以避免过拟合陷阱。 | 发现历史表现不佳并试图通过调整参数来“修复”过去时触发。 |
| [mutual-fund-tracking-error-budget](mutual-fund-tracking-error-budget/SKILL.md) | 评估共同基金表现或制定基金管理策略，涵盖相对投资目标、基准表现规则及跟踪误差预算。 | 评估共同基金表现或制定基金管理策略时。 |
| [momentum-strategy-fundamentals](momentum-strategy-fundamentals/SKILL.md) | 解释动量投资的核心哲学，区分股票动量与期货趋势跟踪，验证策略逻辑基础。 | 需要理解动量投资核心哲学、区分股票动量与期货趋势跟踪、或验证策略逻辑基础时。 |
| [stock-selection-ranking-system](stock-selection-ranking-system/SKILL.md) | 用于筛选动量股票、建立排名系统、替换持仓股票或确定买入名单。 | 筛选动量股票、建立排名系统、替换持仓股票或确定买入名单时。 |
| [backtesting-data-integrity](backtesting-data-integrity/SKILL.md) | 确保回测数据完整性，消除幸存者偏差、处理分红复权，反映真实交易环境。 | 构建量化回测模型、获取历史数据或评估策略历史表现时。 |
| [position-sizing-risk-management](position-sizing-risk-management/SKILL.md) | 计算具体买入股数、确定仓位权重、管理组合风险敞口及基于ATR的动态头寸管理。 | 计算具体买入股数、确定仓位权重、管理组合风险敞口或调整持仓规模时。 |
| [exit-rebalancing-protocols](exit-rebalancing-protocols/SKILL.md) | 执行定期再平衡、决定卖出持仓、应对市场下跌及管理现有头寸的系统性规则。 | 执行定期再平衡、决定卖出持仓、应对市场下跌或管理现有头寸时。 |
| [strategy-limitations-pitfalls](strategy-limitations-pitfalls/SKILL.md) | 评估替代策略、考虑做空操作、使用杠杆ETF或比较期货市场与股票市场策略时的风险提示。 | 评估替代策略、考虑做空操作、使用杠杆ETF或比较期货市场与股票市场策略时。 |
| [market-timing-entry-rules](market-timing-entry-rules/SKILL.md) | 决定市场敞口、初始建仓、应对熊市或判断何时停止/恢复买入的择时规则。 | 决定市场敞口、初始建仓、应对熊市或判断何时停止/恢复买入时。 |
| [index-selection-benchmark-setup](index-selection-benchmark-setup/SKILL.md) | 建立投资范围、选择业绩基准、分类股票市值及评估策略表现的基础设置。 | 建立投资范围、选择业绩基准、分类股票市值或评估策略表现时。 |

## Quick Navigation

### 策略基础与理论
- **[momentum-strategy-fundamentals](momentum-strategy-fundamentals/SKILL.md)**: 理解动量投资核心哲学与行为金融学原理。
- **[strategy-limitations-pitfalls](strategy-limitations-pitfalls/SKILL.md)**: 识别策略局限性与跨市场交易的常见陷阱。
- **[active-fund-underperformance-analysis](active-fund-underperformance-analysis/SKILL.md)**: 分析主动基金跑输市场的结构性原因。

### 策略构建与设置
- **[index-selection-benchmark-setup](index-selection-benchmark-setup/SKILL.md)**: 建立投资范围与业绩基准。
- **[momentum-window-parameter-setting](momentum-window-parameter-setting/SKILL.md)**: 优化动量策略的时间窗口参数。
- **[stock-selection-ranking-system](stock-selection-ranking-system/SKILL.md)**: 建立系统化的股票排名与选股机制。

### 执行与风险管理
- **[market-timing-entry-rules](market-timing-entry-rules/SKILL.md)**: 基于趋势的市场择时与入场规则。
- **[position-sizing-risk-management](position-sizing-risk-management/SKILL.md)**: 动态仓位计算与波动率均衡。
- **[exit-rebalancing-protocols](exit-rebalancing-protocols/SKILL.md)**: 系统化的退出与再平衡协议。

### 回测与数据
- **[backtesting-data-integrity](backtesting-data-integrity/SKILL.md)**: 确保回测数据的真实性与完整性。
- **[ban-post-hoc-parameter-optimization](ban-post-hoc-parameter-optimization/SKILL.md)**: 防止回测中的过拟合与后视偏差。

### 基金筛选与评估
- **[etf-screening-and-avoidance-rules](etf-screening-and-avoidance-rules/SKILL.md)**: 识别并排除高风险或非被动型ETF。
- **[mutual-fund-tracking-error-budget](mutual-fund-tracking-error-budget/SKILL.md)**: 评估基金跟踪误差与相对表现。

## How to Use

这些技能旨在作为特定领域的专家知识库被调用。当您在以下场景中提问时，请明确引用相关技能：

1.  **策略开发**：在设计或优化动量策略时，请参考策略构建与执行类技能。
2.  **风险控制**：在计算仓位或进行回测时，请务必调用风险管理与数据完整性技能，以避免常见错误。
3.  **产品选择**：在筛选ETF或评估共同基金时，请使用基金筛选类技能进行合规性检查。
4.  **问题诊断**：如果策略表现不如预期，请使用“策略局限性与陷阱”或“禁止事后参数优化”技能进行诊断。

通过结合这些技能，您可以构建一个稳健、数据驱动的量化投资决策流程。
```