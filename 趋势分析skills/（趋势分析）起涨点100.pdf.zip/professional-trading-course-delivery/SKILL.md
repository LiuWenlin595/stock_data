---
name: professional-trading-course-delivery
description: Use when planning, scheduling, or delivering professional trading courses (specifically Wu Chaohui's操盘课程) that require standardized resource allocation, instructor management, and venue coordination at Guangzhou headquarters. Triggers when arranging course timelines, allocating teaching resources, or confirming instructor schedules for standardized trading education programs.
---

# 专业操盘课程交付标准化

## 适用场景
- 需要实施标准化操盘培训课程
- 需要排期教学资源与师资调配
- 确认广州本部场地与主讲教师档期

## 前置条件
- [ ] 培训地点已确定为广州本部
- [ ] 主讲教师（伍朝辉）档期已确认可用

## 交付标准执行流程

### 1. 理论课程交付配置
**课时设置：**
- 单节课时长：固定45分钟（符合成人注意力集中周期）
- 总讲数：32讲
- 授课方式：连续编号，顺序交付（sequential delivery）

**师资配置：**
- 全部理论课程（第1-32讲）必须由伍朝辉统一授课
- 禁止更换教师，确保教学风格连贯性和知识体系一致性

**场地要求：**
- 固定地点：广州本部实体教室
- 禁止变更至其他分校区或线上授课

### 2. 实盘指导特殊配置
**时长结构：**
- 周期：连续四个月跟踪指导
- 与理论课比例：约1:20（时间维度）
  - 理论：约24小时（32讲×45分钟）
  - 实践：约480小时工作时间

**内容模块：**
1. **模块一：盘口技术特征掌握**（技能训练阶段）
2. **模块二：游资目标股操盘全过程监控**（实战跟踪阶段）

**师资延续：**
- 实盘指导仍由伍朝辉负责，保持教学连续性

### 3. 出版制作资源配置
- **策划/责任编辑**：罗振文（负责内容策划与审核）
- **技术编辑**：陆俊帆（负责技术实现与排版）
- **封面设计**：李桢涛/逸品设计

## 质量控制要点
1. **地点标准化**：广州本部确保教学环境一致性
2. **师资单一化**：避免多教师授课导致的风格冲突
3. **理论实践配比**：实践占比远超理论，符合操盘技能习得规律

## 输出成果
生成《课程实施排期表及资源配置清单》，明确：
- 理论课时间表（32讲×45分钟）
- 实盘指导4个月时间线
- 师资锁定确认书（伍朝辉专属）
- 场地使用确认（广州本部）