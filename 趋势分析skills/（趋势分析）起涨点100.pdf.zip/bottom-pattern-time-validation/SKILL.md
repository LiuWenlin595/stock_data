---
name: bottom-pattern-time-validation
description: Validate minimum adjustment time requirements for bottom formation patterns (double bottom, sloping rectangle, L-shape, head-shoulders bottom, rounded bottom) to distinguish genuine bottoms from false ones. Use when analyzing stocks in bottom-building phase after declines to verify if identified patterns meet minimum time thresholds before considering entry.
---

# 底部形态时间验证

验证底部构筑时间的充分性，排除假性底部。

## 适用场景
- 股价经过下跌后处于底部构筑阶段
- 已识别出具体底部形态，需要验证其可靠性
- 排除V型反转（无整理时间）的情况

## 底部形态识别与时间标准

识别底部形态类型并核对最小调整时间（交易日）：

| 形态类型 | 最小时间 | 特征描述 |
|---------|---------|---------|
| **斜矩形** | 50日 | 倾斜箱体整理，高低点同向倾斜 |
| **大L形** | 30日 | 长期横盘后快速下探再回升 |
| **小L形** | 8日 | 短期底部形态，类似大L但周期短 |
| **双底形** | 13日 | W底，两个低点等高，中间有反弹 |
| **头肩底形** | 30日 | 左肩、头、右肩结构清晰 |
| **大圆弧底形** | 30日 | 圆形或碟形底部，缓慢下跌后缓慢上升 |

## 验证流程

1. **形态识别**：根据K线走势判断属于上述哪种底部形态
2. **时间计算**：统计底部构筑期间的交易日数量
3. **标准比对**：
   - IF 实际调整时间 ≥ 对应标准 → 形态成立，底部构筑充分
   - IF 实际调整时间 < 对应标准 → 形态不成立，警惕假性底部

## 重要提示
- 上述时间为最低标准，实际调整时间越长越可靠
- 不适用于顶部形态判断
- V型反转无整理时间，不适用本标准