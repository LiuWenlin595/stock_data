```markdown
# 起涨点交易技术技能库 (Starting Point Trading Techniques)

基于专业操盘书籍《98D01Da4-37Df-46Af-Af7C-30B9111E7D4E》构建的Claude Code技能集合，涵盖A股主力操盘行为分析、起涨点识别、技术形态验证、资金管理和风险控制等完整交易体系。帮助投资者识别真假突破、把握主升浪启动时机、理解主力建仓洗盘逻辑。

## Available Skills

| Skill | Description | Use When |
|-------|-------------|----------|
| [qizhangdian-fenlei-yu-xingzhi-panding](qizhangdian-fenlei-yu-xingzhi-panding/SKILL.md) | 识别和分类股票起涨点类型（反弹型/趋势型/主升型），判断起涨点性质并计算预期上升空间 | 需要判断起涨点性质和预期涨幅时 |
| [main-rising-starting-point-identification](main-rising-starting-point-identification/SKILL.md) | 识别主升型起涨点，通过生命线与决策线金叉确认，配合成交量验证后续走势 | 股票出现起涨点且需要确认是否为主升型时 |
| [main-rise-starting-point-analysis](main-rise-starting-point-analysis/SKILL.md) | 识别主升型起涨点并在回调时执行低吸策略，结合MACD和盘口大封单验证 | 生命线与决策线金叉向上且盘口出现大封单时 |
| [main-uptrend-start-point](main-uptrend-start-point/SKILL.md) | 识别主升型起涨点，判断股价是否进入主升浪行情 | 大阳线突破底部平台、均线金叉、MACD配合时 |
| [rebound-starting-point-identification](rebound-starting-point-identification/SKILL.md) | 识别反弹型起涨点并判断其操作可行性的技术方法 | 股票出现起涨点信号但需要判断是否为反弹型时 |
| [rebound-start-point](rebound-start-point/SKILL.md) | 识别反弹型起涨点，判断下跌趋势中的反弹机会 | 生命线与决策线死叉向下、决策线走平、大阳线突破决策线时 |
| [rebound-type-starting-point-analysis](rebound-type-starting-point-analysis/SKILL.md) | 判断空头排列结构中的上涨是否为反弹型起涨点并验证后续爆发力 | 观察到股票在空头排列中出现上涨迹象时 |
| [rebound-starting-point-analysis-and-trading](rebound-starting-point-analysis-and-trading/SKILL.md) | 分析反弹型起涨点，执行多因子共振追涨策略，识别风险信号 | 出现反弹型起涨点需要综合决策时 |
| [rebound-starting-point-strategy](rebound-starting-point-strategy/SKILL.md) | 识别反弹型起涨点并执行分仓狙击 | 股票处于阶段性底部但生命线与决策线尚未金叉时 |
| [starting-point-validation-framework](starting-point-validation-framework/SKILL.md) | 通过四大技术系统交叉验证起涨点信号有效性，避免假突破 | 识别到起涨点信号但担心假突破或技术破绽时 |
| [strong-starting-point-identification](strong-starting-point-identification/SKILL.md) | 识别强力型起涨点，包括振幅与涨幅背离时的成交量辅助判定 | 判断起涨点强度和测算上涨空间时 |
| [four-line-golden-cross-starting-point](four-line-golden-cross-starting-point/SKILL.md) | 确认四线金叉共振起涨点，执行突破确认及回调低吸的中线建仓策略 | 攻击线与操盘线金叉且生命线与决策线刚刚金叉时 |
| [special-pattern-starting-point](special-pattern-starting-point/SKILL.md) | 识别特殊形态的起涨点，包括股权转让公告后、横盘建仓后、涨停试盘后等模式 | 识别特定事件或形态后的起涨机会时 |
| [counter-trend-starting-point-identification](counter-trend-starting-point-identification/SKILL.md) | 识别个股逆大盘趋势上涨的起涨点，并根据大盘所处情境判断是否可操作 | 大盘下跌或横盘时个股独立上涨的场景 |
| [trend-following-starting-point-identification](trend-following-starting-point-identification/SKILL.md) | 识别个股顺应大盘上涨趋势的起涨点 | 大盘强势反弹或震荡上涨环境，个股顺势上涨时 |
| [shipan-xingwei-shibie-yu-fenxi](shipan-xingwei-shibie-yu-fenxi/SKILL.md) | 识别主力在起涨前的试盘行为（涨停试盘、长上影线试盘、长下影线试盘、打压挖坑试盘） | 分析主力操盘意图和起涨时机时 |
| [long-lower-shadow-test-strategy](long-lower-shadow-test-strategy/SKILL.md) | 识别主力通过长下影线测试下方支撑、进行恐慌性吸筹或准备拉升的意图 | K线出现长下影线且股价处于平台整理或建仓阶段时 |
| [long-upper-shadow-accumulation-pattern](long-upper-shadow-accumulation-pattern/SKILL.md) | 识别主力通过长上影线反复试盘进行建仓的固定操盘定式 | 个股在相对低位区域多次出现长上影线且伴随打压回调时 |
| [limit-up-test-strategy](limit-up-test-strategy/SKILL.md) | 分析主力通过涨停板测试市场反应、吸筹或准备拉升的意图 | 观察到个股出现涨停板且疑似主力试盘时 |
| [pit-test-pattern-analysis](pit-test-pattern-analysis/SKILL.md) | 识别主力通过打压挖坑进行试盘和洗盘的技术形态，捕捉洗盘结束后的起涨信号 | 放量起涨后快速下跌、成交量萎缩至地量并在决策线获得支撑时 |
| [test-pattern-recognition-and-accumulation-timing](test-pattern-recognition-and-accumulation-timing/SKILL.md) | 识别主力试盘模式，分析主力意图，预测后续建仓时机和波段行情 | 个股K线图中出现长上影线或涨停板试盘形态时 |
| [main-force-behavior-analysis](main-force-behavior-analysis/SKILL.md) | 分析涨停试盘后的主力拉升节奏，预测正式起涨时间，识别主力诱空行为 | 个股出现涨停试盘形态，需要研判主力后续操作节奏时 |
| [main-capital-behavior-analysis](main-capital-behavior-analysis/SKILL.md) | 分析起涨点背后的主力资金行为，通过六维分析框架全面评估主力操盘逻辑 | 识别起涨点后深入分析主力意图和操盘规律时 |
| [intraday-volume-wave-mainforce-behavior-analysis](intraday-volume-wave-mainforce-behavior-analysis/SKILL.md) | 通过识别量峰形态和波形特征，判断主力资金处于拉高建仓、滚动操盘、试盘还是对倒出货阶段 | 盘中实时分析分时图时 |
| [jiancang-xingtai-shibie](jiancang-xingtai-shibie/SKILL.md) | 识别主力建仓的技术形态（三角形横盘、双底等），分析建仓阶段的量价特征 | 分析股票起涨前的主力建仓行为时 |
| [main-force-capital-calculation](main-force-capital-calculation/SKILL.md) | 测算起涨点当日主力资金真实投入量以评估操盘力度 | 需要评估主力投入资金强度和操盘决心时 |
| [zhuli-zijin-yu-pankou-fenxi](zhuli-zijin-yu-pankou-fenxi/SKILL.md) | 分析主力资金投入量、测算操盘量、识别起涨点当日技术特征、区分对敲拉高与拉高建仓 | 分析主力操盘强度和判断建仓阶段时 |
| [moving-average-entry-system](moving-average-entry-system/SKILL.md) | 基于均线系统识别起涨点并执行买入策略 | 需要通过生命线、决策线、攻击线、操盘线等均线确认起涨点时 |
| [junxian-xitong-jiaoyi-celue](junxian-xitong-jiaoyi-celue/SKILL.md) | 基于均线系统（生命线、决策线、攻击线、操盘线）的交易策略，包括主升型起涨点的分仓狙击法则 | 趋势启动初期的交易决策时 |
| [macd-entry-point-analysis](macd-entry-point-analysis/SKILL.md) | 基于MACD指标识别股票起涨点并判定买入时机 | 日线级别需要通过MACD金叉、红绿柱变化确认起涨点时 |
| [k-line-pattern-recognition](k-line-pattern-recognition/SKILL.md) | 识别股票K线中的大阳线、中阳线、小阳线等基本技术形态 | 需要分析K线实体涨幅、影线长度、前置成交量状态时 |
| [kline-pattern-entry-recognition](kline-pattern-entry-recognition/SKILL.md) | 识别小阳线、大阳线、黑太阳线等K线形态作为起涨点 | 通过K线形态、均线系统、振幅等综合判断起涨点时 |
| [medium-yang-candle-starting-point](medium-yang-candle-starting-point/SKILL.md) | 判定4-6%涨幅的中阳线是否为有效起涨点，执行次日回调低吸策略 | 观察到股票出现中阳线需要验证起涨点时 |
| [small-bullish-candle-breakout-strategy](small-bullish-candle-breakout-strategy/SKILL.md) | 确认小阳线突破均线阻力的起涨点成立，制定次日逢低买进策略 | 出现1-4%涨幅小阳线且有效突破决策线或生命线时 |
| [black-sun-pattern-recognition](black-sun-pattern-recognition/SKILL.md) | 判定跳空高开阴线（黑太阳）形态标准性，识别主力洗盘或出货风险 | 股价调整阶段观察到黑太阳形态时 |
| [main-rise-daily-breakout-strategy](main-rise-daily-breakout-strategy/SKILL.md) | 基于日K线大阳线突破与均线系统金叉共振识别主升型起涨点 | 股价以放量大阳线突破底部平台或均线双重阻力时 |
| [main-rise-intraday-attack-wave-strategy](main-rise-intraday-attack-wave-strategy/SKILL.md) | 通过分时图攻击波形识别主升型起涨点并执行分层买入策略 | 盘中呈现攻击短波或中波、日K线均线金叉状态时 |
| [attack-wave-trading-strategies](attack-wave-trading-strategies/SKILL.md) | 识别冲击波、攻击波等分时形态并执行相应交易策略 | 根据攻击波形特征判断主力意图并制定买入策略时 |
| [bottom-pattern-time-validation](bottom-pattern-time-validation/SKILL.md) | 验证底部形态（双底、斜矩形、L型、头肩底、圆弧底）的最小调整时间要求 | 需要区分真假底部形态时 |
| [multi-timeframe-confirmation-method](multi-timeframe-confirmation-method/SKILL.md) | 当日线均量线尚未形成金叉时，使用60分钟K线进行技术修正与次日验证 | 日线级别信号滞后但60分钟级别已出现量能突破时 |
| [main-rise-starting-point-chasing-strategy](main-rise-starting-point-chasing-strategy/SKILL.md) | 综合评估板块热点、题材强度、量能预期及大盘环境决定是否执行追涨买进策略 | 主升型起涨点形态出现且即将进入主升浪快速拉升阶段时 |
| [rebound-starting-point-multi-entry-strategy](rebound-starting-point-multi-entry-strategy/SKILL.md) | 生命线与决策线均向下运行时，根据盘中攻击波出现的不同时段选择差异化入场策略 | 日K线空头排列但盘中出现攻击波时 |
| [rebound-starting-point-death-cross-chase](rebound-starting-point-death-cross-chase/SKILL.md) | 个股出现生命线与决策线死叉但具备反弹型起涨点特征和强板块热点支撑时，判断是否执行例外性追涨买进策略 | 技术信号与资金热点背离、需要逆势做多的特殊短线交易场景 |
| [three-position-trading-system](three-position-trading-system/SKILL.md) | 在60分钟趋势交易中执行分三批次建仓的完整体系 | 询问如何分批建仓、何时加第二仓/第三仓、或如何应用机动仓调节成本时 |
| [starting-point-capital-all