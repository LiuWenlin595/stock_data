```markdown
# 专业交易与宏观经济分析技能集

本技能集源自专业金融书籍（ID: 54852575-Cccb-482E-908B-A43Bbbb2D006），涵盖了交易心理学、技术分析、期权策略、宏观经济分析及财政政策评估等领域。这些技能旨在帮助用户在金融市场分析、投资决策制定、风险控制以及个人心智成长方面获得专业支持，将理论与实践相结合以应对复杂的市场环境。

## Available Skills

| Skill | Description | Use When |
|-------|-------------|----------|
| [real-interest-rate-differential-capital-flow-analysis](real-interest-rate-differential-capital-flow-analysis/SKILL.md) | 分析实际利率差异如何驱动跨境资本流动、汇率变动及国内信贷条件。 | 预测开放经济体汇率走势、评估货币政策对国际资本吸引力、分析国内信贷挤出效应。 |
| [trader-psychology-mindset](trader-psychology-mindset/SKILL.md) | 培养成功交易者的心理特质、道德信念和决策调整能力。 | 评估交易者心理状态、克服赚钱罪恶感、根据市场实际调整预测。 |
| [reality-challenge-psychology](reality-challenge-psychology/SKILL.md) | 面对交易亏损或现实挫折时进行心理调整，将错误转化为成长机会。 | 交易亏损后、遭遇不公或不利现实、需要建立责任承担心态。 |
| [dow-theory-analysis](dow-theory-analysis/SKILL.md) | 应用道氏理论分析市场趋势、预测经济活动并确认趋势反转。 | 判断市场主要趋势方向、评估经济前景、验证趋势变化。 |
| [capital-gains-tax-middle-class-wealth-analysis](capital-gains-tax-middle-class-wealth-analysis/SKILL.md) | 分析降低资本利得税对中产阶级房屋所有者的财富效应及社区经济影响。 | 评估资本利得税政策变化对节税、财富增值、消费支出及社区经济的影响。 |
| [capital-gains-tax-return-analysis](capital-gains-tax-return-analysis/SKILL.md) | 计算资本利得税对投资报酬率的税后影响，评估投资方案在税率情境下的可行性。 | 比较税前与税后报酬率、判断风险溢价吸引力、评估不同税率对投资的影响。 |
| [stock-market-economic-prediction](stock-market-economic-prediction/SKILL.md) | 利用股票市场作为整体经济趋势的领先指标，预测经济起伏与循环峰值。 | 宏观经济预测、经济周期分析、政策影响评估、投资决策择时。 |
| [commitment-mental-programming](commitment-mental-programming/SKILL.md) | 通过心智重编程建立"投入的决心"，消除内在冲突，结合意识与潜意识追求目标。 | 重大目标达成、长期习惯养成、交易纪律建立、需要持续意志力支撑。 |
| [capital-gains-tax-revenue-creation-analysis](capital-gains-tax-revenue-creation-analysis/SKILL.md) | 分析资本利得税减免对政府税收的创造效应。 | 评估税收政策调整、投资激励措施的经济影响、税收动态评分。 |
| [dow-jones-monthly-median-benchmark](dow-jones-monthly-median-benchmark/SKILL.md) | 提供道琼工业指数在1982年5月至1993年6月期间的月度价格变动中位数统计值。 | 评估该时期道指的典型市场波动性或基准水平。 |
| [trader-psychology-self-awareness](trader-psychology-self-awareness/SKILL.md) | 交易者自我认知与心理架构分析框架。 | 评估交易者心理状态、识别神经性驱动模式、诊断"应该的暴君"、建立冲销交易员心理特质。 |
| [institutional-futures-leverage-manipulation](institutional-futures-leverage-manipulation/SKILL.md) | 大型法人利用期货杠杆操纵现货市场，通过双倍期货空头获利弥补现货亏损。 | 拥有庞大资金的机构投资者需要卖出大量股票时。 |
| [market-breadth-indicator](market-breadth-indicator/SKILL.md) | 计算和应用10天约当期-净变动-移动平均-行情宽度振荡指标。 | 衡量市场中期超买超卖情况或评估市场宽度。 |
| [emotional-state-management](emotional-state-management/SKILL.md) | 情绪状态管理与心流状态建立。 | 从负面情绪中恢复、建立积极情绪关联、理解动机冲突、进入最佳表现状态。 |
| [redistribution-fiscal-policy-impact](redistribution-fiscal-policy-impact/SKILL.md) | 分析劫富济贫式财政政策对资本形成与经济增长的负面影响。 | 财政政策评估、税制设计分析、经济影响预测、奥地利学派经济学应用。 |
| [recession-wealth-protection](recession-wealth-protection/SKILL.md) | 在经济衰退或萧条期间调整投资立场以避开财务灾难，通过预测市场转折点实现保护。 | 经济周期转折期、政府干预政策变化期、面临系统性风险时。 |
| [belief-system-transformation](belief-system-transformation/SKILL.md) | 信念系统与价值观转换程序。 | 评估个人价值观结构、识别行为动机根源、消除限制性信念、建立积极价值观。 |
| [reserve-currency-commodity-pricing-analysis](reserve-currency-commodity-pricing-analysis/SKILL.md) | 分析储备货币贬值对大宗商品定价的影响，评估实际进口成本和竞争力变化。 | 美元计价大宗商品分析、购买力平价计算、储备货币风险评估、国际贸易成本分析。 |
| [moving-average-trading-system](moving-average-trading-system/SKILL.md) | 使用移动平均线生成买卖信号，判断长期趋势方向与个股筛选。 | 趋势跟踪交易、中长期投资决策、技术分析驱动的仓位管理。 |
| [money-management-risk-control](money-management-risk-control/SKILL.md) | 执行资金管理和风险控制策略，包括一致性获利原则和期权交易的特殊风险规则。 | 设定交易仓位规模、管理风险资本、锁定利润。 |
| [economic-growth-foundation](economic-growth-foundation/SKILL.md) | 分析经济成长的先决条件（生产、剩余、储蓄、创新）。 | 评估经济体是否具备成长基础、解释为何某些经济体无法成长、经济系统分析。 |
| [macroeconomic-policy-analysis](macroeconomic-policy-analysis/SKILL.md) | 分析宏观经济因素和政策干预对市场的影响。 | 理解市场异常表现、预测政策影响、分析宏观经济与市场背离。 |
| [wealth-acquisition-classification](wealth-acquisition-classification/SKILL.md) | 财富获取途径分类。 | 面临生存选择、分析财富来源、了解不同获取财富的方式。 |
| [extreme-low-capital-intuitive-speculation](extreme-low-capital-intuitive-speculation/SKILL.md) | 价格创历史极值且缺乏基本面支撑时，使用极少量资金进行期权投机性买入的例外策略。 | 价格创历史极值且定性为"可承受损失的直觉赌博"时（严禁养成习惯）。 |
| [market-player-vs-value-player-distinction](market-player-vs-value-player-distinction/SKILL.md) | 区分基于价格走势预测的"行情玩家"与基于价值低估的"价值玩家"。 | 确定交易策略方向、分析重点及风险管理模式。 |
| [trend-change-1-2-3-criteria](trend-change-1-2-3-criteria/SKILL.md) | 使用1-2-3准则判定趋势变动，确认转折。 | 趋势跟踪交易、中长期趋势转折识别、道氏理论实践应用。 |
| [junk-bond-definition-and-risk](junk-bond-definition-and-risk/SKILL.md) | 定义垃圾债券并分析其风险特征。 | 询问扩张信用并购融资、高风险债券特征、公司并购资金筹措方式。 |
| [fiscal-deficit-trend-projection](fiscal-deficit-trend-projection/SKILL.md) | 基于"若无变化则趋势持续"原则预测赤字支出趋势延续性。 | 长期趋势交易、政府预算预测、财政政策分析。 |
| [option-time-value-lookup](option-time-value-lookup/SKILL.md) | 期权时间价值数据查询。 | 需要查询索引521-1048对应的期权时间价值数值时。 |
| [elizabethan-debt-repayment-strategy](elizabethan-debt-repayment-strategy/SKILL.md) | 国家财政面临巨额赤字时的领导力与财政管理策略。 | 国家财政面临巨额赤字、需要建立极高领导威望转化税收为自愿行为。 |
| [pe-ratio-book-value-analysis](pe-ratio-book-value-analysis/SKILL.md) | 使用本益比与帐面价值作为相对指标，辅助判断市场及个股的超买超卖状态。 | 个股筛选、市场估值判断、多头行情初期至中期的辅助分析。 |
| [sovereign-debt-sustainability-threshold-analysis](sovereign-debt-sustainability-threshold-analysis/SKILL.md) | 评估主权国家债务可持续性，通过利息支出与税收收入比率预测债务危机风险。 | 非储备货币国家的高债务负担分析、财政可持续性评估、危机预警。 |
| [trading-discipline-methodology](trading-discipline-methodology/SKILL.md) | 交易纪律与市场分析方法论。 | 建立交易行为准则、观察致胜模式、管理市场压力、进行盘势判读。 |
| [technical-trading-strategies](technical-trading-strategies/SKILL.md) | 应用技术分析工具和交易策略，包括狭幅盘整突破、四天法则等。 | 识别交易机会、判断趋势反转、评估交易胜算。 |
| [credit-expansion-recession-ineffectiveness](credit-expansion-recession-ineffectiveness/SKILL.md) | 判定经济衰退期信用扩张政策的有效性，分析名义利率与基源利率的关系。 | 货币政策分析、经济周期研究、债券市场判断、衰退期投资决策。 |
| [options-trading-strategy](options-trading-strategy/SKILL.md) | 应用维克的选择权定价理念和基于历史统计的期权交易策略。 | 评估期权价格合理性、制定期权交易计划、判断期权溢价是否公平。 |
| [option-pricing-risk-assessment](option-pricing-risk-assessment/SKILL.md) | 评估期权定价合理性，计算风险比率，制定期权交易策略。 | 期权交易决策、波动率评估、风险报酬分析。 |
| [relative-strength-trading](relative-strength-trading/SKILL.md) | 运用相对强度指标选择股票与商品期货的交易标的。 | 趋势跟踪中的标的筛选、市场领导股识别、商品价差交易。 |
| [djia-volatility-historical-table](djia-volatility-historical-table/SKILL.md) | 解读道琼斯工业指数变动绝对值历史频次分布表。 | 市场波动性研究、历史数据分析、技术分析参考。 |
| [macro-fundamental-analysis](macro-fundamental-analysis/SKILL.md) | 基于政府政策干预进行宏观基本面分析与经济预测。 | 金融市场趋势预测、政策影响评估、投资决策框架建立。 |
| [market-statistical-age-analysis](market-statistical-age-analysis/SKILL.md) | 基于市场走势的统计分布评估风险，判断当前市场"年龄"与健康状况。 | 中长期投资决策、风险管理、市场周期定位、多空方向选择。 |
| [four-day-rule-trend-forecasting](four-day-rule-trend-forecasting/SKILL.md) | 运用四天法则识别道琼斯工业指数中期趋势的顶部与底部。 | 中期趋势分析、道琼斯指数交易、市场转折点预警。 |
| [fundamental-stock-screening](fundamental-stock-screening/SKILL.md) | 使用本益比、信用扩张程度、流动性等基本面指标辅助筛选股票。 | 技术分析后的最终筛选、多空方向选择、风险管理。 |
| [cross-strait-financial-terminology](cross-strait-financial-terminology/SKILL.md) | 转换台湾与大陆金融术语译法。 | 阅读使用台湾译法的金融书籍、跨境金融文献阅读、术语对照。 |
| [us-budget-deficit-forecasting](us-budget-deficit-forecasting/SKILL.md) | 使用四种保守方法预测美国政府未来十年预算赤字。 | 长期财政规划、国债投资分析、宏观经济预测、政策影响评估。 |
| [market-analysis-framework](market-analysis-framework/SKILL.md) | 自上而下的市场分析框架和盘中联动规律。 | 系统性市场分析、预测特定时间段的市场行为（股票、债券、商品、期货、黄金）。 |
| [investment-decision-evaluation](investment-decision-evaluation/SKILL.md) | 边际投资决策评估规则，评估风险-报酬比率和资本利得税率影响。 | 评估投资方案可行性、分析税收对投资决策的影响。 |
| [rational-self-interest-definition](rational-self-interest-definition/SKILL.md) | 确立理性的自利定义与道德边界，区分自利与剥削。 | 道德立场确立、政治经济学讨论、交易伦理、个人权利辩护。 |
| [option-trading-strategies](option-trading-strategies/SKILL.md) | 期权交易策略集合，包括基于历史波动率的期权选择和避险。 | 选择期权合约、对冲投资组合、评估期权交易胜算。 |
| [advanced-technical-patterns](advanced-technical-patterns/SKILL.md) | 高级技术形态分析，包括道氏理论在个股上的应用限制和2B假信号策略。 | 应用道氏理论分析个股、处理2B假突破。 |
| [technical-analysis-trading-system](technical-analysis-trading-system/SKILL.md) | 综合技术分析交易决策系统，生成市场趋势信号。 | 识别趋势变动信号、评估多空力量、选择具体交易标的。 |

## Quick Navigation

### 交易心理与心智管理
- **trader-psychology-mindset**: 培养成功交易者的心理特质、道德信念和决策调整能力。
- **reality-challenge-psychology**: 面对亏损或挫折时的心理调整，将错误转化为成长机会。
- **commitment-mental-programming**: 通过心智重编程建立投入的决心，消除内在冲突。
- **trader-psychology-self-awareness**: 交易者自我认知与心理架构分析框架。
- **emotional-state-management**: 情绪状态管理与心流状态建立。
- **belief-system-transformation**: 信念系统与价值观转换程序。

### 技术分析与交易系统
- **dow-theory-analysis**: 应用道氏理论分析市场趋势、预测经济活动。
- **market-breadth-indicator**: 计算和应用10天约当期-净变动-移动平均-行情宽度振荡指标。
- **moving-average-trading-system**: 使用移动平均线生成买卖信号，判断长期趋势。
- **trend-change-1-2-3-criteria**: 使用1-2-3准则判定趋势变动。
- **technical-trading-strategies**: 应用狭幅盘整突破、四天法则等技术分析工具。
- **relative-strength-trading**: 运用相对强度指标选择交易标的。
- **djia-volatility-historical-table**: 解读道琼斯工业指数变动绝对值历史频次分布表。
- **four-day-rule-trend-forecasting**: 运用四天法则识别中期趋势的顶部与底部。
- **advanced-technical-patterns**: 高级技术形态分析，包括2B假信号策略。
- **technical-analysis-trading-system**: 综合技术分析交易决策系统。

### 期权交易策略
- **option-time-value-lookup**: 期权时间价值数据查询。
- **options-trading-strategy**: 应用维克的选择权定价理念和基于历史统计的策略。
- **option-pricing-risk-assessment**: 评估期权定价合理性，计算风险比率。
- **option-trading-strategies**: 期权交易策略集合，包括基于历史波动率的期权选择和避险。

### 宏观经济与财政政策
- **real-interest-rate-differential-capital-flow-analysis**: 分析实际利率差异如何驱动跨境资本流动。
- **capital-gains-tax-middle-class-wealth-analysis**: 分析降低资本利得税对中产阶级的财富效应。
- **capital-gains-tax-return-analysis**: 计算资本利得税对投资报酬率的税后影响。
- **stock-market-economic-prediction**: 利用股票市场作为整体经济趋势的领先指标。
- **capital-gains-tax-revenue-creation-analysis**: 分析资本利得税减免对政府税收的创造效应。
- **redistribution-fiscal-policy-impact**: 分析劫富济贫式财政政策对资本形成与经济增长的负面影响。
- **recession-wealth-protection**: 在经济衰退期间调整投资立场以避开财务灾难。
- **reserve-currency-commodity-pricing-analysis**: 分析储备货币贬值对大宗商品定价的影响。
- **economic-growth-foundation**: 分析经济成长的先决条件。
- **macroeconomic-policy-analysis**: 分析宏观经济因素和政策干预对市场的影响。
- **fiscal-deficit-trend-projection**: 预测赤字支出趋势延续性。
- **sovereign-debt-sustainability-threshold-analysis**: 评估主权国家债务可持续性。
- **credit-expansion-recession-ineffectiveness**: 判定经济衰退期信用扩张政策的有效性。
- **us-budget-deficit-forecasting**: 预测美国政府未来十年预算赤字。

### 市场分析与基本面
- **dow-jones-monthly-median-benchmark**: 提供特定时期道指月度价格变动中位数统计值。
- **institutional-futures-leverage-manipulation**: 大型法人利用期货杠杆操纵现货市场的策略。
- **pe-ratio-book-value-analysis**: 使用本益比与帐面价值辅助判断市场及个股状态。
- **macro-fundamental-analysis**: 基于政府政策干预进行宏观基本面分析与经济预测。
- **market-statistical-age-analysis**: 基于市场走势的统计分布评估风险，判断市场"年龄"。
- **fundamental-stock-screening**: 使用基本面指标辅助筛选股票。
- **market-analysis-framework**: 自上而下的市场分析框架和盘中联动规律。

### 风险管理与资金管理
- **money-management-risk-control**: 执行资金管理和风险控制策略。
- **investment-decision-evaluation**: 边际投资决策评估规则。
- **extreme-low-capital-intuitive-speculation**: 价格创历史极值时的极少量资金期权投机策略。

### 投资哲学与概念
- **wealth-acquisition-classification**: 财富获取途径分类。
- **market-player-vs-value-player-distinction**: 区分"行情玩家"与"价值玩家"。
- **junk-bond-definition-and-risk**: 定义垃圾债券并分析其风险特征。
- **elizabethan-debt-repayment-strategy**: 国家财政面临巨额赤字时的领导力与财政管理策略。
- **rational-self-interest-definition**: 确立理性的自利定义与道德边界。
- **cross-strait-financial-terminology**: 转换台湾与大陆金融术语译法。

## How to Use

要使用这些技能，请根据您的具体需求描述任务或问题。例如：
- 如果您需要分析**市场趋势**，可以参考"技术分析与交易系统"分类下的技能。
- 如果您正在处理**交易心理障碍**，请查看"交易心理与心智管理"部分。
- 如果您需要评估**宏观经济政策**的影响，请浏览"宏观经济与财政政策"分类。
- 对于**期权交易**的具体操作，请直接访问"期权交易策略"下的相关技能。

您可以直接点击上述表格中的技能链接，或根据"Quick Navigation"部分找到对应的技能文件。每个技能文件都包含详细的操作指南和触发条件。
```